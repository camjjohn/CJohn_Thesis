# -*- coding: utf-8 -*-
"""
Created on Fri Mar  8 10:04:25 2019

@author: Camille John
"""

#%% CREATION OF RMSE DATAFRAME
#%% DOCUMENT SETUP
# Scientific libraries
import numpy as np
# Data analysis libraries
import pandas as pd
#Visualization Librairies
import matplotlib.pyplot as plt
#import seaborn as sns;
#sns.set()
# Operating system library
import os
cwd = os.getcwd()  # cwd: current working directory
# Time access and conversion library
import time as tm
# Custom Functions
from functions_rmseDataframe import LoadCleanDataFile, CreateColSel, CreateColAna

#%% MAIN BODY OF CODE - Start
#%% STEP 1: INPUTS 

# Create dataframe of meta data referenced
metaData = 'mdProj'
filePath = os.path.join(cwd,'..','02-MetaDataAnalysis', metaData, metaData + '.csv')
df_md = pd.DataFrame()
df_md = pd.read_csv(filePath)

# Create list of identifiers to analyze
#identifier_list = df_md['Identifier'].tolist()
#identifier_list = ['8b0c8e73226d4e76a94940ea7a0d09eb64fe1997', 
#                   '21bf3d7c2495cdc2e7e1776c3c2bf6a6eb27f9d7', 
#                   '60d1b128ecdd67ab89be533d25c8e2536e41565f'] # Partial and single
#                                                               # selection initiated
identifier_list = df_md['Identifier']
commonIds = pd.read_csv(os.path.join(cwd,'..','02-MetaDataAnalysis','mdProj', 
                                     'CommonIdsProj_201709-201808.csv'))
identifier_list = pd.merge(identifier_list.to_frame(), commonIds, on = ['Identifier'])
identifier_list = identifier_list['Identifier'].tolist()


# Create list of months to analyze   
yyyy_mm_list =  ['2015-09', '2015-10', '2015-11', '2015-12', '2016-01', '2016-02', #0-5
                 '2016-03', '2016-04', '2016-05', '2016-06', '2016-07', '2016-08', #6-11
                 '2016-09', '2016-10', '2016-11', '2016-12', '2017-01', '2017-02', #12-17
                 '2017-03', '2017-04', '2017-05', '2017-06', '2017-07', '2017-08', #18-23
                 '2017-09', '2017-10', '2017-11', '2017-12', '2018-01', '2018-02', #24-29
                 '2018-03', '2018-04', '2018-05', '2018-06', '2018-07', '2018-08'] #30-35
#yyyy_mm_list = yyyy_mm_list[24:36] # Partial selection initiated (2017-09 to 2018-08)
#yyyy_mm_list = yyyy_mm_list[12:36] # Partial selection initiated (2016-09 to 2018-08)
yyyy_mm_list = [yyyy_mm_list[35]] # Single selection initiated

seasonAssign = pd.DataFrame({
            'Year_Month': ['2015-09', '2015-10', '2015-11', '2015-12', '2016-01', '2016-02', #0-5
                           '2016-03', '2016-04', '2016-05', '2016-06', '2016-07', '2016-08', #6-11
                           '2016-09', '2016-10', '2016-11', '2016-12', '2017-01', '2017-02', #12-17
                           '2017-03', '2017-04', '2017-05', '2017-06', '2017-07', '2017-08', #18-23
                           '2017-09', '2017-10', '2017-11', '2017-12', '2018-01', '2018-02', #24-29
                           '2018-03', '2018-04', '2018-05', '2018-06', '2018-07', '2018-08'], #30-35
#            'Season': ['Cooling', 'Shoulder', 'Shoulder', 'Heating', 'Heating', 'Heating', 
#                       'Heating', 'Shoulder', 'Shoulder', 'Cooling', 'Cooling', 'Cooling',
#                       'Cooling', 'Shoulder', 'Shoulder', 'Heating', 'Heating', 'Heating', 
#                       'Heating', 'Shoulder', 'Shoulder', 'Cooling', 'Cooling', 'Cooling',
#                       'Cooling', 'Shoulder', 'Shoulder', 'Heating', 'Heating', 'Heating', 
#                       'Heating', 'Shoulder', 'Shoulder', 'Cooling', 'Cooling', 'Cooling'],
            'Season': ['Fall', 'Fall', 'Fall', 'Winter', 'Winter', 'Winter', 
                       'Spring', 'Spring', 'Spring', 'Summer', 'Summer', 'Summer',
                       'Fall', 'Fall', 'Fall', 'Winter', 'Winter', 'Winter', 
                       'Spring', 'Spring', 'Spring', 'Summer', 'Summer', 'Summer',                       
                       'Fall', 'Fall', 'Fall', 'Winter', 'Winter', 'Winter', 
                       'Spring', 'Spring', 'Spring', 'Summer', 'Summer', 'Summer'],                       
                       })
# Specify criterion2: Analysis period is  >= crit2 [hour]
# Specify criterion3: Outdoor temperature remains approximately constant during
    #   analysis period (i.e. the temperature change is <= crit3)
# criterion4: Specify daytime or nighttime periods of analysis
# Specify criterion5: R-squared value for tauBldg_hr_optim is  >= crit5)
    
crit2 = 1
crit3 = 2.
crit4 = ['D_', 'N_']
crit5 = [0.25, 0.5, 1.0] #place standard error values in descending order
critSel = '60min_2oC_Nb_Tfdiff5'
#%% STEP 2:  SELECT TIME CONSTANTS USED FOR ANALYSIS
colAllSel = pd.DataFrame()
colAllCount = pd.DataFrame() 

now = tm.time()
idx1 = 1
for yyyy_mm in yyyy_mm_list:
    print ('\n')
    print('Year_Month Iteration %d of %d started' % (idx1,len(yyyy_mm_list)))
    print ('\n')
    if os.path.exists(os.path.join(cwd, '..','03-TimeCstEstimationNb', yyyy_mm)):
        idx2 = 1
        for identifier in identifier_list:
            print('Identifier Iteration %d of %d started' % (idx2,len(identifier_list)))
            if os.path.exists(os.path.join(cwd,'..','03-TimeCstEstimationNb',yyyy_mm,'timeCst'+
                                           metaData[2:]+crit4[1]+yyyy_mm+'_'+identifier+'.csv')):
                colCln = pd.DataFrame()
                colCln = LoadCleanDataFile(yyyy_mm, identifier, metaData, crit4)
                if 'tauBldg_hr_optim' in colCln.columns:
                    count1, count2, count3, count4, count5, colSel = CreateColSel(colCln, crit2, crit3, crit5)
                    counts = {'Identifier': [identifier],
                              'All': [count1],
                              'Taubldg_hr_optim_LessThanOrEqualZero': [count2],
                              'Tf_minus_Tfoptim_MoreThanOrEqual5Deg': [count3],
                              'TauMeas_LessThan1hr': [count4],
                              'deltaTout_MoreThan2deg': [count5]}
                    colCount = pd.DataFrame(counts, columns = ['Identifier',
                                                               'All',
                                                               'Taubldg_hr_optim_LessThanOrEqualZero',
                                                               'Tf_minus_Tfoptim_MoreThanOrEqual5Deg',
                                                               'deltaTout_MoreThan2deg'])
                    colSel['Identifier'] = np.nan
                    colAllCount = colAllCount.append(colCount, ignore_index=True)
                    for ind in colSel.index:
                        colSel.loc[ind,'Identifier'] = identifier
                    colAllSel = colAllSel.append(colSel, ignore_index=True)
                else:
                    print(str(identifier) + ': Least Squares was not performed for this identifier.')
            else:
                print (str(identifier) + ': This identifier was not found in ' + yyyy_mm + '.')
            idx2 += 1
            print(tm.time() - now)
    else:
        print (yyyy_mm + ': This month was not found in estimated data.')
        print ('\n')
        
    colAllCount.to_csv(os.path.join(cwd,critSel,'colCount'+ metaData[2:]+crit4[1]+yyyy_mm+
                                  '.csv'), index = True) 
    colAllSel['Season'] = np.nan
    colAllSel['Climate Zone'] = np.nan
    colAllSel['Style'] = np.nan
    colAllSel['Age of Home [years]'] = np.nan
    colAllSel['Floor Area [m2]'] = np.nan
    colAllSel['Number of Floors'] = np.nan
    colAllSel['Building Footprint [m2]'] = np.nan
    colAllSel['Number of Occupants'] = np.nan
    colAllSel['Number of Remote Sensors'] = np.nan
    # colAllSel.set_index(['Identifier'], inplace = True)
    colAllSel.reset_index(inplace=True)
    for ind in colAllSel.index:
        colAllSel.loc[ind, 'Climate Zone'] = df_md.loc[df_md['Identifier'] == colAllSel.loc[ind,'Identifier'], 
                      'Climate Zone'].values
        colAllSel.loc[ind, 'Age of Home [years]'] = df_md.loc[df_md['Identifier'] == colAllSel.loc[ind,'Identifier'], 
                      'Age of Home [years]'].values
        colAllSel.loc[ind, 'Style'] = df_md.loc[df_md['Identifier'] == colAllSel.loc[ind,'Identifier'], 
                      'Style'].values
        colAllSel.loc[ind, 'Floor Area [m2]'] = df_md.loc[df_md['Identifier'] == colAllSel.loc[ind,'Identifier'], 
                      'Floor Area [m2]'].values
        colAllSel.loc[ind, 'Number of Floors'] = df_md.loc[df_md['Identifier'] == colAllSel.loc[ind,'Identifier'], 
                      'Number of Floors'].values
        colAllSel.loc[ind, 'Number of Occupants'] = df_md.loc[df_md['Identifier'] == colAllSel.loc[ind,'Identifier'], 
                      'Number of Occupants'].values
        colAllSel.loc[ind, 'Number of Remote Sensors'] = df_md.loc[df_md['Identifier'] == colAllSel.loc[ind,'Identifier'], 
                      'Number of Remote Sensors'].values
    colAllSel['Season'] = seasonAssign.loc[
            seasonAssign['Year_Month'] == yyyy_mm, 'Season'].item()
    colAllSel['Building Footprint [m2]'] = colAllSel['Floor Area [m2]'] / colAllSel[
            'Number of Floors']
    colAllSel['Dwelling Classification']= np.nan
    colAllSel.loc[(colAllSel['Style'] == 'Detached'), 'Dwelling Classification'] = 'Single-Family Residential'
    colAllSel.loc[(colAllSel['Style'] != 'Detached') & (colAllSel['Style'].notnull()), 'Dwelling Classification'] = 'Multi-Family Residential'

    colAllSel.to_csv(os.path.join(cwd,critSel,'colSel'+ metaData[2:]+crit4[1]+yyyy_mm+
                                  '.csv'), index = True)

    idx1 += 1
    print(tm.time() - now)

#%% MAIN BODY OF CODE - End
#%% NOTES - Start     
##Check number of dwelling wthat have  analysis periods with RSMEs over/under a certain value
#yyyy_mm_list =  ['2017-09','2017-10', '2017-11', '2017-12', '2018-01', '2018-02', 
#                 '2018-03', '2018-04', '2018-05', '2018-06', '2018-07', '2018-08']
#metaData = 'mdProj'
#filePath = os.path.join(cwd,'..','02-MetaDataAnalysis', metaData, metaData + '.csv')
#df_md = pd.DataFrame()
#df_md = pd.read_csv(filePath)
#critSel = '60min_2oC_Nb_Tfdiff5'
#crit4 = ['D_', 'N_']
#
#for yyyy_mm in yyyy_mm_list:
#    check = pd.read_csv(os.path.join(cwd,critSel,'colAna'+ metaData[2:]+crit4[1]+yyyy_mm+'.csv'))
#    print(yyyy_mm)
#    print('%6d dwellings have analysis periods with RMSE larger than 1.0.' % (len(check[(check['AnaPeriodsUsed1.5'] != check['AnaPeriodsUsed1.0'])])))
#    print('%6d dwellings have analysis periods with RMSE larger than 0.5.' % (len(check[(check['AnaPeriodsUsed1.0'] != check['AnaPeriodsUsed0.5'])])))
#    print('%6d sfr dwellings have analysis periods with RMSE larger than 1.0.' % (len(check[(check['AnaPeriodsUsed1.5'] != check['AnaPeriodsUsed1.0']) & (check['Style'] == 'Detached')])))
#    print('%6d sfr dwellings have analysis periods with RMSE larger than 0.5.' % (len(check[(check['AnaPeriodsUsed1.0'] != check['AnaPeriodsUsed0.5']) & (check['Style'] == 'Detached')])))
#    print('%6d mfr dwellings have analysis periods with RMSE larger than 1.0.' % (len(check[(check['AnaPeriodsUsed1.5'] != check['AnaPeriodsUsed1.0']) & (check['Style'] != 'Detached') & (check['Style'].notnull())])))
#    print('%6d mfr dwellings have analysis periods with RMSE larger than 0.5.' % (len(check[(check['AnaPeriodsUsed1.0'] != check['AnaPeriodsUsed0.5']) & (check['Style'] != 'Detached') & (check['Style'].notnull())])))
#       
#len(check[(check['Style'] == 'Detached')])
#len(check[(check['Style'] != 'Detached')& (check['Style'].notnull())])        
#%% NOTES - End