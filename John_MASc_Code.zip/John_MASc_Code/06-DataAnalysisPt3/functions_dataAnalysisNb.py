# -*- coding: utf-8 -*-
"""
Created on Thu Feb 20 16:28:05 2020

@author: Camille John
"""

#%% CUSTOM FUNCTIONS FOR DATA ANALYSIS
#%% DOCUMENT SETUP
# Scientific libraries
import numpy as np
# Data analysis libraries
import pandas as pd
#Visualization Librairies
import matplotlib.pyplot as plt
import seaborn as sns;
sns.set(palette="pastel", color_codes=True)
# Operating system library
import os
cwd = os.getcwd()
# Time access and conversion library
import time as tm

#%% CREATE HISTOGRAM (w/kde)
def Hist1(col, binNo, kde, title, folderName, fileName):
    f6 = plt.figure()
    f6 = sns.distplot(col.dropna(axis=0, how='any'), bins = binNo, kde = False)
    f6.set(xlim=(0, None))
    f6.axes.set_title(title)
    f6.set_xlabel(r'Time Constant, $\tau$ [hours]')
    f6.set_ylabel('Frequency')
    f6.get_figure().savefig( os.path.join(cwd + '/'+ folderName +'/hist_'+ fileName +'.png'),
#               transparent = 'true'
               )

#%% CREATE VIOLIN PLOT (split)
def Violin1(x_data, y_data, hue_data, df, title, folderName, fileName):
    f2 = plt.figure(figsize = (12,8))
    f2 = sns.violinplot(x=x_data, y= y_data, hue= hue_data,
               split=True, inner="quart", 
               palette={'2018-02': "r", '2018-08': "b"},
               data=df)
    f2.set(ylim=(0, None))
    f2.axes.set_title(title)
    f2.set_xlabel('Climate Zones')
    f2.set_ylabel(r'Time Constant, $\tau$ [hours]')
    f2.get_figure().savefig(os.path.join(cwd,folderName,'viol_'+ fileName +'.png'),
#       transparent = 'true'
        )
    sns.despine(left=True)
    
#%% CREATE BOX PLOT (compare)
def Box1(x_data, y_data, hue_data, df, title, folderName, fileName):
    f3 = plt.figure(figsize = (18,12))
    f3 = sns.boxplot(x=x_data, y= y_data, hue= hue_data,    
               palette={'2018-02': "r", '2018-08': "b"},
               data=df)
    f3.axes.set_title(title)
    f3.set_xlabel('Climate Zones')
    f3.set_ylabel(r'Time Constant, $\tau$ [hours]')
    f3.get_figure().savefig(os.path.join(cwd,folderName,'box_'+ fileName +'.png'),
#       transparent = 'true'
        )
    sns.despine(left=True)
    
#%% CREATE KERNEL DENSITY ESTIMATION (2D center AND 1D borders)
def Kde2Kde1_1(x_data, y_data, df, folderName, fileName):
#    f2 = plt.figure()
    f1 = sns.jointplot(x_data, y_data, data=df, kind='kde', space= 0, color='b'
                       ,xlim = [0,70], ylim = [0,120] #default 0-100 on x-axis and 0-120 on y-axis
                       ,n_levels=30, kernel='epa', stat_func=None)
    plt.subplots_adjust(left=0.2, right=0.8, top=0.8, bottom=0.2)  # shrink fig so cbar is visible
    f1.set_axis_labels(xlabel=r'Time Constant, $\tau$ [hours]', ylabel='Age of Home [years]')
#    cax = grid.fig.add_axes([.95, .18, .04, .5])  # x, y, width, height
#    color_bar = sns.plt.colorbar(cax=cax)
#    plt.show()
    f1.savefig(os.path.join(cwd,folderName,'Kde2Kde1_'+ fileName +'.png'),
#                       transparent = 'true'
                        )
 
#%% MAIN BODY OF CODE - End
#%% NOTES - Start


#%% NOTES - End