# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 03:46:42 2019

@author: Camille John
"""

#%% DATA ANALYSIS
#%% DOCUMENT SETUP
# Scientific libraries
import numpy as np
# Data analysis libraries
import pandas as pd
#Visualization Librairies
import matplotlib.pyplot as plt
import seaborn as sns;
sns.set(palette="pastel", color_codes=True)
# Operating system library
import os
cwd = os.getcwd()
# Time access and conversion library
import time as tm
# Custom Functions
from functions_dataAnalysisNb import Hist1, Violin1, Box1, Kde2Kde1_1

#%% MAIN BODY OF CODE - Start
#%% STEP 1: INPUTS

date = '26Jan2021'
# Create dataframe referenced
metaData = 'mdProj'
critSel = '60min_2oC_Nb_Tfdiff5'
tauBldg_hr = 'tauWtdMeanRmse0.5'
crit4 = ['D_', 'N_']

# Create dataframe of meta data referenced
filePath = os.path.join(cwd,'..','02-MetaDataAnalysis',metaData,metaData +'.csv')
df_md = pd.DataFrame()
df_md = pd.read_csv(filePath)

# Create list of months to analyze   
yyyy_mm_list =  ['2015-09', '2015-10', '2015-11', '2015-12', '2016-01', '2016-02', #0-5
                 '2016-03', '2016-04', '2016-05', '2016-06', '2016-07', '2016-08', #6-11
                 '2016-09', '2016-10', '2016-11', '2016-12', '2017-01', '2017-02', #12-17
                 '2017-03', '2017-04', '2017-05', '2017-06', '2017-07', '2017-08', #18-23
                 '2017-09', '2017-10', '2017-11', '2017-12', '2018-01', '2018-02', #24-29
                 '2018-03', '2018-04', '2018-05', '2018-06', '2018-07', '2018-08'] #30-35
yyyy_mm_list = yyyy_mm_list[24:36] # Partial selection initiated (2017-09 to 2018-08)
#yyyy_mm_list = yyyy_mm_list[12:36] # Partial selection initiated (2016-09 to 2018-08)
#yyyy_mm_list = [yyyy_mm_list[29]] # Single selection initiated

#%% STEP 2: MONTHLY TAU
df_projAll = pd.DataFrame()

idx1 = 1
for yyyy_mm in yyyy_mm_list:
    print ('\n')
    print('Year_Month Iteration %d of %d started' % (idx1,len(yyyy_mm_list)))
    print ('\n')
    if os.path.exists(os.path.join(cwd, '..','05-DataAnalysisPt2')):
        fileName = 'colAna'+ metaData[2:] +crit4[1] + yyyy_mm +'.csv'
        filePath = os.path.join(cwd,'..','05-DataAnalysisPt2',critSel, fileName)
        if os.path.exists(os.path.join(cwd,'..', '05-DataAnalysisPt2',critSel, fileName)):
            colAna = pd.DataFrame()
            colAna = pd.read_csv(filePath)
            # colAna = colAna[colAna['tauStdRmse0.5']>=0]
            dataSample = pd.DataFrame()
            dataSample = pd.concat([colAna['Year_Month'], colAna['Identifier'],
                                    colAna[tauBldg_hr],colAna['Climate Zone'],
                                    colAna['Floor Area [m2]'], colAna['Number of Floors'],
                                    colAna['Age of Home [years]']], axis = 1)
            dataSample['AreaPerLevel'] = dataSample['Floor Area [m2]'] / dataSample['Number of Floors']
            dataSample.set_index(['Identifier'], inplace = True)
            dataSample['Style'] = np.nan
            dataSample['Auxilliary Heat Fuel Type'] = np.nan
            dataSample['Model'] = np.nan
            dataSample['Number of Remote Sensors'] = np.nan
            for ind in dataSample.index:
                dataSample.loc[ind, 'Style'] = df_md.loc[df_md['Identifier'] == ind, 
                              'Style'].values
                dataSample.loc[ind, 'Auxilliary Heat Fuel Type'] = df_md.loc[df_md['Identifier'] == ind, 
                              'Auxilliary Heat Fuel Type'].values
                dataSample.loc[ind, 'Model'] = df_md.loc[df_md['Identifier'] == ind, 
                              'Model'].values
                dataSample.loc[ind, 'Number of Remote Sensors'] = df_md.loc[df_md['Identifier'] == ind, 
                              'Number of Remote Sensors'].values
            dataSample.to_csv(os.path.join(cwd, critSel,'rawDataSample_'+yyyy_mm+'_'+ date +'.csv'))
            # dataSample = dataSample[(dataSample[tauBldg_hr]<= 240.)] # realistically should be smaller than 10 days
            # dataSample = dataSample[(dataSample[tauBldg_hr]>= 3.)] #  realistically should be bigger than 3 hours
            for i in range(1,7):
                Hist1(dataSample[dataSample['Climate Zone']==i][tauBldg_hr], 20, False, #default bin no is 25
                      'Distribution of Time Constant Values for ' + yyyy_mm + ': Climate Zone'+str(i), critSel,
                      metaData[2:] +crit4[1]+ yyyy_mm +'_cz'+str(i)+'_tauBldg')
                Kde2Kde1_1(tauBldg_hr, 'Age of Home [years]', dataSample[dataSample['Climate Zone']==i][[tauBldg_hr,'Age of Home [years]']],
                         critSel, metaData[2:] +crit4[1]+ yyyy_mm +'_cz'+str(i)+'_tauBldg')
            df_projAll = df_projAll.append(dataSample)    
        else:
            print (critSel +'/' + metaData +'/' + yyyy_mm +  ': This analysis dataframe was not found.')
            print ('\n')
    else:
        print (yyyy_mm + ': This month was not found among estimated data.')
        print ('\n')
    idx1 += 1
df_projAll.to_csv(os.path.join(cwd,critSel,metaData[2:]+crit4[1]+'All_'+ date +'.csv'))

df_plt = pd.DataFrame()
df_plt = df_projAll[(df_projAll['Year_Month'] == '2018-02') | (df_projAll['Year_Month'] == '2018-08')]    
#Violin1('Climate Zone', tauBldg_hr,'Year_Month', df_plt, 
#        'Distribition of Time Constant Values by climate zone', critSel, 
#        metaData[2:] +crit4[1] +'cz'+'_tauBldg')  
Box1('Climate Zone', tauBldg_hr,'Year_Month', df_plt, 
        'Distribition of Time Constant Values by climate zone', critSel, 
        metaData[2:] +crit4[1] +'cz'+'_tauBldg')
 
#%% MAIN BODY OF CODE - End
#%% NOTES - Start


#%% NOTES - End