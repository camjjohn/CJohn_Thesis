Note001.For analyzing the monthly time constant
averages through visualizations and creating a 
dataframe for the presentation stage:
- requires csv files saved to in folder 
04-AnalysisDataframe:
colAnaProjN_yyyy-mm.csv
- use dataAnalysisNb.py and 
functions_dataAnalysisNb.py
- figures and csv files created saved to folder
06-DataAnalysisPt3/60min_2oC_Nb_Tfdiff5


