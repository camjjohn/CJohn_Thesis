# -*- coding: utf-8 -*-
"""
Created on Thu Feb 28 22:36:00 2019

@author: Camille John
"""

#%% CUSTOM FUNCTIONS FOR TIME CONSTANT ESTIMATION
#%% DOCUMENT SETUP
# Scientific libraries
import numpy as np
# Data analysis libraries
import pandas as pd
from scipy.optimize import least_squares,curve_fit
from sklearn.metrics import r2_score
# Operating system library
import os
cwd = os.getcwd()
# Time access and conversion library
import time as tm
import datetime as dt

#%% LOAD DATA FILES
def LoadDataFile(yyyy_mm, identifier):
    cwd = os.getcwd()  # cwd: current working directory
    fileName = identifier + '.csv'
    filePath = os.path.join(cwd, '..', '01-Data', yyyy_mm, fileName)
    # Creates dataframe
    df = pd.read_csv(filePath)
    # Creates custom index
    pd.to_datetime(df['DateTime'])
    df.set_index(df['DateTime'], inplace = True)
#    print ('Identifier :' + str(identifier))
    return (df)

#%% CREATE DAYLIGHT DATAFRAME
def SunRiseSet(df_md, suntime, yyyy_mm, identifier):
    # Creates daylight dataframe
    location = pd.DataFrame()
    location = df_md[['Country', 'ProvinceState', 'City']][
            df_md['Identifier'] == identifier].reset_index(drop=True) 
    sunrow = pd.DataFrame()
    try:
        sunrow = suntime.loc[(suntime['Country'] == location['Country'][0]) 
                        & (suntime['ProvinceState'] == location['ProvinceState'][0]) 
                        & (suntime['City'] == location['City'][0])].index[0]
        daylight = pd.DataFrame()
        daylight = pd.DataFrame(data = {'YearMonth': [yyyy_mm],
                                       'sunrise':[suntime.loc[sunrow, 'rise_'+ yyyy_mm]], 
                                       'sunset':[suntime.loc[sunrow,'set_'+ yyyy_mm]]})                
        daylight.loc[0,'sunrise'] = pd.to_datetime(daylight.loc[0,'sunrise']).hour
        daylight.loc[0,'sunset'] = pd.to_datetime(daylight.loc[0,'sunset']).hour
        daylight.loc[0,'sunrise_minus_1'] = daylight.loc[0,'sunrise']-1
    except IndexError:
        print ("Error - Location not found in SunTime for %s" %(identifier))
    return (daylight)

#%% CREATE COLPREP
def CreateColPrep(df, daylight):
    # Create sub-dataframe 'DateTime'
    timeIntervals = df.loc[:,['DateTime']]
    # Create sub-dataframe 'tempC'
    tempC = df.loc[:,['T_ctrl','T_out']]
    tempC = (tempC - 32.) * 5. / 9.
    # Create sub-dataframe 'equipUsed'
    equipAll = df.reindex(columns = ['fan', 
                  'auxHeat1', 'auxHeat2','auxHeat3', 
                  'compCool1', 'compCool2', 'compCool3', 
                  'compHeat1', 'compHeat2', 'compHeat3']) 
    # Drop columns containing all missing values (i.e. remove equipment not
    # in use from analysis)
    equipUsed = equipAll.dropna(axis=1, how ='all')
    # Create a new column called hvac_off where the value is 1
    # if the heating, cooling and ventilation are off
    off = (equipUsed == 0).all(axis=1)
    equipUsed = equipUsed.assign(hvac_off = np.where(off, 1, 0))
    # Combine select columns by label for analysis
    colPrep = pd.concat([timeIntervals, tempC, equipUsed], axis = 1)
    # Assign hourId, night class sleep (Criterion4 & 5)
    # night column where the value is 1 if the hourId is between sunset and sunrise
    # sleep column where the value is 1 if the hourId is between 10pm to 5am (less Activity)
    colPrep['hourId'] = np.nan
    colPrep['night'] = np.nan
    colPrep['sleep']= np.nan
    hourIds = pd.to_datetime(colPrep['DateTime']) 
    for i in range(0, len(colPrep['T_ctrl'])):
        colPrep.iloc[i, -3] = hourIds[i].hour
        if (daylight['sunrise_minus_1'][0] < daylight['sunset'][0]):
            criterion4 = (colPrep.iloc[i,-3]<= daylight['sunrise_minus_1'][0]) | (colPrep.iloc[i,-3]>=daylight['sunset'][0])
        else:
            criterion4 = (colPrep.iloc[i,-3]<= daylight['sunrise_minus_1'][0]) & (colPrep.iloc[i,-3]>=daylight['sunset'][0])    
        colPrep.iloc[i, -2] = np.where (criterion4, 1, np.nan)
        criterion5 = (colPrep.iloc[i,-3] < 5) | (colPrep.iloc[i,-3] >= 22)
        colPrep.iloc[i,-1] = np.where(criterion5, 1, np.nan)
    # Create empty column for periodId
    colPrep['periodId'] = 0.
    # Assign a periodId to the remaining time intervals based on 'hvac_off', 'night' and 'sleep' (criterion1)  
    for i in range(1, len(colPrep['T_ctrl'])):
        criterion1 = (colPrep.iloc[i,-5] == 1) & (colPrep.iloc[i,-3] == 1) & (colPrep.iloc[i,-2] == 1)
        colPrep.iloc[i, -1] = np.where (criterion1, 1, 0)
    count = 0
    for i in range(1, len(colPrep['T_ctrl'])):
        if ((colPrep.iloc[i, -1] - colPrep.iloc[(i-1), -1]) == 1):
            count += 1 
        if colPrep.iloc[i, -1] !=0:
            colPrep.iloc[i, -1] = count
    # Assign first entry of periodId   
    if (colPrep.iloc[0,-5] == 1) & (colPrep.iloc[0,-3] == 1)  & (colPrep.iloc[0,-2] == 1):
        colPrep.iloc[0,-1] = 1
    else:
        colPrep.iloc[0,-1] = 0
    colPrep['periodId'] = colPrep['periodId'].replace(0, np.nan)
    #Select analysis periods when hvac off, night time, and sleep time (Criterion 1, 4 & 5)
    colPrep = colPrep[(colPrep['hvac_off'] == 1) & (colPrep['night'] == 1)  & (colPrep['sleep'] == 1) ]
    # Table organized by analysis periods (for vizualizing)
#    tblAna = pd.pivot_table(colAna, index = ['periodId','DateTime'], 
#                            values = ['T_ctrl', 'T_out'])
    # Print section of tblAna related to a PeriodId
#    print tblAna.query('periodId == 1.0')
    return (colPrep)

#%% CREATE EXPONENTIAL DECAY CURVE
def ExponentialDecay(time,T_f, Ti_Tf,tauBldg):
    return T_f + Ti_Tf * np.exp(- time / tauBldg)

#%% CREATE AGGREGATE FUNCTION
def AggregateFunction(row,colPrep):
    time = np.arange(0., len(colPrep[colPrep.periodId==row.name])*5, 5.) / 60.
    Temperature = colPrep[colPrep.periodId==row.name].T_ctrl.values
    bnds = ([row.T_f-50, Temperature[0] - row.T_f-50, 0],[row.T_f+50,Temperature[0] - row.T_f+50, np.inf])
    init = np.array([row.T_f, Temperature[0] - row.T_f, 50])
    if (np.isnan(Temperature).any()):
        print ('For one analysis period, there are missing T_Ctrl values. Least Squares was not used.') 
    else: 
        try:
            popt, pcov = curve_fit(ExponentialDecay,time,Temperature,init,bounds=bnds)
            row[['T_f_optim','T_i_minus_T_f_optim', 'tauBldg_hr_optim']] = popt
            residual = ExponentialDecay(time, popt[0], popt[1],popt[2]) - Temperature
            row['rss'] = np.sum(residual**2) # residual sum of squares
            row['tss'] = np.sum((Temperature - Temperature.mean())**2) # total sum of squares
            row['ess'] = row['tss']-row['rss'] # explained sum of squares
            row['rmse'] = np.sqrt(row['rss']/(len(Temperature))) #standard error of regression       
            row['r2_score'] = r2_score(Temperature,ExponentialDecay(time, popt[0], popt[1],popt[2]))
            # standard uncertainties or standard errors (std deviation) in fitting parameters
            perr = np.sqrt(np.diag(pcov))
            row[['err_T_f_optim','err_T_i_minus_T_f_optim', 'err_tauBldg_hr_optim']] = perr
        except RuntimeError:
            print("Error - curve_fit failed")
            row[['T_f_optim','T_i_minus_T_f_optim', 'tauBldg_hr_optim']] = [np.nan, np.nan, np.nan]
            row['rss'] = np.nan
            row['tss'] = np.nan
            row['ess'] = np.nan
            row['rmse'] = np.nan
            row['r2_score'] = np.nan
            row[['err_T_f_optim','err_T_i_minus_T_f_optim', 'err_tauBldg_hr_optim']] = [np.nan, np.nan, np.nan]
    return row

#%% CREATE COLCALC
def CreateColCalc(colPrep):
    # Create dataframe with columns needed for calculation of tauBldg:
    #   col0 = startTime; col1 = endTime; col2 = tauMeas; col3 = tauMeas_hr (criterion2)
    Part1 = colPrep.groupby('periodId').agg({'DateTime': ['min', 'max']})
    Part1.iloc[:, 0] = pd.to_datetime(Part1.iloc[:, 0])
    Part1.iloc[:, 1] = pd.to_datetime(Part1.iloc[:, 1])
    Part1['tauMeas'] = Part1.iloc[:, 1] - Part1.iloc[:, 0]
    Part1['tauMeas_hr'] = (Part1.iloc[:, 1] - Part1.iloc[:, 0]) / np.timedelta64(1, 's') / 3600.
    Part1.columns = ['startTime','endTime','tauMeas','tauMeas_hr']
    #   col4 = T_i
    Part2 = colPrep.groupby('periodId').agg({'T_ctrl':[lambda x: x.iloc[0]]})
    Part2.columns = Part2.columns.droplevel(1)
    Part2.columns = ['T_i']
    #   col5 = T_tm
    Part3 = colPrep.groupby('periodId').agg({'T_ctrl':[lambda x: x.iloc[-1]]})
    Part3.columns = Part3.columns.droplevel(1)
    Part3.columns = ['T_tm']
    #   col6 = tempOut_min; col7 = tempOut_max; col8 = T_f
    Part4 = colPrep.groupby('periodId').agg({'T_out': ['min', 'max', 'mean']})
    Part4.columns = Part4.columns.droplevel(1)
    Part4.columns = ['T_out_min','T_out_max','T_f']
    #   col9 = deltaT_out (criterion3)
    Part4['deltaT_out'] = Part4.iloc[:, 1] - Part4.iloc[:, 0]
    colCalc = pd.concat([Part1, Part2, Part3, Part4], axis=1)
    colCalc = colCalc[colCalc['tauMeas_hr'] >= 1.]
    #   col10 = tauBldg_hr
    colCalc['tauBldg_hr'] =  -1 * colCalc.iloc[:, 3] / np.log(1 - 
      (colCalc.iloc[:, 4] - colCalc.iloc[:, 5]) / (colCalc.iloc[:, 4] - 
      colCalc.iloc[:, 8]))
    colCalc = colCalc.dropna(axis=0, how='any')
    #Curve fit to Data
    # col11 = T_f_optim; col12 = T_i_minus_T_f_optim; col 13 = tauBldg_hr_optim;
    # col14 = residual_cost; col 15 = r2_score 
#    now = tm.time()
    listofNames = colCalc.columns.tolist()
    listofNames.extend(('T_f_optim','T_i_minus_T_f_optim', 'tauBldg_hr_optim',
                        'rss','tss','ess',
                        'rmse','r2_score',
                        'err_T_f_optim','err_T_i_minus_T_f_optim', 'err_tauBldg_hr_optim',))
    colCalc = colCalc.reindex(columns=listofNames, fill_value=0)
    colCalc = colCalc.apply(AggregateFunction, args=(colPrep,), axis=1)
    colCalc['Tf_minus_Tfoptim'] = abs(colCalc['T_f'] - colCalc['T_f_optim'])
#    print(tm.time() - now)
    return (colCalc)
#%% CREATE COLCLN
def CreateColCln(df, daylight):
    # Create dataframe with columns needed for identifying analysis periods
    colPrep = CreateColPrep(df, daylight)
    # Create dataframe with columns needed for time constant calculation
    colCalc = CreateColCalc(colPrep)
    # Create clean (processed) dataframe with:
    #   col0 = tauMeas_hr (criterion2); col1 = deltaT_out (criterion3); 
    #   col2 = T_i; col3 = T_tm; col4 = T_f; col5 = tauBldg_hr; col6= startTime;
#    colCln = pd.concat([colCalc.iloc[:,3], colCalc.iloc[:,9], colCalc.iloc[:,4],
#                        colCalc.iloc[:,5], colCalc.iloc[:,8], colCalc.iloc[:,10],
#                        colCalc.iloc[:,0]], axis=1)
    colCln = colCalc
#    df.rename(columns = {'Unnamed: 0':'DateTime'}, inplace = True)
    return (colCln)
    
