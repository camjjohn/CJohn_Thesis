# -*- coding: utf-8 -*-
"""
Created on Fri Mar  8 09:59:19 2019

@author: Camille John
"""

#%% CUSTOM FUNCTIONS FOR CREATION OF ANALYSIS DATAFRAME
#%% DOCUMENT SETUP
# Scientific libraries
import numpy as np
# Data analysis libraries
import pandas as pd
#Visualization Librairies
import matplotlib.pyplot as plt
#import seaborn as sns;
#sns.set()
# Operating system library
import os
cwd = os.getcwd()
# Time access and conversion library
import time as tm

#%% LOAD DATA FILE
def LoadCleanDataFile(yyyy_mm, identifier, metaData, crit4):
    cwd = os.getcwd()  # cwd: current working directory
    fileName = 'timeCst'+metaData[2:]+crit4[1]+yyyy_mm+'_'+identifier+'.csv'
    filePath = os.path.join(cwd, '..','03-TimeCstEstimationNb', yyyy_mm, fileName)
    # Creates dataframe
    colCln = pd.read_csv(filePath, 
                         error_bad_lines=False, warn_bad_lines=True)
    return (colCln)

#%% CREATE COLSEL
def CreateColSel(colCln, crit2, crit3, crit5, crit6, crit7):
    # criterion1: The house is under free-floating conditions during analysis
    #  period (i.e. when the HVAC system is switched off)
    # criterion2: Analysis period is  more than 1 hour
    # criterion3: Outdoor temperature remains approximately constant during
    #   analysis period (i.e. the temperature change is <= to 2°C)
    #criterion4: periods of analysis are between sunset and sunrise(night)
    # criterion5: RMSE value for tauBldg_hr_optim is  <= crit5) 
    colCln = colCln[colCln['tauBldg_hr_optim'] > 0]
    colSel = pd.concat([colCln['tauMeas_hr'], colCln['deltaT_out'], colCln['rmse'], 
                        colCln['r2_score'], colCln['tauBldg_hr_optim'], colCln['T_f'],
                        colCln['Tf_minus_Tfoptim'], colCln['startTime']], axis = 1)
    colSel = colSel[colSel['Tf_minus_Tfoptim'] < 5.0] # limit difference between Tf and Tf_optim 
    for element in crit5:
        colSel['SelectedRmse'+str(element)] = np.nan
    #   col0 = tauMeas_hr (criterion2); col1 = deltaT_out (criterion3); 
    #   col2 = rmse; col3 = r2_score; col4 = tauBldg_hr_optim;
    #   col5 =Tf_minus_Tfoptim; col6 = SelectedRmse0.5 (criterion5); 
    #   col7 = SelectedRmse1.0 (criterion5); col8 = SelectedRmse2.0 (criterion5)  
    for i in range(0, len(colSel.index)):
        criterion2 = (colSel.iloc[i, 0] >= crit2)
        criterion3 = (np.absolute(colSel.iloc[i, 1]) <= crit3)
        criterion6 = (colSel.iloc[i, 4] >= crit6)
        criterion7 = (colSel.iloc[i, 4] <= crit7)
        for idx, element in enumerate(crit5):
            criterion5 = (colSel.iloc[i, 2] <= element)
            colSel.iloc[i, -(len(crit5) - idx)] = np.where(
                    criterion2 and criterion3 and criterion5 and criterion6 and criterion7, 1., 0.)
#    colSel = colSel.loc[colSel['SelectedRmse'+str(crit5[0])] == 1] #Selection of only crit5 rows
    return (colSel)

#%% CREATE COLANA
def CreateColAna(identifier, yyyy_mm, colCln, crit2, crit3, crit5, crit6, crit7):
    # Create dataframe with columns needed for selection of analysis periods
    colSel = CreateColSel(colCln, crit2, crit3, crit5, crit6, crit7)
    colAna = pd.DataFrame(columns = ['Identifier', 'Year_Month'], 
                       data=[[identifier, yyyy_mm]])
    colAna['MaxRmseColSel']= np.nan
    colAna['MaxRmseColSel']= colSel.rmse.max()
    for i in range(0, len(crit5)):
        colFilt = colSel.loc[colSel['SelectedRmse'+str(crit5[i])] == 1] #Selection of only crit5 rows
        colAna['tauWtdMeanRmse'+str(crit5[i])] = np.nan
        if not colFilt.empty:
            colAna['tauWtdMeanRmse'+str(crit5[i])] = np.average(colFilt[colFilt['SelectedRmse'+
               str(crit5[i])] == 1].tauBldg_hr_optim, weights= 1 / (colFilt[colFilt['SelectedRmse'+
                  str(crit5[i])] == 1].rmse))
        # based on rmse range lower than crit5
        colAna['tauMeanRmse'+str(crit5[i])] = np.nan # mean of taus
        colAna['tauStdRmse'+str(crit5[i])] = np.nan # standard deviation of taus
        colAna['CV'+str(crit5[i])] = np.nan # coefficient of variation
        colAna['tauMeanRmse'+str(crit5[i])] = colFilt[colFilt['SelectedRmse'+
               str(crit5[i])] == 1].tauBldg_hr_optim.mean()
        colAna['tauStdRmse'+str(crit5[i])] = colFilt[colFilt['SelectedRmse'+
               str(crit5[i])] == 1].tauBldg_hr_optim.std()
        colAna['CV'+str(crit5[i])] = colAna['tauStdRmse'+str(crit5[i])] / colAna['tauMeanRmse'+
               str(crit5[i])]
        colAna['AnaPeriodsUsed'+str(crit5[i])] = len(colFilt[colFilt['SelectedRmse'+str(crit5[i])] == 1].index)
    return (colAna)
