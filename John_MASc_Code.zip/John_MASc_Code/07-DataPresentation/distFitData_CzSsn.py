# -*- coding: utf-8 -*-
"""
Created on Thu May  7 13:44:15 2020

@author: Camille John
"""

#%% DISTRIBUTION FITTING TO DATA
#%% DOCUMENT SETUP
import pandas as pd
import numpy as np
import scipy
from sklearn.preprocessing import StandardScaler
import scipy.stats
import matplotlib.pyplot as plt
from sklearn import datasets


import os
import seaborn as sns
cwd = os.getcwd()  # cwd: current working directory
import warnings
warnings.filterwarnings("ignore")

#%% MAIN BODY OF CODE - Start
#%% Load Pre-prepared datasets
#Load cleaned and explanded meta data    
df_md = pd.read_csv(os.path.join(cwd,'ProjN_metaData.csv'))    
#  Load time constant data
df = pd.read_csv(os.path.join(cwd, 'ProjN_tmCstData.csv'))

#%% STEP 1: Data Preparation Pt1


# By Climate Zone
df_cz1 = df[(df['Climate Zone']== 1)]
df_cz2 = df[(df['Climate Zone']== 2)]
df_cz3 = df[(df['Climate Zone']== 3)]
df_cz4 = df[(df['Climate Zone']== 4)]
df_cz5 = df[(df['Climate Zone']== 5)]
df_cz6 = df[(df['Climate Zone']== 6)]
df_cz7 = df[(df['Climate Zone']== 7)]
df_cz8 = df[(df['Climate Zone']== 8)]

#%% STEP 2: Data Preparation Pt2

#SFR By Season
df_cz1Fal = df_cz1[(df_cz1['Season']=='Fall')] 
df_cz1Win = df_cz1[(df_cz1['Season']=='Winter')]
df_cz1Spr = df_cz1[(df_cz1['Season']=='Spring')]
df_cz1Sum = df_cz1[(df_cz1['Season']=='Summer')]

df_cz2Fal = df_cz2[(df_cz2['Season']=='Fall')] 
df_cz2Win = df_cz2[(df_cz2['Season']=='Winter')]
df_cz2Spr = df_cz2[(df_cz2['Season']=='Spring')]
df_cz2Sum = df_cz2[(df_cz2['Season']=='Summer')]

df_cz3Fal = df_cz3[(df_cz3['Season']=='Fall')] 
df_cz3Win = df_cz3[(df_cz3['Season']=='Winter')]
df_cz3Spr = df_cz3[(df_cz3['Season']=='Spring')]
df_cz3Sum = df_cz3[(df_cz3['Season']=='Summer')]

df_cz4Fal = df_cz4[(df_cz4['Season']=='Fall')] 
df_cz4Win = df_cz4[(df_cz4['Season']=='Winter')]
df_cz4Spr = df_cz4[(df_cz4['Season']=='Spring')]
df_cz4Sum = df_cz4[(df_cz4['Season']=='Summer')]

df_cz5Fal = df_cz5[(df_cz5['Season']=='Fall')] 
df_cz5Win = df_cz5[(df_cz5['Season']=='Winter')]
df_cz5Spr = df_cz5[(df_cz5['Season']=='Spring')]
df_cz5Sum = df_cz5[(df_cz5['Season']=='Summer')]

df_cz6Fal = df_cz6[(df_cz6['Season']=='Fall')] 
df_cz6Win = df_cz6[(df_cz6['Season']=='Winter')]
df_cz6Spr = df_cz6[(df_cz6['Season']=='Spring')]
df_cz6Sum = df_cz6[(df_cz6['Season']=='Summer')]

df_cz7Fal = df_cz7[(df_cz7['Season']=='Fall')] 
df_cz7Win = df_cz7[(df_cz7['Season']=='Winter')]
df_cz7Spr = df_cz7[(df_cz7['Season']=='Spring')]
df_cz7Sum = df_cz7[(df_cz7['Season']=='Summer')]

df_cz8Fal = df_cz8[(df_cz8['Season']=='Fall')] 
df_cz8Win = df_cz8[(df_cz8['Season']=='Winter')]
df_cz8Spr = df_cz8[(df_cz8['Season']=='Spring')]
df_cz8Sum = df_cz8[(df_cz8['Season']=='Summer')]
           
#%% STEP 3: INPUTS
y= df_cz6Win.loc[:,'tauWtdMeanRmse0.5']
y = y.values
fileName = 'cz6Win.png'
pretitle = 'Climate Zone 6 Winter:'

#%%  STEP 4
# Create an index array (x) for data
x = np.arange(len(y))
size = len(y)
n = size

#%% STEP 5: Visualize the data, and show descriptive summary
fig3 = plt.figure()
ax3 = fig3.add_subplot(111)
plt.hist(y)
ax3.set_title(pretitle + ' Histogram')
ax3.set_xlabel(r'$\tau_{mth,k}$ [hours]')
ax3.set_ylabel('Frequency')
plt.tight_layout()
# plt.show()
# fig3.savefig(os.path.join(cwd, 'Figures_TmCstData', 'Histogram_'+ fileName), bbox_inches='tight')

hist_n, hist_bins, hist_patches =plt.hist(y)
y_df = pd.DataFrame(y, columns=['Data'])
y_df_stats = y_df.describe()
gmean = scipy.stats.gmean(y)
#print ('\nSummary of Statistics for Distribution:')
#print ('----------------------------------------')
#print (y_df_stats)
#print ('Geometric Mean:', gmean)


#%% STEP 6: Fitting a range of distribution and test for goodness of fit

sc=StandardScaler() 
yy = y.reshape (-1,1)
sc.fit(yy)
y_std =sc.transform(yy)
y_std = y_std.flatten()
y_std
del yy

dist_names = [
              'beta',
              'expon',
              'gamma',
              'lognorm',
               'norm',
              'weibull_min', 
              'weibull_max',
              'chi2',
              'exponweib',
              'f',
              'johnsonsb'              
              ]

# Set up empty lists to store results
chi_square = []
p_values = []
# Set up 50 bins for chi-square test
# Observed data will be approximately evenly distrubuted aross all bins

bin_no=20 # bin number method 1
# upper_quartile = np.percentile(y, 75) # bin number method 2
# lower_quartile = np.percentile(y, 25)
# iqr = upper_quartile - lower_quartile
# upper_whisker = y[(y<=upper_quartile+1.5*iqr)].max()
# lower_whisker = y[(y>=lower_quartile-1.5*iqr)].min()
# bw= 2*iqr*n**(-1/3)
# bin_no = int(round((y.max() - y.min())/2, -1))

percentile_bins = np.linspace(0,100,(bin_no+1))
percentile_cutoffs = np.percentile(y_std, percentile_bins)
observed_frequency, bins = (np.histogram(y_std, bins=percentile_cutoffs))
cum_observed_frequency = np.cumsum(observed_frequency)

# Loop through candidate distributions

for distribution in dist_names:
    # Set up distribution and get fitted distribution parameters
    dist = getattr(scipy.stats, distribution)
    param = dist.fit(y_std)
    
    # Obtain the KS test P statistic, round it to 5 decimal places
    p = scipy.stats.kstest(y_std, distribution, args=param)[1]
    p = np.around(p, 5)
    p_values.append(p)    
    
    # Get expected counts in percentile bins
    # This is based on a 'cumulative distrubution function' (cdf)
    cdf_fitted = dist.cdf(percentile_cutoffs, *param[:-2], loc=param[-2], 
                          scale=param[-1])
    expected_frequency = []
    for bin in range(len(percentile_bins)-1):
        expected_cdf_area = cdf_fitted[bin+1] - cdf_fitted[bin]
        expected_frequency.append(expected_cdf_area)
    
    # calculate chi-squared
    expected_frequency = np.array(expected_frequency) * size
    cum_expected_frequency = np.cumsum(expected_frequency)
    ss = sum (((cum_expected_frequency - cum_observed_frequency) ** 2) / cum_observed_frequency)
    chi_square.append(ss)
        
# Collate results and sort by goodness of fit (best at top)

results = pd.DataFrame()
results['Distribution'] = dist_names
results['chi_square'] = chi_square
results['p_value'] = p_values
results.sort_values(['chi_square'], inplace=True)
    
# Report results

print ('\nDistributions sorted by goodness of fit:')
print ('----------------------------------------')
print (results)

#%% STEP 7: top three fits, plot the fit and return the sklearn parameters.

# Divide the observed data into 100 bins for plotting (this can be changed)
number_of_bins = bin_no
bin_cutoffs = np.linspace(np.percentile(y,0), np.percentile(y,99),number_of_bins)

fig4 = plt.figure(figsize=(6.5,4.5))
# Create the plot
h = plt.hist(y, bins = bin_cutoffs, color='0.75')

# Get the top three distributions from the previous phase
number_distributions_to_plot = 3
dist_names = results['Distribution'].iloc[0:number_distributions_to_plot]

# Create an empty list to stroe fitted distribution parameters
parameters = []

# Loop through the distributions ot get line fit and paraemters

for dist_name in dist_names:
    # Set up distribution and store distribution paraemters
    dist = getattr(scipy.stats, dist_name)
    param = dist.fit(y)
    parameters.append(param)
    
    mean, var, skew, kurt = scipy.stats.johnsonsb.stats(a=param[0], b=param[1], loc=param[2], scale=param[3], moments='mvsk')
    median = scipy.stats.johnsonsb.median(a=param[0], b=param[1], loc=param[2], scale=param[3])
    std = scipy.stats.johnsonsb.std(a=param[0], b=param[1], loc=param[2], scale=param[3])
    t_crit = scipy.stats.t.ppf(q=0.975,df=n-1) # for 95% confidence interval
    SE = std / np.sqrt(n)
    ci_lower = mean - (t_crit*SE)
    ci_upper = mean + (t_crit*SE)
    
    # Get line for each distribution (and scale to match observed data)
    pdf_fitted = dist.pdf(x, *param[:-2], loc=param[-2], scale=param[-1])
    scale_pdf = np.trapz (h[0], h[1][:-1]) / np.trapz (pdf_fitted, x)
    pdf_fitted *= scale_pdf
    
    # Add the line to the plot
    plt.plot(pdf_fitted, label=dist_name + ' distribution')
    
    # Set the plot x axis to contain 99% of the data
    # This can be removed, but sometimes outlier data makes the plot less clear
    plt.xlim(0,np.percentile(y,99))

# Add legend and display plot
plt.axvline(median, color='g', linestyle='dashed', linewidth=1, label = 'estimated Median')
plt.axvline(mean, color='r', linestyle='dashed', linewidth=1, label = 'estimated Mean')
plt.axvspan(ci_lower, ci_upper, facecolor='r',
            alpha=0.2, label=r'estimated Mean (95% CL)')
fig4.legend(bbox_to_anchor=(0.975,0.87), loc="upper right")
plt.title(pretitle +' Best Fit Johnson SB Distribution \n (a=%7.3f, b=%7.3f, loc=%7.3f, scale=%7.3f)' %(param[0], param[1], param[2], param[3]))
plt.xlabel(r'$\tau_{mth,k}$ [hours]')
plt.ylabel('Frequency')
plt.tight_layout()
plt.show()
fig4.savefig(os.path.join(cwd, 'Figures_TmCstData', 'distFitData_'+ fileName), bbox_inches='tight')


# Store distribution paraemters in a dataframe (this could also be saved)
dist_parameters = pd.DataFrame()
dist_parameters['Distribution'] = (
        results['Distribution'].iloc[0:number_distributions_to_plot])
dist_parameters['Distribution parameters'] = parameters

# Print parameter results
print ('\nDistribution parameters:')
print ('------------------------')

#for index, row in dist_parameters.iterrows():
#    print ('\nDistribution:', row[0])
#    print ('Parameters:', row[1] )


#%% STEP 8: qq and pp plots
    
data = y_std.copy()
data.sort()

# Loop through selected distributions (as previously selected)

for distribution in dist_names:
    # Set up distribution
    dist = getattr(scipy.stats, distribution)
    param = dist.fit(y_std)
    
    # Get random numbers from distribution
    norm = dist.rvs(*param[0:-2],loc=param[-2], scale=param[-1],size = size)
    norm.sort()
    
    # Create figure
    fig = plt.figure(figsize=(8,5)) 
    
    # qq plot
    ax1 = fig.add_subplot(121) # Grid of 2x2, this is suplot 1
    ax1.plot(norm,data,"o")
    min_value = np.floor(min(min(norm),min(data)))
    max_value = np.ceil(max(max(norm),max(data)))
    ax1.plot([min_value,max_value],[min_value,max_value],'r--')
    ax1.set_xlim(min_value,max_value)
    ax1.set_xlabel('Theoretical quantiles')
    ax1.set_ylabel('Observed quantiles')
    title = pretitle  +'\n qq plot for ' + distribution +' distribution'
    ax1.set_title(title)
    
    # pp plot
    ax2 = fig.add_subplot(122)
    
    # Calculate cumulative distributions
    bins = np.percentile(norm,range(0,101))
    data_counts, bins = np.histogram(data,bins)
    norm_counts, bins = np.histogram(norm,bins)
    cum_data = np.cumsum(data_counts)
    cum_norm = np.cumsum(norm_counts)
    cum_data = cum_data / max(cum_data)
    cum_norm = cum_norm / max(cum_norm)
    
    # plot
    ax2.plot(cum_norm,cum_data,"o")
    min_value = np.floor(min(min(cum_norm),min(cum_data)))
    max_value = np.ceil(max(max(cum_norm),max(cum_data)))
    ax2.plot([min_value,max_value],[min_value,max_value],'r--')
    ax2.set_xlim(min_value,max_value)
    ax2.set_xlabel('Theoretical cumulative distribution')
    ax2.set_ylabel('Observed cumulative distribution')
    title = pretitle +'\n pp plot for ' + distribution +' distribution'
    ax2.set_title(title)
    
    # Display plot    
    plt.tight_layout(pad=4)
    plt.show()
    
    fig.savefig(os.path.join(cwd, 'Figures_TmCstData', 'qqppPlot_'+ fileName), bbox_inches='tight')
#%% STEP 8:
#for index, row in dist_parameters.iterrows():
#    a = row[1][0]
#    b = row[1][1]
#    loc = row[1][2]
#    scale = row[1][3]
#mean, var, skew, kurt = scipy.stats.johnsonsb.stats(a=a, b=b, loc=loc, scale=scale, moments='mvsk')
#median = scipy.stats.johnsonsb.median(a=a, b=b, loc=loc, scale=scale)
#std = scipy.stats.johnsonsb.std(a=a, b=b, loc=loc, scale=scale)     

lower_quartile = float(y_df_stats.iloc[4].values)
upper_quartile = float(y_df_stats.iloc[6].values)
iqr = upper_quartile - lower_quartile
upper_whisker = float(y_df[(y_df<=upper_quartile+1.5*iqr)].max().values)
lower_whisker = float(y_df[(y_df>=lower_quartile-1.5*iqr)].min().values)
cv = float(y_df_stats.iloc[2].values)/float(y_df_stats.iloc[1].values)

print ('\nDistributions sorted by goodness of fit:')
print ('----------------------------------------')
print (results)

# Print parameter results
print ('\nDistribution parameters:')
print ('------------------------')
for index, row in dist_parameters.iterrows():
    print ('\nDistribution:', row[0])
    print ('Parameters:', row[1] )
    
print ('\nSummary of Statistics for Distribution:')
print ('----------------------------------------')
print (y_df_stats)
print ('Geometric Mean:', gmean)
print ('Coefficient of Variation:', cv )
print ('Lower Whisker:', lower_whisker )
print ('Upper Whisker:', upper_whisker )
    
print ('\nSummary of Statistics for Theoretical (Estimated) Distribution:')
print ('----------------------------------------')
print ('\nDistribution:', distribution)
print ('Dist Mean:', mean)
print ('Dist Median:', median)  
print ('Dist Variance:', var)
print ('Dist Standard deviation:', std)
print ('Dist Skewness:', skew)
print ('Dist Kurtosis:', kurt)
print ('Dist Mean lower CL:', ci_lower)
print ('Dist Mean upper CL:', ci_upper)

dStatSum = [['Count', int(y_df_stats.iloc[0].values)],
            ['Arithmetic Mean', float(y_df_stats.iloc[1].values)],
            ['Geometric Mean', gmean],
            ['Standard deviation', float(y_df_stats.iloc[2].values)],
            ['Coefficient of Variation', cv],
            ['Minimum', float(y_df_stats.iloc[3].values)],
            ['Lower Whisker', lower_whisker],
            ['Lower Quartile (25%)', float(y_df_stats.iloc[4].values)],
            ['Median (50%)',float(y_df_stats.iloc[5].values)],
            ['Upper Quartile (75%)', float(y_df_stats.iloc[6].values)],
            ['Upper Whisker', upper_whisker],
            ['Maximum', float(y_df_stats.iloc[7].values)],
            ['Interquartile range (IQR)', iqr],
            ['Dist Name',results.iloc[0,0]],
            ['Dist Mean Lower CL', ci_lower],
            ['Dist Mean', float(mean)],
            ['Dist Mean Upper CL', ci_upper],
            ['Dist Standard deviation', std],
            ['Dist Median', median],
            ['Dist Skewness', float(skew)],
            ['Dist Kurtosis', float(kurt)],
            ['Dist Chi Squared', results.iloc[0,1]],
            ['Dist P Value', results.iloc[0,2]],
            ['Dist a', parameters[0][0]],
            ['Dist b', parameters[0][1]],
            ['Dist loc', parameters[0][2]],
            ['Dist scale', parameters[0][3]]]

StatSummary = pd.DataFrame(data = dStatSum, columns = ['Statistic/Parameter', 'Value'])
StatSummary.to_csv(os.path.join(cwd, 'Figures_TmCstData', 'Stats_'+ fileName[:-4]+'.csv'))

#%% MAIN BODY OF CODE - End
#%% NOTES - Start

#distribution list
#        st.alpha,st.anglit,st.arcsine,st.beta,st.betaprime,st.bradford,st.burr,st.cauchy,st.chi,st.chi2,st.cosine,
#        st.dgamma,st.dweibull,st.erlang,st.expon,st.exponnorm,st.exponweib,st.exponpow,st.f,st.fatiguelife,st.fisk,
#        st.foldcauchy,st.foldnorm,st.frechet_r,st.frechet_l,st.genlogistic,st.genpareto,st.gennorm,st.genexpon,
#        st.genextreme,st.gausshyper,st.gamma,st.gengamma,st.genhalflogistic,st.gilbrat,st.gompertz,st.gumbel_r,
#        st.gumbel_l,st.halfcauchy,st.halflogistic,st.halfnorm,st.halfgennorm,st.hypsecant,st.invgamma,st.invgauss,
#        st.invweibull,st.johnsonsb,st.johnsonsu,st.ksone,st.kstwobign,st.laplace,st.levy,st.levy_l,st.levy_stable,
#        st.logistic,st.loggamma,st.loglaplace,st.lognorm,st.lomax,st.maxwell,st.mielke,st.nakagami,st.ncx2,st.ncf,
#        st.nct,st.norm,st.pareto,st.pearson3,st.powerlaw,st.powerlognorm,st.powernorm,st.rdist,st.reciprocal,
#        st.rayleigh,st.rice,st.recipinvgauss,st.semicircular,st.t,st.triang,st.truncexpon,st.truncnorm,st.tukeylambda,
#        st.uniform,st.vonmises,st.vonmises_line,st.wald,st.weibull_min,st.weibull_max,st.wrapcauchy


#%% NOTES - End
