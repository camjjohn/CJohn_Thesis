Note001.For performing outlier analysis and 
creating the presentation of knowledge
acquired in the metadata and data analysis stages:
- requires csv files saved to in folder 
05-DataAnalysisPt2: ProjN_All_ddmmmyyyy
- save ProjN_All_ddmmmyyyy as ProjN_tmCstData
- use plotDataPresentation.py
- creates bar plots, heat maps, etc.
- files created saved to folders: Figures_Metadata 
and Figures_TmCstData

Note002.For performing the distribution fitting for 
making statistical inferences:
-use distFitData_CzSsn.py
-creates figure saved to folder Figures_TmCstData

