# -*- coding: utf-8 -*-
"""
Created on Wed May 22 17:36:41 2019

@author: Camille John
"""

#%% ASSINGMENT OF LATITUDE, LONGITUDE & TIME ZONE
#%% DOCUMENT SETUP
# Scientific libraries
import numpy as np
# Data analysis libraries
import pandas as pd
# Operating system library
import os
cwd = os.getcwd()
# Time access and conversion library
import time as tm
import datetime 
# Geocoding library
from geopy.geocoders import Nominatim
geolocator = Nominatim(user_agent="my-application")
# Time Zone Identification library
from timezonefinder import TimezoneFinder
tf = TimezoneFinder(in_memory=True) 
 
#%% MAIN BODY OF CODE - Start
#%% STEP 1: INPUTS 
# Create dataframe of meta data referenced
metaData = 'mdProj'
fileName ='CommonIdsProj_201709-201808.csv'

#%% STEP 1: LOAD METADATA FILE
cwd = os.getcwd()  # cwd: current working directory
# Creates dataframe
filePath = os.path.join(cwd, metaData, fileName)
df_md = pd.DataFrame()
df_md = pd.read_csv(filePath)
df_md = df_md[['Country', 'ProvinceState', 'City']].drop_duplicates()
df_md.reset_index(drop = True, inplace=True)
# Create columns
df_md['Latitude'] = np.nan
df_md['Longitude'] = np.nan
df_md['tz'] = np.nan

#%% STEP 2: ASSIGN LATITUDES AND LONGITUDES AND TZ
idx1 = 1
missing = []
starting = tm.time()
for i in df_md.index:
    print ('\n')
    print('Iteration %d of %d started' % (idx1,len(df_md.index)))
    where = [df_md.loc[i,'City'],',',df_md.loc[i, 'ProvinceState'],',',df_md.loc[i, 'Country']]
    location = geolocator.geocode(" ".join(where))
    if location is not None:
        df_md.loc[i, 'Latitude'] = location.latitude
        df_md.loc[i, 'Longitude'] = location.longitude
        tz = tf.timezone_at(lng=location.longitude, lat=location.latitude)
        df_md.loc[i, 'tz'] = tz
    else:
        missing.append(i) 
    print(tm.time() - starting)
    idx1 += 1
#%% STEP 3: SAVE FILE    
df_md.to_csv(os.path.join(cwd, metaData,'cities_LatLongTz.csv'), index = False)  


#%% MAIN BODY OF CODE - End
#%% NOTES
#%% STEP 2: ASSIGN LATITUDES AND LONGITUDES BASED ON IDENTIFIERS
#idx1 = 1
#missing = []
#starting = tm.time()
#for identifier in df_md['Identifier']:
#    print ('\n')
#    print('Identifier %d of %d started' % (idx1,len(df_md['Identifier'])))
#    i = df_md['Identifier'].loc[(df_md['Identifier'] == identifier)].index.values[0]
#    where = [df_md.loc[i, 'City'],',',df_md.loc[i, 'ProvinceState'],',',df_md.loc[i, 'Country']]
#    location = geolocator.geocode(" ".join(where))
#    if location is not None:
#        df_md.loc[i, 'Latitude'] = location.latitude
#        df_md.loc[i, 'Longitude'] = location.longitude
#    else:
#        missing.append(identifier) 
#    print(tm.time() - starting)
#    idx1 += 1
