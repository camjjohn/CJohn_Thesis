# -*- coding: utf-8 -*-
"""
Created on Tue Jan 19 21:30:08 2021

@author: Camille John
"""
#%% RMSE ANALYSIS
#%% DOCUMENT SETUP
# Scientific libraries
import numpy as np
# Data analysis libraries
import pandas as pd
#Visualization Librairies
import matplotlib.pyplot as plt
import seaborn as sns;
sns.set(style="white")
# Operating system library
import os
cwd = os.getcwd()  # cwd: current working directory
# Time access and conversion library
import time as tm

#%% MAIN BODY OF CODE - Start
#%% STEP 1: INPUTS 
Df09 = pd.read_csv(os.path.join(cwd, '60min_2oC_Nb_Tfdiff5', 'colSelProjN_2017-09.csv'))            
Df10 = pd.read_csv(os.path.join(cwd, '60min_2oC_Nb_Tfdiff5', 'colSelProjN_2017-10.csv'))
Df11 = pd.read_csv(os.path.join(cwd, '60min_2oC_Nb_Tfdiff5', 'colSelProjN_2017-11.csv'))
Df12 = pd.read_csv(os.path.join(cwd, '60min_2oC_Nb_Tfdiff5', 'colSelProjN_2017-12.csv'))
Df01 = pd.read_csv(os.path.join(cwd, '60min_2oC_Nb_Tfdiff5', 'colSelProjN_2018-01.csv'))
Df02 = pd.read_csv(os.path.join(cwd, '60min_2oC_Nb_Tfdiff5', 'colSelProjN_2018-02.csv'))
Df03 = pd.read_csv(os.path.join(cwd, '60min_2oC_Nb_Tfdiff5', 'colSelProjN_2018-03.csv'))
Df04 = pd.read_csv(os.path.join(cwd, '60min_2oC_Nb_Tfdiff5', 'colSelProjN_2018-04.csv'))
Df05 = pd.read_csv(os.path.join(cwd, '60min_2oC_Nb_Tfdiff5', 'colSelProjN_2018-05.csv'))
Df06 = pd.read_csv(os.path.join(cwd, '60min_2oC_Nb_Tfdiff5', 'colSelProjN_2018-06.csv'))
Df07 = pd.read_csv(os.path.join(cwd, '60min_2oC_Nb_Tfdiff5', 'colSelProjN_2018-07.csv'))
Df08 = pd.read_csv(os.path.join(cwd, '60min_2oC_Nb_Tfdiff5', 'colSelProjN_2018-08.csv'))

#Join all months together
frames = [Df09, Df10, Df11, Df12, Df01, Df02, Df03, Df04, Df05, Df06, Df07, Df08]
fullYear= pd.concat(frames)
                    
#%% STEP 2:  SELECT ROWS USED FOR ANALYSIS OF ALL DWELLINGS

fullYear05 = fullYear[(fullYear['rmse']<= 0.5)]
fullYear05_1hr = fullYear05[(fullYear05["tauMeas_hr"]>=1)]
fullYear05_1hr_tau3=fullYear05_1hr[(fullYear05_1hr["tauBldg_hr_optim"]>=3) & (fullYear05_1hr["tauBldg_hr_optim"]<=240)  & (fullYear05_1hr["tauMeas_hr"]<18.)]
len(fullYear05_1hr_tau3['Identifier'].unique())


f01 = plt.figure(figsize=(6,3))
f01 =sns.distplot(fullYear05_1hr_tau3["rmse"], hist=True, kde=False, bins=50,
                  hist_kws={"color": "b"})
f01.set_xlabel(r'RMSE [$^\circ$C]')
f01.set_ylabel('Number of Analysis Periods')
f01.get_figure().savefig(os.path.join(cwd, 'Figures', 'rmse05_tau3_rmseCount.png'),dpi=400,
#               transparent = 'true'
           bbox_inches='tight')

fullYear05_1hr_tau3["rmse"]. describe()
upper_quartile = np.percentile(fullYear05_1hr_tau3["rmse"], 75)
lower_quartile = np.percentile(fullYear05_1hr_tau3["rmse"], 25)
iqr = upper_quartile - lower_quartile
upper_whisker = fullYear05_1hr_tau3["rmse"][(fullYear05_1hr_tau3["rmse"]<=upper_quartile+1.5*iqr)].max()
lower_whisker = fullYear05_1hr_tau3["rmse"][(fullYear05_1hr_tau3["rmse"]>=lower_quartile-1.5*iqr)].min()


f02 = plt.figure(figsize=(6,3))
f02 =sns.distplot(fullYear05_1hr_tau3["tauBldg_hr_optim"], hist=True, kde=False, bins=50,
                  hist_kws={"color": "b"})
f02.set_xlabel(r'$\tau_{j,k}$ [hours]')
f02.set_ylabel('Number of Analysis Periods')
f02.get_figure().savefig(os.path.join(cwd, 'Figures', 'rmse05_tau3_tauCount.png'),dpi=400,
#               transparent = 'true'
           bbox_inches='tight')

fullYear05_1hr_tau3["tauBldg_hr_optim"]. describe()
upper_quartile = np.percentile(fullYear05_1hr_tau3["tauBldg_hr_optim"], 75)
lower_quartile = np.percentile(fullYear05_1hr_tau3["tauBldg_hr_optim"], 25)
iqr = upper_quartile - lower_quartile
upper_whisker = fullYear05_1hr_tau3["tauBldg_hr_optim"][(fullYear05_1hr_tau3["tauBldg_hr_optim"]<=upper_quartile+1.5*iqr)].max()
lower_whisker = fullYear05_1hr_tau3["tauBldg_hr_optim"][(fullYear05_1hr_tau3["tauBldg_hr_optim"]>=lower_quartile-1.5*iqr)].min()


f03 = plt.figure(figsize=(8,2))
f03 =sns.boxplot(x=fullYear05_1hr_tau3["tauMeas_hr"], palette= sns.set_palette(['lightsteelblue']), showmeans=True, meanprops={"marker":"o",
                                                       "markerfacecolor":"white", 
                                                       "markeredgecolor":"black",
                                                       "markersize":"7"},)
f03.set_xlabel('Analysis Period Duration [hours]')
# f03.set_xlim(0, 20)
f03.get_figure().savefig(os.path.join(cwd, 'Figures', 'rmse05_tau3_DistPeriodDuration.png'),dpi=400,
#               transparent = 'true'
           bbox_inches='tight')

fullYear05_1hr_tau3["tauMeas_hr"].describe()
upper_quartile = np.percentile(fullYear05_1hr_tau3["tauMeas_hr"], 75)
lower_quartile = np.percentile(fullYear05_1hr_tau3["tauMeas_hr"], 25)
iqr = upper_quartile - lower_quartile
upper_whisker = fullYear05_1hr_tau3["tauMeas_hr"][(fullYear05_1hr_tau3["tauMeas_hr"]<=upper_quartile+1.5*iqr)].max()
lower_whisker = fullYear05_1hr_tau3["tauMeas_hr"][(fullYear05_1hr_tau3["tauMeas_hr"]>=lower_quartile-1.5*iqr)].min()

#%% STEP 3:  SELECT ROWS USED FOR ANALYSIS OF SFR DWELLINGS

fullYearSFR = fullYear[(fullYear['Dwelling Classification']== 'Single-Family Residential')]
fullYearSFR05 = fullYearSFR[(fullYearSFR['rmse']<= 0.5)]
fullYearSFR05_1hr = fullYearSFR05[(fullYearSFR05["tauMeas_hr"]>=1)]
fullYearSFR05_1hr_tau3=fullYearSFR05_1hr[(fullYearSFR05_1hr["tauBldg_hr_optim"]>=3) & (fullYearSFR05_1hr["tauBldg_hr_optim"]<=240)]
len(fullYearSFR05_1hr_tau3['Identifier'].unique())

f01 = plt.figure(figsize=(8,4))
f01 =sns.distplot(fullYearSFR05_1hr_tau3["rmse"], hist=True, kde=False, bins=50,
                  hist_kws={"color": "b"})
f01.set_xlabel(r'RMSE [$^\circ$C]')
f01.set_ylabel('Number of Analysis Periods')
f01.get_figure().savefig(os.path.join(cwd, 'Figures', 'SFR_rmse05_tau3_rmseCount.png'),
#               transparent = 'true'
           )

f02 = plt.figure(figsize=(8,4))
f02 =sns.distplot(fullYearSFR05_1hr_tau3["tauBldg_hr_optim"], hist=True, kde=False, bins=50,
                  hist_kws={"color": "b"})
f02.set_xlabel(r'Time Constant, $\tau$ [hours]')
f02.set_ylabel('Number of Analysis Periods')
f02.get_figure().savefig(os.path.join(cwd, 'Figures', 'SFR_rmse05_tau3_tauCount.png'),
#               transparent = 'true'
           )

f03 = plt.figure(figsize=(8,2))
f03 =sns.boxplot(fullYearSFR05_1hr_tau3["tauMeas_hr"], palette='muted')
f03.set_xlabel('Length of Analysis Periods [hours]')
f03.set_xlim(0, 20)
f03.get_figure().savefig(os.path.join(cwd, 'Figures', 'SFR_rmse05_tau3_PeriodLengthCount.png'),
#               transparent = 'true'
           )

#%% STEP 4:  SELECT ROWS USED FOR ANALYSIS OF MFR DWELLINGS
fullYearMFR = fullYear[(fullYear['Dwelling Classification']== 'Multi-Family Residential')]
fullYearMFR05 = fullYearMFR[(fullYearMFR['rmse']<= 0.5)]
fullYearMFR05_1hr = fullYearMFR05[(fullYearMFR05["tauMeas_hr"]>=1)]
fullYearMFR05_1hr_tau3=fullYearMFR05_1hr[(fullYearMFR05_1hr["tauBldg_hr_optim"]>=3) & (fullYearMFR05_1hr["tauBldg_hr_optim"]<=240)]
len(fullYearMFR05_1hr_tau3['Identifier'].unique())

sns.color_palette("pastel")
f01 = plt.figure(figsize=(8,4))
f01 =sns.distplot(fullYearMFR05_1hr_tau3["rmse"], hist=True, kde=False, bins=50,
                  hist_kws={"color": "b"})
f01.set_xlabel(r'RMSE [$^\circ$C]')
f01.set_ylabel('Number of Analysis Periods')
f01.get_figure().savefig(os.path.join(cwd, 'Figures', 'MFR_rmse05_tau3_rmseCount.png'),
#               transparent = 'true'
           )

f02 = plt.figure(figsize=(8,4))
f02 =sns.distplot(fullYearMFR05_1hr_tau3["tauBldg_hr_optim"], hist=True, kde=False, bins=50,
                  hist_kws={"color": "b"})
f02.set_xlabel(r'Time Constant, $\tau$ [hours]')
f02.set_ylabel('Number of Analysis Periods')
f02.get_figure().savefig(os.path.join(cwd, 'Figures', 'MFR_rmse05_tau3_tauCount.png'),
#               transparent = 'true'
           )

f03 = plt.figure(figsize=(8,2))
f03 =sns.boxplot(fullYearMFR05_1hr_tau3["tauMeas_hr"], palette='muted')
f03.set_xlabel('Length of Analysis Periods [hours]')
f03.set_xlim(0, 20)
f03.get_figure().savefig(os.path.join(cwd, 'Figures', 'MFR_rmse05_tau3_PeriodLengthCount.png'),
#               transparent = 'true'
           )


#%% MAIN BODY OF CODE - End
#%% NOTES - Start  

# f03 = plt.figure(figsize=(8,4))
# f03 =sns.distplot(fullYearSFR05_1hr_tau3["tauMeas_hr"], hist=True, kde=False, bins=35)
# f03.set_xlabel('Length of Analysis Periods [hours]')
# f03.set_ylabel('Number of Analysis Periods')

# f04 = sns.JointGrid(data=fullYearSFR05_1hr_tau3, x="rmse", y="tauMeas_hr")
# f04.plot_joint(sns.histplot)
# f04.plot_marginals(sns.boxplot)
# f04.set_axis_labels(xlabel=r'RMSE [$^\circ$C]', ylabel='Length of Analysis Periods [hours]')


# f04 = sns.JointGrid(data=fullYearSFR05_1hr_tau3, x="rmse", y="tauBldg_hr_optim")
# f04.plot_joint(sns.histplot)
# f04.plot_marginals(sns.boxplot)
# f04.set_axis_labels(xlabel=r'RMSE [$^\circ$C]', ylabel=r'Time Constant, $\tau$ [hours]')

# f05 = sns.JointGrid(data=fullYearSFR05_1hr_tau3, x="tauMeas_hr", y="tauBldg_hr_optim")
# f05.plot_joint(sns.histplot)
# f05.plot_marginals(sns.boxplot)
# f05.set_axis_labels(xlabel='Length of Analysis Periods [hours]', ylabel=r'Time Constant, $\tau$ [hours]')

# f06 = plt.figure(figsize=(8,4))
# f06 =sns.catplot(x="yyyy_mm", y="tauBldg_hr_optim", kind='box', data=fullYearSFR05_1hr_tau3)
# f06.set_xlabel(r'Year-Month')
# f06.set_ylabel(r'Time Constant, $\tau$ [hours]')


#%% NOTES - End