Note001. For creating a analysis dataframe used in 
the analysis of the analysis periods as well as their 
durations, associated RMSEs, and associated TTCs:
- requires file mdProj.csv from folder 
02-MetadataAnalysis
- requires data files (eg: timeCstProjN_yyyy-mm_a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1.csv)
from the monthly folders in folder 03-TimeCstEstimationNb
- use rmseDataframe.py and functions_rmseDataframe.py
- files created saved to folder 
03-DataAnalysisPt1/60min_2oC_Nb_Tfdiff5

Note002. For analyzing the durations, associated RMSEs, 
associated TTCs of the analysis periods the duration of 
analysis periods:
- requires csv files from folder 
03-DataAnalysisPt1/60min_2oC_Nb_Tfdiff5
titled "colSelProjN_YYYY-MM.csv"
- use rmseAnalysis.py
- files created saved to folder 03-DataAnalysisPt1/Figures



