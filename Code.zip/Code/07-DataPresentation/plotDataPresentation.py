# -*- coding: utf-8 -*-
"""
Created on Sun May 10 13:43:46 2020

@author: Camille John
"""

#%% PLOT DATA PRESENTATION
#%% DOCUMENT SETUP
import pandas as pd
import numpy as np
import scipy
from sklearn.preprocessing import StandardScaler
import scipy.stats as st
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from sklearn import datasets
import os
import seaborn as sns
sns.set(style="white")
cwd = os.getcwd()  # cwd: current working directory
import warnings
warnings.filterwarnings("ignore")

#%% CUSTOM FUNCTIONS
# sum up number o missing outputs    
def NumMissingInput(x):
  return sum(x.isnull())

# remove outliers
def remove_outlier(df_in, col_name):
    q1 = df_in[col_name].quantile(0.25)
    q3 = df_in[col_name].quantile(0.75)
    iqr = q3-q1 #Interquartile range
    fence_low  = q1-1.5*iqr
    fence_high = q3+1.5*iqr
    df_out = df_in.loc[(df_in[col_name] > fence_low) & (df_in[col_name] < fence_high)]
    return df_out

#%% MAIN BODY OF CODE - Start
#%% STEP 0: Pre-prepared Dataframe Creation - Run the first time only

# df_md = pd.read_csv(os.path.join(cwd,'..','02-MetadataAnalysis','mdProj','CommonIdsProj_201709-201808.csv'))
# df_md.set_index(['Identifier'], inplace = True)

# df_md['Building Footprint [m2]'] = np.nan
# df_md['Building Footprint [m2]'] = df_md['Floor Area [m2]'] / df_md['Number of Floors']

# p_inf = float("inf")
# df_md['Floor Area Interval [m2]'] = np.nan
# bins1 = pd.IntervalIndex.from_tuples(data=[(0, 150), (150, 300), (300, p_inf)])
# df_md['Floor Area Interval [m2]'] = pd.cut(df_md['Floor Area [m2]'], bins= bins1)

# p_inf = float("inf")
# df_md['Floor Area Interval3 [m2]'] = np.nan
# bins1 = pd.IntervalIndex.from_tuples(data=[(0, 150), (150, 200), (200, 250), (250, 300), (300, 350), (350, p_inf)])
# df_md['Floor Area Interval3 [m2]'] = pd.cut(df_md['Floor Area [m2]'], bins= bins1)

# df_md['Age of Home Interval [years]'] = np.nan
# bins2 = pd.IntervalIndex.from_tuples([(0, 3), (3, 8), (8, 13), (13, 18), (18, 28), (28, 38), (38, 58), (58, p_inf)], closed='left')
# df_md['Age of Home Interval [years]'] = pd.cut(x= df_md['Age of Home [years]'], bins= bins2, include_lowest=True)
   
# p_inf = float("inf")
# df_md['Floor Area Interval2 [m2]'] = np.nan
# bins1 = pd.IntervalIndex.from_tuples(data=[(0, 100), (100, 250), (250, 400), (400, p_inf)])
# df_md['Floor Area Interval2 [m2]'] = pd.cut(df_md['Floor Area [m2]'], bins= bins1)

# df_md['Age of Home Interval2 [years]'] = np.nan
# bins2 = pd.IntervalIndex.from_tuples([(0, 10), (10, 20), (20, p_inf)], closed='left')
# df_md['Age of Home Interval2 [years]'] = pd.cut(x= df_md['Age of Home [years]'], bins= bins2, include_lowest=True)

# df_md['Dwelling Classification']= np.nan
# df_md.loc[(df_md['Style'] == 'Detached'), 'Dwelling Classification'] = 'Single-Family Residential'
# df_md.loc[(df_md['Style'] != 'Detached') & (df_md['Style'].notnull()), 'Dwelling Classification'] = 'Multi-Family Residential'
            
# df_md.to_csv(os.path.join(cwd,'ProjN_metaData_o.csv'))

# df_o = pd.read_csv(os.path.join(cwd,'..','06-DataAnalysisPt3','60min_2oC_Nb_Tfdiff5', 'ProjN_All_26Jan2021.csv'))
# df_o['Floor Area [m2]'] = np.nan
# df_o['Number of Floors'] = np.nan
# df_o['Age of Home [years]'] = np.nan
# df_o.rename(columns={"AreaPerLevel": "Building Footprint [m2]"}, inplace=True)
# df_o['Building Footprint [m2]'] = np.nan
# df_o.set_index('Identifier', inplace= True)

# df_o.reset_index(inplace=True) 
# # for ind in df_o.index:
# #         df_o.loc[ind, 'Age of Home [years]'] = df_md.loc[df_md['Identifier'] == df_o.loc[ind,'Identifier'], 
# #                       'Age of Home [years]'].values
# #         df_o.loc[ind, 'Floor Area [m2]'] = df_md.loc[df_md['Identifier'] == df_o.loc[ind,'Identifier'], 
# #                       'Floor Area [m2]'].values
# #         df_o.loc[ind, 'Number of Floors'] = df_md.loc[df_md['Identifier'] == df_o.loc[ind,'Identifier'], 
# #                       'Number of Floors'].values
# #         df_o.loc[ind, 'Building Footprint [m2]'] = df_md.loc[df_md['Identifier'] == df_o.loc[ind,'Identifier'], 
# #                       'Building Footprint [m2]'].values

# # df_o.rename(columns={"AreaPerLevel": "Building Footprint [m2]"}, inplace=True)
  
   
# # p_inf = float("inf")
# # df_o['Floor Area Interval [m2]'] = np.nan
# # bins1 = pd.IntervalIndex.from_tuples(data=[(0, 150), (150, 300), (300, p_inf)]) 
# # df_o['Floor Area Interval [m2]'] = pd.cut(df_o['Floor Area [m2]'], bins= bins1)

# # p_inf = float("inf")
# # df_o['Floor Area Interval3 [m2]'] = np.nan
# # bins1 = pd.IntervalIndex.from_tuples(data=[(0, 150), (150, 200), (200, 250), (250, 300), (300, 350), (350, p_inf)])
# # df_o['Floor Area Interval3 [m2]'] = pd.cut(df_o['Floor Area [m2]'], bins= bins1)

# # df_o['Age of Home Interval [years]'] = np.nan
# # bins2 = pd.IntervalIndex.from_tuples([(0, 3), (3, 8), (8, 13), (13, 18), (18, 28), (28, 38), (38, 58), (58, p_inf)], closed='left')
# # df_o['Age of Home Interval [years]'] = pd.cut(x= df_o['Age of Home [years]'], bins= bins2, include_lowest=True)
        
# # p_inf = float("inf")
# # df_o['Floor Area Interval2 [m2]'] = np.nan
# # bins1 = pd.IntervalIndex.from_tuples(data=[(0, 100), (100, 250), (250, 400), (400, p_inf)])
# # df_o['Floor Area Interval2 [m2]'] = pd.cut(df_o['Floor Area [m2]'], bins= bins1)

# # df_o['Age of Home Interval2 [years]'] = np.nan
# # bins2 = pd.IntervalIndex.from_tuples([(0, 10), (10, 20), (20, p_inf)], closed='left')
# # df_o['Age of Home Interval2 [years]'] = pd.cut(x= df_o['Age of Home [years]'], bins= bins2, include_lowest=True)

# # seasonAssign = pd.DataFrame({
# #             'Year_Month': ['2015-09', '2015-10', '2015-11', '2015-12', '2016-01', '2016-02', #0-5
# #                           '2016-03', '2016-04', '2016-05', '2016-06', '2016-07', '2016-08', #6-11
# #                           '2016-09', '2016-10', '2016-11', '2016-12', '2017-01', '2017-02', #12-17
# #                           '2017-03', '2017-04', '2017-05', '2017-06', '2017-07', '2017-08', #18-23
# #                           '2017-09', '2017-10', '2017-11', '2017-12', '2018-01', '2018-02', #24-29
# #                           '2018-03', '2018-04', '2018-05', '2018-06', '2018-07', '2018-08'], #30-35
# # #            'Season': ['Cooling', 'Shoulder', 'Shoulder', 'Heating', 'Heating', 'Heating', 
# # #                       'Heating', 'Shoulder', 'Shoulder', 'Cooling', 'Cooling', 'Cooling',
# # #                       'Cooling', 'Shoulder', 'Shoulder', 'Heating', 'Heating', 'Heating', 
# # #                       'Heating', 'Shoulder', 'Shoulder', 'Cooling', 'Cooling', 'Cooling',
# # #                       'Cooling', 'Shoulder', 'Shoulder', 'Heating', 'Heating', 'Heating', 
# # #                       'Heating', 'Shoulder', 'Shoulder', 'Cooling', 'Cooling', 'Cooling'],
# #             'Season': ['Fall', 'Fall', 'Fall', 'Winter', 'Winter', 'Winter', 
# #                       'Spring', 'Spring', 'Spring', 'Summer', 'Summer', 'Summer',
# #                       'Fall', 'Fall', 'Fall', 'Winter', 'Winter', 'Winter', 
# #                       'Spring', 'Spring', 'Spring', 'Summer', 'Summer', 'Summer',                       
# #                       'Fall', 'Fall', 'Fall', 'Winter', 'Winter', 'Winter', 
# #                       'Spring', 'Spring', 'Spring', 'Summer', 'Summer', 'Summer'],                       
# #                       })
# # df_o['Season'] = np.nan  
# # for ind in df_o.index:
# #         df_o.loc[ind, 'Season'] = seasonAssign.loc[seasonAssign['Year_Month'] == df_o.loc[ind,'Year_Month'], 
# #                       'Season'].values 
   
# # df_o['Dwelling Classification']= np.nan
# # df_o.loc[(df_o['Style'] == 'Detached'), 'Dwelling Classification'] = 'Single-Family Residential'
# # df_o.loc[(df_o['Style'] != 'Detached') & (df_o['Style'].notnull()), 'Dwelling Classification'] = 'Multi-Family Residential'
      
# # df_o.to_csv(os.path.join(cwd, 'ProjN_tmCstData_o.csv'))
   
#%% STEP 1: Load Pre-prepared datasets - Run after only after running STEP 0 at least once
#Load cleaned and explanded meta data    
df_md = pd.read_csv(os.path.join(cwd,'ProjN_metaData_o.csv'))    
#  Load time constant data
df_o = pd.read_csv(os.path.join(cwd, 'ProjN_tmCstData_o.csv'))

#%% STEP 2: Data Preparation Pt1

# Age and Floor Intervals

# By Climate Zone
df_cz1_o = df_o[(df_o['Climate Zone']== 1)]
df_cz2_o = df_o[(df_o['Climate Zone']== 2)]
df_cz3_o = df_o[(df_o['Climate Zone']== 3)]
df_cz4_o = df_o[(df_o['Climate Zone']== 4)]
df_cz5_o = df_o[(df_o['Climate Zone']== 5)]
df_cz6_o = df_o[(df_o['Climate Zone']== 6)]
df_cz7_o = df_o[(df_o['Climate Zone']== 7)]
df_cz8_o = df_o[(df_o['Climate Zone']== 8)]


#%% STEP 3: ORIGINAL METADATA DESCRIPTION

# # Check out info of dataframe
# print ('\n')
# print ('\n')
# print ("+ ORIGINAL METADATA DATAFRAME:")
# print ('\n')
# df_md.info()
# print ('\n')
# df_md_stats = df_md.describe()
# #Applying per column:
# print ("No. of Missing Inputs per column:")
# print (df_md.apply(NumMissingInput, axis=0)) #axis=0 defines that function is to be applied on each column
# ##Applying per row:
# #print "\n No. of Missing Inputs per row:"
# #print df_md.apply(NumMissingInput, axis=1) #axis=1 defines that function is to be applied on each row# Column  0: 'Identifier'
# print ('\n')


# print('Total number of residences in sample study: %d' %(len(df_md.index)))
# print ('\n')
# print('The mode of climate zone: %8.2f' %(df_md['Climate Zone'].mode()))
# print ('\n')
# print('The mode of floor area: %8.2f' %(df_md['Floor Area [m2]'].mode()))
# print ('\n')
# print('The mode of Style: %s' %(df_md['Style'].mode()))
# print ('\n')
# print('The mode of number of floors: %8.2f' %(df_md['Number of Floors'].mode()))
# print ('\n')
# print('The mode of age of home: %8.2f' %(df_md['Age of Home [years]'].mode()))
# print ('\n')
# print('The mode of number of occupants: %8.2f' %(df_md['Number of Occupants'].mode()))
# print ('\n')

#%% STEP 4: ORIGINAL DATA DESCRIPTION

# Check out info of dataframe
print ('\n')
print ('\n')
print ("+ ORIGINAL DATA DATAFRAME:")
print ('\n')
df_o.info()
print ('\n')
df_o_stats = df_o.describe()
#Applying per column:
print ("No. of Missing Inputs per column:")
print (df_o.apply(NumMissingInput, axis=0)) #axis=0 defines that function is to be applied on each column
##Applying per row:
#print "\n No. of Missing Inputs per row:"
#print df_o.apply(NumMissingInput, axis=1) #axis=1 defines that function is to be applied on each row# Column  0: 'Identifier'
print ('\n')


print('Total number of monthly TCC averages: %d' %(len(df_o.index)))
print ('\n')


#%% MD FIG 1: BAR PLOT - Clean Ecobee Metadata - Count by all Climate

# #df_md['Climate Zone'][(df_md['Country'] =='CA')].value_counts().sort_values()
# #df_md['Climate Zone'][(df_md['Country']== 'US')].value_counts().sort_values()
# df_plt1 = pd.DataFrame(data = np.array([[0.,0.,0.,0.,127.,2193.,331.,0.],
#                                          [353.,2461.,4297.,2624.,2662.,293.,20.,2.]]), 
#                         index = ['Canada', 'USA'],
#                         columns = ['1', '2', '3', '4', '5', '6', '7', '8'])
# pal1 = sns.color_palette("Blues_r", 2)
# fig1 = plt.figure(figsize=(7.,3.75))
# ax1 = fig1.add_subplot(111)   
# df_plt1.T.plot(kind='bar', colormap=ListedColormap(pal1), width=.9, ax=ax1)
# for bar in ax1.patches:
#     ax1.annotate('{:.0f}'.format(bar.get_height()), 
#                 xy=(bar.get_x() + bar.get_width()/2, bar.get_height()), 
#                 xytext= (0,1), 
#                 textcoords='offset points', 
#                 ha='center', va='bottom')
# plt.xticks(rotation= 0)
# plt.xlabel('Climate Zone')
# plt.ylabel('Number of Dwellings')
# plt.legend(title='Country')
# #plt.title('Study Sample: Dwellings by Country and Climate Zone')
# plt.tight_layout()
# sns.despine(fig=fig1)
# fig1.savefig(os.path.join(cwd,'Figures_Metadata','barPlt_Dw_CountVsCzByCountry.png'), dpi=400,
# #       transparent = 'true'
#     )

      
 #%%  MD FIG 2: BAR PLOT/ HEATMAP - Clean Ecobee Metadata - Count by all Climate and one SUB Style
 
# #df_md['Climate Zone'][(df_md['Style']== 'Detached')].value_counts().sort_values()
# df_plt2 = pd.DataFrame(data = np.array([[193., 1606., 2924., 1750., 1771., 1537., 272., 2.]]), 
#                         index = ['Detached'],
#                         columns = ['1', '2', '3', '4', '5', '6', '7', '8']) 
 
# pal2 = sns.color_palette("Blues_r", 2)
# fig2 = plt.figure(figsize=(5.75,3.75))
# ax2 = fig2.add_subplot(111)   
# df_plt2.T.plot(kind='bar', colormap=ListedColormap(pal2), width=.9, ax=ax2)
# for bar in ax2.patches:
#     ax2.annotate('{:.0f}'.format(bar.get_height()), 
#                 xy=(bar.get_x() + bar.get_width()/2, bar.get_height()), 
#                 xytext= (0,1), 
#                 textcoords='offset points', 
#                 ha='center', va='bottom')
# plt.xticks(rotation= 0)
# plt.xlabel('Climate Zone')
# plt.ylabel('Number of Dwellings')
# plt.legend(title='Dwelling Type')
# #plt.title('Study Sample: Single-family Residential \n by Dwelling Type and Climate Zone')
# plt.tight_layout()
# sns.despine(fig=fig2)
# fig2.savefig(os.path.join(cwd,'Figures_Metadata','barPlt_subDw_CountVsCzByType.png'), dpi=400,
# #       transparent = 'true'
#     )


#%% MD FIG 3: HEATMAP - Clean Ecobee Metadata - Count by all Climate and all MUB Styles

# styles_long = df_md[['Style', 'Climate Zone']]
# styles_long = styles_long.groupby(['Style', 'Climate Zone']).size().reset_index().rename(columns={0:'count'})
# styles = styles_long.pivot('Style', 'Climate Zone', 'count').fillna(0)
# df_plt3 = styles[(styles.index != 'Detached')]
# fig3, ax3 = plt.subplots(figsize=(6.5,3.75))
# sns.heatmap(df_plt3, annot=True, fmt="g", linewidths=.5, ax=ax3, cmap='YlGnBu', cbar_kws={'label': 'Number of Dwellings'})
# ax3.set_xticklabels(['1', '2', '3', '4', '5', '6', '7', '8'])
# plt.ylabel('Dwelling Type')
# #plt.title('Study Sample: Multi-Family Residential \n  by Dwelling Type and Climate Zone')
# plt.tight_layout()
# sns.despine(fig=fig3)
# fig3.savefig(os.path.join(cwd,'Figures_Metadata','heatMap_mubDw_CountVsCzByType' +'.png'), dpi=400,
#     #           transparent = 'true'
#                 )


 #%%  MD FIG 4: HEATMAP - Clean Ecobee Metadata - Count by all Age

# ages_long = df_md[['Age of Home Interval [years]', 'Climate Zone']]
# ages_long = ages_long.groupby(['Age of Home Interval [years]', 'Climate Zone']).size().reset_index().rename(columns={0:'count'})
# df_plt4 = ages_long.pivot('Age of Home Interval [years]', 'Climate Zone', 'count').fillna(0)
# fig4, ax4 = plt.subplots(figsize=(6.5,3.75))
# yticklabels=['2016-2018','2011-2015', '2006-2010', '2001-2005','1991-2000','1981-1990', '1961-1980', '  <= 1960']
# sns.heatmap(df_plt4, annot=True, fmt="g", linewidths=.5, ax=ax4, cmap='YlGnBu', yticklabels=yticklabels, cbar_kws={'label': 'Number of Dwellings'})
# ax4.set_xticklabels(['1', '2', '3', '4', '5', '6', '7', '8'])
# plt.ylabel('Year of Construction')
# #plt.title('Study Sample: \n Dwellings by Year of Construction and Climate Zone')
# plt.tight_layout()
# plt.show() 
# sns.despine(fig=fig4)
# fig4.savefig(os.path.join(cwd,'Figures_Metadata','heatMap_Dw_CountVsCzByAge' +'.png'),  dpi=400,
#     #           transparent = 'true'
#                 )

#%% MD FIG 5: HEATMAP - Clean Ecobee Metadata - Count by all Area

# floorArea_long = df_md[['Floor Area Interval [m2]', 'Climate Zone']]
# floorArea_long = floorArea_long.groupby(['Floor Area Interval [m2]', 'Climate Zone']).size().reset_index().rename(columns={0:'count'})
# df_plt5  = floorArea_long.pivot('Floor Area Interval [m2]', 'Climate Zone', 'count').fillna(0)
# fig5, ax5 = plt.subplots(figsize=(6.5,3.75))
# #yticklabels=['[0,150]','(150,200]', '(200,250]', '(250,300]','(300,350]','(350,inf]']
# sns.heatmap(df_plt5, annot=True, fmt="g", linewidths=.5, ax=ax5, cmap='YlGnBu', cbar_kws={'label': 'Number of Dwellings'})
# ax5.set_xticklabels(['1', '2', '3', '4', '5', '6', '7', '8'])
# plt.ylabel('Floor Area [sq.m.]')
# #plt.title('Study Sample: \n Dwellings by Floor Area and Climate Zone')
# plt.tight_layout()
# sns.despine(fig=fig5)
# fig5.savefig(os.path.join(cwd,'Figures_Metadata','heatMap_Dw_CountVsCzByArea' +'.png'), dpi=400,
#     #           transparent = 'true'
#                 )

#%% MD FIG 6: BAR PLOT - Clean Ecobee Metadata - Count by Number of Floors and one SUB Style

# Nbrfloors_long = df_md[['Number of Floors', 'Style']]
# Nbrfloors_long = Nbrfloors_long.groupby(['Number of Floors', 'Style']).size().reset_index().rename(columns={0:'count'})
# df_plt6  = Nbrfloors_long[(Nbrfloors_long['Style'] == 'Detached')].pivot('Number of Floors', 'Style', 'count').fillna(0)
# pal6 = sns.color_palette("Blues_r", 2)
# fig6 = plt.figure(figsize=(5.75,3.75))
# ax6 = fig6.add_subplot(111)  
# df_plt6.plot(kind='bar', colormap=ListedColormap(pal6), width=.6, ax=ax6)
# for bar in ax6.patches:
#     ax6.annotate('{:.0f}'.format(bar.get_height()), 
#                 xy=(bar.get_x() + bar.get_width()/2, bar.get_height()), 
#                 xytext= (0,1), 
#                 textcoords='offset points', 
#                 ha='center', va='bottom')
# ax6.set_xticklabels(['1', '2', '3', '4'])
# plt.xticks(rotation= 0)
# plt.xlabel('Climate Zone')
# plt.ylabel('Number of Dwellings')
# plt.legend(title='Dwelling Type')
# #plt.title('Study Sample: Single-family Residential  \n by Dwelling Type and Number of Floors')
# plt.tight_layout()
# sns.despine(fig=fig6)
# fig6.savefig(os.path.join(cwd,'Figures_Metadata','barPlt_subDw_CountVsNbrFloorsByType' +'.png'), dpi=400,
#     #           transparent = 'true'
#                 )
# ##Heat Map Option
# #Nbrfloors_long = df_md[['Number of Floors', 'Style']]
# #Nbrfloors_long = Nbrfloors_long.groupby(['Number of Floors', 'Style']).size().reset_index().rename(columns={0:'count'})
# #df_plt6  = Nbrfloors_long[(Nbrfloors_long['Style'] == 'Detached')].pivot('Number of Floors', 'Style', 'count').fillna(0)
# #fig6, ax6 = plt.subplots(figsize=(7.5,3.5))
# ##yticklabels=['1', '2', '3', '4']
# #sns.heatmap(df_plt6, annot=True, fmt="g", linewidths=.5, ax=ax6, cmap='YlGnBu', cbar_kws={'label': 'Number of Dwellings'})
# #plt.title('Study Sample: \n Dwellings by Style and Number of Floors')
# #plt.ylabel('Number of Floors')
# #plt.tight_layout()
# #sns.despine(fig=fig6)
# #fig6.savefig(os.path.join(cwd,'Figures_Metadata','heatMap_subDwellings_CountVsNbrFloorsByStyle' +'.png'), dpi=400,
# #    #           transparent = 'true'
# #                )

#%% MD FIG 7: HEATMAP - Clean Ecobee Metadata - Count by Number of Floors and MUB Syle
# Nbrfloors_long = df_md[['Number of Floors', 'Style']]
# Nbrfloors_long = Nbrfloors_long.groupby(['Number of Floors', 'Style']).size().reset_index().rename(columns={0:'count'})
# df_plt7  = Nbrfloors_long[(Nbrfloors_long['Style'] != 'Detached')].pivot('Number of Floors', 'Style', 'count').fillna(0)
# fig7, ax7 = plt.subplots(figsize=(6.5,3.75))
# sns.heatmap(df_plt7.T, annot=True, fmt="g", linewidths=.5, ax=ax7, cmap='YlGnBu',  xticklabels=['1', '2', '3', '4'], cbar_kws={'label': 'Number of Dwellings'})
# plt.ylabel('Dwelling Type')
# #plt.title('Study Sample: Multi-Family Residential \n by Dwelling Type and Number of Floors')
# plt.tight_layout()
# sns.despine(fig=fig7)
# fig7.savefig(os.path.join(cwd,'Figures_Metadata','heatMap_mubDw_CountVsNbrFloorsByType' +'.png'), dpi=400,
#     #           transparent = 'true'
#                 )
 

#%% STEP 5: Data Preparation Pt2

# Outlier removal
df_cz1 = remove_outlier(df_cz1_o, 'tauWtdMeanRmse0.5')
df_cz2 = remove_outlier(df_cz2_o, 'tauWtdMeanRmse0.5')
df_cz3 = remove_outlier(df_cz3_o, 'tauWtdMeanRmse0.5')
df_cz4 = remove_outlier(df_cz4_o, 'tauWtdMeanRmse0.5')
df_cz5 = remove_outlier(df_cz5_o, 'tauWtdMeanRmse0.5')
df_cz6 = remove_outlier(df_cz6_o, 'tauWtdMeanRmse0.5')
df_cz7 = remove_outlier(df_cz7_o, 'tauWtdMeanRmse0.5')
df_cz8 = remove_outlier(df_cz8_o, 'tauWtdMeanRmse0.5')
frames = [df_cz1, df_cz2, df_cz3, df_cz4, df_cz5, df_cz6, df_cz7, df_cz8]
df = pd.concat(frames)

#By Season
df_cz1Fal = df_cz1[(df_cz1['Season']=='Fall')] 
df_cz1Win = df_cz1[(df_cz1['Season']=='Winter')]
df_cz1Spr = df_cz1[(df_cz1['Season']=='Spring')]
df_cz1Sum = df_cz1[(df_cz1['Season']=='Summer')]

df_cz2Fal = df_cz2[(df_cz2['Season']=='Fall')] 
df_cz2Win = df_cz2[(df_cz2['Season']=='Winter')]
df_cz2Spr = df_cz2[(df_cz2['Season']=='Spring')]
df_cz2Sum = df_cz2[(df_cz2['Season']=='Summer')]

df_cz3Fal = df_cz3[(df_cz3['Season']=='Fall')] 
df_cz3Win = df_cz3[(df_cz3['Season']=='Winter')]
df_cz3Spr = df_cz3[(df_cz3['Season']=='Spring')]
df_cz3Sum = df_cz3[(df_cz3['Season']=='Summer')]

df_cz4Fal = df_cz4[(df_cz4['Season']=='Fall')] 
df_cz4Win = df_cz4[(df_cz4['Season']=='Winter')]
df_cz4Spr = df_cz4[(df_cz4['Season']=='Spring')]
df_cz4Sum = df_cz4[(df_cz4['Season']=='Summer')]

df_cz5Fal = df_cz5[(df_cz5['Season']=='Fall')] 
df_cz5Win = df_cz5[(df_cz5['Season']=='Winter')]
df_cz5Spr = df_cz5[(df_cz5['Season']=='Spring')]
df_cz5Sum = df_cz5[(df_cz5['Season']=='Summer')]

df_cz6Fal = df_cz6[(df_cz6['Season']=='Fall')] 
df_cz6Win = df_cz6[(df_cz6['Season']=='Winter')]
df_cz6Spr = df_cz6[(df_cz6['Season']=='Spring')]
df_cz6Sum = df_cz6[(df_cz6['Season']=='Summer')]

df_cz7Fal = df_cz7[(df_cz7['Season']=='Fall')] 
df_cz7Win = df_cz7[(df_cz7['Season']=='Winter')]
df_cz7Spr = df_cz7[(df_cz7['Season']=='Spring')]
df_cz7Sum = df_cz7[(df_cz7['Season']=='Summer')]

df_cz8Fal = df_cz8[(df_cz8['Season']=='Fall')] 
df_cz8Win = df_cz8[(df_cz8['Season']=='Winter')]
df_cz8Spr = df_cz8[(df_cz8['Season']=='Spring')]
df_cz8Sum = df_cz8[(df_cz8['Season']=='Summer')] 

df_Sep = df[(df['Year_Month'])=='2017-09']
df_Oct = df[(df['Year_Month'])=='2017-10']
df_Nov = df[(df['Year_Month'])=='2017-11']
df_Dec = df[(df['Year_Month'])=='2017-12']
df_Jan = df[(df['Year_Month'])=='2018-01']
df_Feb = df[(df['Year_Month'])=='2018-02']
df_Mar = df[(df['Year_Month'])=='2018-03']
df_Apr = df[(df['Year_Month'])=='2018-04']
df_May = df[(df['Year_Month'])=='2018-05']
df_Jun = df[(df['Year_Month'])=='2018-06']
df_Jul = df[(df['Year_Month'])=='2018-07']
df_Aug = df[(df['Year_Month'])=='2018-08']


id_tmCst = df['Identifier'].value_counts()
all_tmCst = df_md
all_tmCst.set_index('Identifier', inplace=True)
df_mdTmCst = all_tmCst[all_tmCst.index.isin(id_tmCst.index.values)]

#%% STEP 6: Creation of Pre-parared Dataframes for further steps (Run once to save progress)

# df_mdTmCst.to_csv(os.path.join(cwd,'ProjN_metaData.csv'))
# df.to_csv(os.path.join(cwd, 'ProjN_tmCstData.csv'))

# #%% Load Pre-prepared datasets
# #Load cleaned and explanded meta data    
# df_mdTmCst = pd.read_csv(os.path.join(cwd, 'ProjN_metaData.csv'))    
# #  Load time constant data
# df = pd.read_csv(os.path.join(cwd, 'ProjN_tmCstData.csv'))

#%% STEP 7: PROCESSED METADATA DESCRIPTION
# Check out info of dataframe
print ('\n')
print ('\n')
print ("+ PROCESSED METADATA DATAFRAME:")
print ('\n')
df_mdTmCst.info()
print ('\n')
df_mdTmCst_stats = df_mdTmCst.describe()
#Applying per column:
print ("No. of Missing Inputs per column:")
print (df_mdTmCst.apply(NumMissingInput, axis=0)) #axis=0 defines that function is to be applied on each column
##Applying per row:
#print "\n No. of Missing Inputs per row:"
#print df_mdTmCst.apply(NumMissingInput, axis=1) #axis=1 defines that function is to be applied on each row# Column  0: 'Identifier'
print ('\n')


print('Total number of residences yielding TCC Values (w/out outliers): %d' %(len(df_mdTmCst.index)))
print ('\n')

#%% STEP 8: PROCESSED DATA DESCRIPTION
# Check out info of dataframe
print ('\n')
print ('\n')
print ("+ PROCESSED DATA DATAFRAME:")
print ('\n')
df.info()
print ('\n')
df_stats = df.describe()
df_cz1_stats = df_cz1.describe()
df_cz2_stats = df_cz2.describe()
df_cz3_stats = df_cz3.describe()
df_cz4_stats = df_cz4.describe()
df_cz5_stats = df_cz5.describe()
df_cz6_stats = df_cz6.describe()
df_cz7_stats = df_cz7.describe()
df_cz8_stats = df_cz8.describe()
#Applying per column:
print ("No. of Missing Inputs per column:")
print (df.apply(NumMissingInput, axis=0)) #axis=0 defines that function is to be applied on each column
##Applying per row:
#print "\n No. of Missing Inputs per row:"
#print df.apply(NumMissingInput, axis=1) #axis=1 defines that function is to be applied on each row# Column  0: 'Identifier'
print ('\n')


print('Total number of monthly TCC averages {w/out outliers): %d' %(len(df.index)))
print ('\n')
print('The mode of climate zone: %8.2f' %(df_mdTmCst['Climate Zone'].mode()))
print ('\n')
print('The mode of floor area: %8.2f' %(df_mdTmCst['Floor Area [m2]'].mode()))
print ('\n')
print('The mode of Style: %s' %(df_mdTmCst['Style'].mode()))
print ('\n')
print('The mode of number of floors: %8.2f' %(df_mdTmCst['Number of Floors'].mode()))
print ('\n')
print('The mode of age of home: %8.2f' %(df_mdTmCst['Age of Home [years]'].mode()))
print ('\n')
print('The mode of number of occupants: %8.2f' %(df_mdTmCst['Number of Occupants'].mode()))
print ('\n')

#%% STEP 9 : VALUES for Estimated Monthly TCC values by Season and Climate Zone

df['Season'][(df['Climate Zone']== 1)].value_counts().sort_values()
df['Season'][(df['Climate Zone']== 2)].value_counts().sort_values()
df['Season'][(df['Climate Zone']== 3)].value_counts().sort_values()
df['Season'][(df['Climate Zone']== 4)].value_counts().sort_values()
df['Season'][(df['Climate Zone']== 5)].value_counts().sort_values()
df['Season'][(df['Climate Zone']== 6)].value_counts().sort_values()
df['Season'][(df['Climate Zone']== 7)].value_counts().sort_values()
df['Season'][(df['Climate Zone']== 8)].value_counts().sort_values()

df['tauWtdMeanRmse0.5'][(df['Season']== 'Summer')].describe()
df['tauWtdMeanRmse0.5'][(df['Season']== 'Summer') & (df['Dwelling Classification']== 'Single-Family Residential')].describe()
df['tauWtdMeanRmse0.5'][(df['Season']== 'Summer') & (df['Dwelling Classification']== 'Multi-Family Residential')].describe()
df_cz1['tauWtdMeanRmse0.5'][(df_cz1['Season']== 'Summer')].describe()
df_cz2['tauWtdMeanRmse0.5'][(df_cz2['Season']== 'Summer')].describe()
df_cz3['tauWtdMeanRmse0.5'][(df_cz3['Season']== 'Summer')].describe()
df_cz4['tauWtdMeanRmse0.5'][(df_cz4['Season']== 'Summer')].describe()
df_cz5['tauWtdMeanRmse0.5'][(df_cz5['Season']== 'Summer')].describe()
df_cz6['tauWtdMeanRmse0.5'][(df_cz6['Season']== 'Summer')].describe()
df_cz7['tauWtdMeanRmse0.5'][(df_cz7['Season']== 'Summer')].describe()
df_cz8['tauWtdMeanRmse0.5'][(df_cz8['Season']== 'Summer')].describe()

df['tauWtdMeanRmse0.5'][(df['Season']== 'Winter')].describe()
df['tauWtdMeanRmse0.5'][(df['Season']== 'Winter') & (df['Dwelling Classification']== 'Single-Family Residential')].describe()
df['tauWtdMeanRmse0.5'][(df['Season']== 'Winter') & (df['Dwelling Classification']== 'Multi-Family Residential')].describe()
df_cz1['tauWtdMeanRmse0.5'][(df_cz1['Season']== 'Winter')].describe()
df_cz2['tauWtdMeanRmse0.5'][(df_cz2['Season']== 'Winter')].describe()
df_cz3['tauWtdMeanRmse0.5'][(df_cz3['Season']== 'Winter')].describe()
df_cz4['tauWtdMeanRmse0.5'][(df_cz4['Season']== 'Winter')].describe()
df_cz5['tauWtdMeanRmse0.5'][(df_cz5['Season']== 'Winter')].describe()
df_cz6['tauWtdMeanRmse0.5'][(df_cz6['Season']== 'Winter')].describe()
df_cz7['tauWtdMeanRmse0.5'][(df_cz7['Season']== 'Winter')].describe()
df_cz8['tauWtdMeanRmse0.5'][(df_cz8['Season']== 'Winter')].describe()

df['tauWtdMeanRmse0.5'][(df['Season']== 'Spring')].describe()
df['tauWtdMeanRmse0.5'][(df['Season']== 'Spring') & (df['Dwelling Classification']== 'Single-Family Residential')].describe()
df['tauWtdMeanRmse0.5'][(df['Season']== 'Spring') & (df['Dwelling Classification']== 'Multi-Family Residential')].describe()
df_cz1['tauWtdMeanRmse0.5'][(df_cz1['Season']== 'Spring')].describe()
df_cz2['tauWtdMeanRmse0.5'][(df_cz2['Season']== 'Spring')].describe()
df_cz3['tauWtdMeanRmse0.5'][(df_cz3['Season']== 'Spring')].describe()
df_cz4['tauWtdMeanRmse0.5'][(df_cz4['Season']== 'Spring')].describe()
df_cz5['tauWtdMeanRmse0.5'][(df_cz5['Season']== 'Spring')].describe()
df_cz6['tauWtdMeanRmse0.5'][(df_cz6['Season']== 'Spring')].describe()
df_cz7['tauWtdMeanRmse0.5'][(df_cz7['Season']== 'Spring')].describe()
df_cz8['tauWtdMeanRmse0.5'][(df_cz8['Season']== 'Spring')].describe()

df['tauWtdMeanRmse0.5'][(df['Season']== 'Fall')].describe()
df['tauWtdMeanRmse0.5'][(df['Season']== 'Fall') & (df['Dwelling Classification']== 'Single-Family Residential')].describe()
df['tauWtdMeanRmse0.5'][(df['Season']== 'Fall') & (df['Dwelling Classification']== 'Multi-Family Residential')].describe()
df_cz1['tauWtdMeanRmse0.5'][(df_cz1['Season']== 'Fall')].describe()
df_cz2['tauWtdMeanRmse0.5'][(df_cz2['Season']== 'Fall')].describe()
df_cz3['tauWtdMeanRmse0.5'][(df_cz3['Season']== 'Fall')].describe()
df_cz4['tauWtdMeanRmse0.5'][(df_cz4['Season']== 'Fall')].describe()
df_cz5['tauWtdMeanRmse0.5'][(df_cz5['Season']== 'Fall')].describe()
df_cz6['tauWtdMeanRmse0.5'][(df_cz6['Season']== 'Fall')].describe()
df_cz7['tauWtdMeanRmse0.5'][(df_cz7['Season']== 'Fall')].describe()
df_cz8['tauWtdMeanRmse0.5'][(df_cz8['Season']== 'Fall')].describe()

#%% STEP 10: Set up for Statistics Summary

czSsn_list1=[
            # [df_cz1Fal, 'cz1Fall'], [df_cz1Win, 'cz1Winter'], [df_cz1Spr, 'cz1Spring'], [df_cz1Sum, 'cz1Summer'], [df_cz1FalSpr, 'cz1FallSpring'], # 0-4
            # [df_cz2Fal, 'cz2Fall'], [df_cz2Win, 'cz2Winter'], [df_cz2Spr, 'cz2Spring'], [df_cz2Sum, 'cz2Summer'], [df_cz2FalSpr, 'cz2FallSpring'], # 5-9
            # [df_cz3Fal, 'cz3Fall'], [df_cz3Win, 'cz3Winter'], [df_cz3Spr, 'cz3Spring'], [df_cz3Sum, 'cz3Summer'], [df_cz3FalSpr, 'cz3FallSpring'], # 10-14
            # [df_cz4Fal, 'cz4Fall'], [df_cz4Win, 'cz4Winter'], [df_cz4Spr, 'cz4Spring'], [df_cz4Sum, 'cz4Summer'], [df_cz4FalSpr, 'cz4FallSpring'], # 15-19
            # [df_cz5Fal, 'cz5Fall'], [df_cz5Win, 'cz5Winter'], [df_cz5Spr, 'cz5Spring'], [df_cz5Sum, 'cz5Summer'], [df_cz5FalSpr, 'cz5FallSpring'], # 20-24
            # [df_cz6Fal, 'cz6Fall'], [df_cz6Win, 'cz6Winter'], [df_cz6Spr, 'cz6Spring'], [df_cz6Sum, 'cz6Summer'], [df_cz6FalSpr, 'cz6FallSpring'], # 25-29
            # [df_cz7Fal, 'cz7Fall'], [df_cz7Win, 'cz7Winter'], [df_cz7Spr, 'cz7Spring'], [df_cz7Sum, 'cz7Summer'], [df_cz7FalSpr, 'cz7FallSpring'],  # 30-34
            [df_cz8Win, 'cz8Winter'], [df_cz8Sum, 'cz8Summer'] # 30-34
            ]
df_Fal = df[df['Season']=='Fall']
df_Win = df[df['Season']=='Winter']
df_Spr = df[df['Season']=='Spring']
df_Sum = df[df['Season']=='Summer']

czSsn_list2 = [[df, 'All'], # 0
               [df_cz1, 'cz1'], [df_cz2, 'cz2'], [df_cz3, 'cz3'], [df_cz4, 'cz4'], # 1-4
               [df_cz5, 'cz5'], [df_cz6, 'cz6'], [df_cz7, 'cz7'], [df_cz8, 'cz8'], # 5-8
               [df_Fal, 'Fal'], [df_Win, 'Win'], [df_Spr, 'Spr'], [df_Sum, 'Sum']] # 9-12

dStatSum = np.zeros ((15,1))                  
for czSsn in czSsn_list1:
    X1_stats = czSsn[0].describe().loc[:,'tauWtdMeanRmse0.5']
    X1= czSsn[0].loc[:,'tauWtdMeanRmse0.5']
    X1 = X1.values
    n = len(X1)
    mean = X1_stats.iloc[1]
    gmean = float(scipy.stats.gmean(X1))
    std = X1_stats.iloc[2]
    cv = std/mean
    lower_quartile = X1_stats.iloc[4]
    upper_quartile = X1_stats.iloc[6]
    iqr = upper_quartile - lower_quartile
    upper_whisker = X1[(X1<=upper_quartile+1.5*iqr)].max()
    lower_whisker = X1[(X1>=lower_quartile-1.5*iqr)].min()
    t_crit = scipy.stats.t.ppf(q=0.975,df=n-1) # for 95% confidence interval
    SE = std / np.sqrt(n)
    ci_lower = mean - (t_crit*SE)
    ci_upper = mean + (t_crit*SE)
    val = np.array([X1_stats.iloc[0],
            mean,
            ci_lower,
            ci_upper,
            gmean,
            std,
            cv,
            X1_stats.iloc[3],
            lower_whisker,
            lower_quartile,
            X1_stats.iloc[5],
            upper_quartile,
            upper_whisker,
            X1_stats.iloc[7],
            iqr])
    dStatSum = np.hstack((dStatSum, np.atleast_2d(val).T))
dStatSum =np.delete(dStatSum, 0, 1)
column_names = []
for czSsn in czSsn_list2: 
    column_names.append(czSsn[1])
StatSummary = pd.DataFrame(data = dStatSum, index=['Count', 'Arithmetic Mean', 'Mean Lower CL',
                                  'Mean Upper CL', 'Geometric Mean', 'Standard deviation',
                                  'Coefficient of Variation', 'Minimum', 'Lower Whisker',
                                  'Lower Quartile (25%)', 'Median (50%)', 'Upper Quartile (75%)',
                                  'Upper Whisker', 'Maximum', 'Interquartile range (IQR)'],
                                   columns = column_names)
# StatSummary.to_csv(os.path.join(cwd, 'Figures_TmCstData', 'Stats_czSSn_.csv'))
# StatSummary.to_csv(os.path.join(cwd, 'Figures_TmCstData', 'Stats_cz_SSn_.csv'))

#%% DFIG 1: HISTOGRAM - Time Cst Data Set - TmCst Count 

df_plt71= df[['tauWtdMeanRmse0.5']]
df_plt71.describe()
upper_quartile = np.percentile(df_plt71['tauWtdMeanRmse0.5'], 75)
lower_quartile = np.percentile(df_plt71['tauWtdMeanRmse0.5'], 25)
iqr = upper_quartile - lower_quartile
upper_whisker = df_plt71['tauWtdMeanRmse0.5'][(df_plt71['tauWtdMeanRmse0.5']<=upper_quartile+1.5*iqr)].max()
lower_whisker = df_plt71['tauWtdMeanRmse0.5'][(df_plt71['tauWtdMeanRmse0.5']>=lower_quartile-1.5*iqr)].min()

# pal71 = sns.color_palette("tab10", 1)
fig71, ax71 = plt.subplots(nrows= 1,ncols= 1, figsize=(6,3))
ax71 = sns.distplot(df_plt71['tauWtdMeanRmse0.5'], hist=True, kde=False, bins=50, hist_kws={"color": "b"})
ax71.set_xlabel(r'$\tau_{mth,k}$ [hours]')
ax71.set_ylabel('Count')
plt.tight_layout()
# sns.despine(fig=fig71)
fig71.savefig(os.path.join(cwd,'Figures_TmCstData','histplt_TmCst_Dist.png'), dpi=400,
#       transparent = 'true'
        bbox_inches='tight')

#%% DFIG 2: BAR PLOT/ HEATMAP - Time Cst Data Set  - Tau Value Count by all Climate and Season

d72_long= df

cz1Fal = d72_long['Climate Zone'][(d72_long['Climate Zone']== 1) & (d72_long['Season'] == 'Fall')].value_counts()[1]
cz1Win = d72_long['Climate Zone'][(d72_long['Climate Zone']== 1) & (d72_long['Season'] == 'Winter')].value_counts()[1]
cz1Spr = d72_long['Climate Zone'][(d72_long['Climate Zone']== 1) & (d72_long['Season'] == 'Spring')].value_counts()[1]
cz1Sum = d72_long['Climate Zone'][(d72_long['Climate Zone']== 1) & (d72_long['Season'] == 'Summer')].value_counts()[1]

cz2Fal = d72_long['Climate Zone'][(d72_long['Climate Zone']== 2) & (d72_long['Season'] == 'Fall')].value_counts()[2]
cz2Win = d72_long['Climate Zone'][(d72_long['Climate Zone']== 2) & (d72_long['Season'] == 'Winter')].value_counts()[2]
cz2Spr = d72_long['Climate Zone'][(d72_long['Climate Zone']== 2) & (d72_long['Season'] == 'Spring')].value_counts()[2]
cz2Sum = d72_long['Climate Zone'][(d72_long['Climate Zone']== 2) & (d72_long['Season'] == 'Summer')].value_counts()[2]

cz3Fal = d72_long['Climate Zone'][(d72_long['Climate Zone']== 3) & (d72_long['Season'] == 'Fall')].value_counts()[3]
cz3Win = d72_long['Climate Zone'][(d72_long['Climate Zone']== 3) & (d72_long['Season'] == 'Winter')].value_counts()[3]
cz3Spr = d72_long['Climate Zone'][(d72_long['Climate Zone']== 3) & (d72_long['Season'] == 'Spring')].value_counts()[3]
cz3Sum = d72_long['Climate Zone'][(d72_long['Climate Zone']== 3) & (d72_long['Season'] == 'Summer')].value_counts()[3]

cz4Fal = d72_long['Climate Zone'][(d72_long['Climate Zone']== 4) & (d72_long['Season'] == 'Fall')].value_counts()[4]
cz4Win = d72_long['Climate Zone'][(d72_long['Climate Zone']== 4) & (d72_long['Season'] == 'Winter')].value_counts()[4]
cz4Spr = d72_long['Climate Zone'][(d72_long['Climate Zone']== 4) & (d72_long['Season'] == 'Spring')].value_counts()[4]
cz4Sum = d72_long['Climate Zone'][(d72_long['Climate Zone']== 4) & (d72_long['Season'] == 'Summer')].value_counts()[4]

cz5Fal = d72_long['Climate Zone'][(d72_long['Climate Zone']== 5) & (d72_long['Season'] == 'Fall')].value_counts()[5]
cz5Win = d72_long['Climate Zone'][(d72_long['Climate Zone']== 5) & (d72_long['Season'] == 'Winter')].value_counts()[5]
cz5Spr = d72_long['Climate Zone'][(d72_long['Climate Zone']== 5) & (d72_long['Season'] == 'Spring')].value_counts()[5]
cz5Sum = d72_long['Climate Zone'][(d72_long['Climate Zone']== 5) & (d72_long['Season'] == 'Summer')].value_counts()[5]

cz6Fal = d72_long['Climate Zone'][(d72_long['Climate Zone']== 6) & (d72_long['Season'] == 'Fall')].value_counts()[6]
cz6Win = d72_long['Climate Zone'][(d72_long['Climate Zone']== 6) & (d72_long['Season'] == 'Winter')].value_counts()[6]
cz6Spr = d72_long['Climate Zone'][(d72_long['Climate Zone']== 6) & (d72_long['Season'] == 'Spring')].value_counts()[6]
cz6Sum = d72_long['Climate Zone'][(d72_long['Climate Zone']== 6) & (d72_long['Season'] == 'Summer')].value_counts()[6]

cz7Fal = d72_long['Climate Zone'][(d72_long['Climate Zone']== 7) & (d72_long['Season'] == 'Fall')].value_counts()[7]
cz7Win = d72_long['Climate Zone'][(d72_long['Climate Zone']== 7) & (d72_long['Season'] == 'Winter')].value_counts()[7]
cz7Spr = d72_long['Climate Zone'][(d72_long['Climate Zone']== 7) & (d72_long['Season'] == 'Spring')].value_counts()[7]
cz7Sum = d72_long['Climate Zone'][(d72_long['Climate Zone']== 7) & (d72_long['Season'] == 'Summer')].value_counts()[7]

cz8Fal = 0
# d72_long['Climate Zone'][(d72_long['Climate Zone']== 8) & (d72_long['Season'] == 'Fall')].value_counts()[8]
cz8Win = d72_long['Climate Zone'][(d72_long['Climate Zone']== 8) & (d72_long['Season'] == 'Winter')].value_counts()[8]
cz8Spr = 0
# d72_long['Climate Zone'][(d72_long['Climate Zone']== 8) & (d72_long['Season'] == 'Spring')].value_counts()[8]
cz8Sum = d72_long['Climate Zone'][(d72_long['Climate Zone']== 8) & (d72_long['Season'] == 'Summer')].value_counts()[8]

df_plt72 = pd.DataFrame(data = np.array([[cz1Fal, cz2Fal, cz3Fal, cz4Fal, cz5Fal, cz6Fal, cz7Fal, cz8Fal], 
                                         [cz1Win, cz2Win, cz3Win, cz4Win, cz5Win, cz6Win, cz7Win, cz8Win],
                                         [cz1Spr, cz2Spr, cz3Spr, cz4Spr, cz5Spr, cz6Spr, cz7Spr, cz8Spr],
                                         [cz1Sum, cz2Sum, cz3Sum, cz4Sum, cz5Sum, cz6Sum, cz7Sum, cz8Sum]]), 
                        index = ['Fall','Winter', 'Spring', 'Summer'],
                        columns = ['1', '2', '3', '4', '5', '6', '7', '8'])
df_plt72 = df_plt72.unstack()
df_plt72.index.names = ['Climate Zone','Season']
df_plt72=df_plt72.to_frame()
df_plt72.columns=['Count']
df_plt72 = df_plt72.reset_index()

pal72 = {'Fall':"orange",'Winter': "skyblue",'Spring': "limegreen",'Summer': "salmon"}
fig72 = plt.figure(figsize=(7,9))
ax72 =  sns.barplot(data= df_plt72, x='Count', y='Climate Zone', hue ='Season', palette=pal72, orient='h')
# Annotate every single Bar with its value, based on it's width           
for p in ax72.patches:
    width = p.get_width()
    plt.text(5+p.get_width(), p.get_y()+0.55*p.get_height(),
             '{:.0f}'.format(width),
             ha='left', va='center')
ax72.set_xlim([0, max(df_plt72['Count'])+300])
plt.xlabel(r'Number of $\tau_{mth,k}$ values')
plt.setp(ax72.get_legend().get_title(), fontsize='13') # for legend title
plt.rc('font', size=14)          # controls default text sizes
plt.rc('axes', titlesize=14)     # fontsize of the axes title
plt.rc('axes', labelsize=16)    # fontsize of the x and y labels
plt.rc('xtick', labelsize=14)    # fontsize of the tick labels
plt.rc('ytick', labelsize=14)    # fontsize of the tick labels
plt.rc('legend', fontsize=13)    # legend fontsize
# plt.rc('figure', titlesize=24)  # fontsize of the figure title
plt.tight_layout()
sns.despine(fig=fig72)
fig72.savefig(os.path.join(cwd,'Figures_TmCstData','barPlt_TmCstDw_CountVsCzBySeason.png'), dpi=400,
#       transparent = 'true'
    )

#%% DFIG 3.1: BAR PLOT/ HEATMAP - Time Cst Data Set  - Dwelling Count by all Climate
d73_long= df_mdTmCst

cz1 = d73_long['Climate Zone'][(d73_long['Climate Zone']== 1)].value_counts()[1]
cz2 = d73_long['Climate Zone'][(d73_long['Climate Zone']== 2)].value_counts()[2]
cz3 = d73_long['Climate Zone'][(d73_long['Climate Zone']== 3)].value_counts()[3]
cz4 = d73_long['Climate Zone'][(d73_long['Climate Zone']== 4)].value_counts()[4]
cz5 = d73_long['Climate Zone'][(d73_long['Climate Zone']== 5)].value_counts()[5]
cz6 = d73_long['Climate Zone'][(d73_long['Climate Zone']== 6)].value_counts()[6]
cz7 = d73_long['Climate Zone'][(d73_long['Climate Zone']== 7)].value_counts()[7]
cz8 = d73_long['Climate Zone'][(d73_long['Climate Zone']== 8)].value_counts()[8]

df_plt73 = pd.DataFrame(data = np.array([[cz1, cz2, cz3, cz4, cz5, cz6, cz7, cz8]]), 
                        columns = ['1', '2', '3', '4', '5', '6', '7', '8'])
df_plt73 = df_plt73.T
df_plt73.index.names = ['Climate Zone']
df_plt73.columns=['Count']
df_plt73 = df_plt73.reset_index()

pal73 = sns.color_palette("Blues_r", 1)
fig73, ax73 = plt.subplots(nrows= 1,ncols= 1, figsize=(6,4)) 
ax73 =  sns.barplot(data= df_plt73, y='Count', x='Climate Zone', palette=pal73)
for bar in ax73.patches:
    ax73.annotate('{:.0f}'.format(bar.get_height()), 
                xy=(bar.get_x() + bar.get_width()/2, bar.get_height()), 
                xytext= (0,1), 
                textcoords='offset points', 
                ha='center', va='bottom')
plt.xticks(rotation= 0)
plt.xlabel('Climate Zone')
plt.ylabel('Number of Dwellings')
plt.tight_layout()
sns.despine(fig=fig73)
fig73.savefig(os.path.join(cwd,'Figures_TmCstData','barPlt_TmCstDw_CountVsCz.png'), dpi=400,
#       transparent = 'true'
    )

#%% DFIG 3.2: BAR PLOT/ HEATMAP - Time Cst Data Set  - Dwelling Count by all Climate by Sample name
# d73_long= df_mdTmCst

# cz1 = d73_long['Climate Zone'][(d73_long['Climate Zone']== 1)].value_counts()[1]
# cz2 = d73_long['Climate Zone'][(d73_long['Climate Zone']== 2)].value_counts()[2]
# cz3 = d73_long['Climate Zone'][(d73_long['Climate Zone']== 3)].value_counts()[3]
# cz4 = d73_long['Climate Zone'][(d73_long['Climate Zone']== 4)].value_counts()[4]
# cz5 = d73_long['Climate Zone'][(d73_long['Climate Zone']== 5)].value_counts()[5]
# cz6 = d73_long['Climate Zone'][(d73_long['Climate Zone']== 6)].value_counts()[6]
# cz7 = d73_long['Climate Zone'][(d73_long['Climate Zone']== 7)].value_counts()[7]
# cz8 = d73_long['Climate Zone'][(d73_long['Climate Zone']== 8)].value_counts()[8]

# cz1b = df_md['Climate Zone'][(df_md['Climate Zone']== 1)].value_counts()[1]
# cz2b = df_md['Climate Zone'][(df_md['Climate Zone']== 2)].value_counts()[2]
# cz3b = df_md['Climate Zone'][(df_md['Climate Zone']== 3)].value_counts()[3]
# cz4b = df_md['Climate Zone'][(df_md['Climate Zone']== 4)].value_counts()[4]
# cz5b = df_md['Climate Zone'][(df_md['Climate Zone']== 5)].value_counts()[5]
# cz6b = df_md['Climate Zone'][(df_md['Climate Zone']== 6)].value_counts()[6]
# cz7b = df_md['Climate Zone'][(df_md['Climate Zone']== 7)].value_counts()[7]
# cz8b = df_md['Climate Zone'][(df_md['Climate Zone']== 8)].value_counts()[8]

# df_plt73 = pd.DataFrame(data = np.array([[cz1b, cz2b, cz3b, cz4b, cz5b, cz6b, cz7b, cz8b],
#                                          [cz1, cz2, cz3, cz4, cz5, cz6, cz7, cz8]]),
#                         index = ['original', 'subset'],
#                         columns = ['1', '2', '3', '4', '5', '6', '7', '8'])

# df_plt73 = df_plt73.unstack()
# df_plt73.index.names = ['Climate Zone', 'Sample']
# df_plt73=df_plt73.to_frame()
# df_plt73.columns=['Count']
# df_plt73 = df_plt73.reset_index()

# pal73 = sns.color_palette("Blues_r", 2)
# fig73, ax73 = plt.subplots(nrows= 1,ncols= 1, figsize=(8,4)) 
# ax73 =  sns.barplot(data= df_plt73, y='Count', x='Climate Zone', hue='Sample',  palette=pal73)
# for bar in ax73.patches:
#     ax73.annotate('{:.0f}'.format(bar.get_height()), 
#                 xy=(bar.get_x() + bar.get_width()/2, bar.get_height()), 
#                 xytext= (0,1), 
#                 textcoords='offset points', 
#                 ha='center', va='bottom')
# plt.xticks(rotation= 0)
# plt.xlabel('Climate Zone')
# plt.ylabel('Number of Dwellings')
# plt.tight_layout()
# sns.despine(fig=fig73)
# fig73.savefig(os.path.join(cwd,'Figures_TmCstData','barPlt_TmCstDw_CountVsCzbySample.png'), dpi=400,
# #       transparent = 'true'
#     )

#%% DFIG 4: SCATTER PLOT  - Time Cst Data set - Means and medians by Climate

d74_long = df

# sns.distplot(d26_long['tauWtdMeanRmse0.5'][(d26_long['Climate Zone']== 1)])
# sns.distplot(d26_long['tauWtdMeanRmse0.5'][(d26_long['Climate Zone']== 2)])
# sns.distplot(d26_long['tauWtdMeanRmse0.5'][(d26_long['Climate Zone']== 3)])
# sns.distplot(d26_long['tauWtdMeanRmse0.5'][(d26_long['Climate Zone']== 4)])
# sns.distplot(d26_long['tauWtdMeanRmse0.5'][(d26_long['Climate Zone']== 5)])
# sns.distplot(d26_long['tauWtdMeanRmse0.5'][(d26_long['Climate Zone']== 6)])
# sns.distplot(d26_long['tauWtdMeanRmse0.5'][(d26_long['Climate Zone']== 7)])
# sns.distplot(d26_long['tauWtdMeanRmse0.5'][(d26_long['Climate Zone']== 8)])

cz1_stats = d74_long['tauWtdMeanRmse0.5'][(d74_long['Climate Zone']== 1)].describe()
cz2_stats = d74_long['tauWtdMeanRmse0.5'][(d74_long['Climate Zone']== 2)].describe()
cz3_stats = d74_long['tauWtdMeanRmse0.5'][(d74_long['Climate Zone']== 3)].describe()
cz4_stats = d74_long['tauWtdMeanRmse0.5'][(d74_long['Climate Zone']== 4)].describe()
cz5_stats = d74_long['tauWtdMeanRmse0.5'][(d74_long['Climate Zone']== 5)].describe()
cz6_stats = d74_long['tauWtdMeanRmse0.5'][(d74_long['Climate Zone']== 6)].describe()
cz7_stats = d74_long['tauWtdMeanRmse0.5'][(d74_long['Climate Zone']== 7)].describe()
cz8_stats = d74_long['tauWtdMeanRmse0.5'][(d74_long['Climate Zone']== 8)].describe()

df_plt74 = pd.DataFrame(data = np.array([[cz1_stats[1], cz2_stats[1], cz3_stats[1], cz4_stats[1], cz5_stats[1], cz6_stats[1], cz7_stats[1]],
                                         [cz1_stats[5], cz2_stats[5], cz3_stats[5], cz4_stats[5], cz5_stats[5], cz6_stats[5], cz7_stats[5]]]), 
                        index = ['Mean','Median'],
                        columns = ['1', '2', '3', '4', '5', '6', '7',])
df_plt74 = df_plt74.unstack()
df_plt74.index.names = ['Climate Zone','Statistic']
df_plt74=df_plt74.to_frame()
df_plt74.columns=['Value']
df_plt74 = df_plt74.reset_index()

fig74, ax74 = plt.subplots(nrows= 1,ncols= 1, figsize=(8, 5))
#Plot Data
sns.scatterplot(x="Climate Zone", y="Value", style="Statistic", s=100, data=df_plt74, ax=ax74)
ax74.set_xticks(ticks = [1.,2.,3.,4.,5.,6.,7.])
#Set outer labels and layout
ax74.set_ylabel(r'Average $\tau_{mth,k}$ [hours]')
plt.tight_layout()
sns.despine(fig=fig74)
fig74.savefig(os.path.join(cwd,'Figures_TmCstData','sctrPlt_TmCstData_StatByCz17.png'), dpi=400,
#       transparent = 'true'
    )

#%% DFIG 5: SCATTER PLOT  - Time Cst Data set - Means and medians by Season

d75_long = df

# sns.distplot(d75_long['tauWtdMeanRmse0.5'][(d75_long['Season']== 'Fall')])
# sns.distplot(d75_long['tauWtdMeanRmse0.5'][(d75_long['Season']== 'Winter')])
# sns.distplot(d75_long['tauWtdMeanRmse0.5'][(d75_long['Season']== 'Spring')])
# sns.distplot(d75_long['tauWtdMeanRmse0.5'][(d75_long['Season']== 'Summer')])

Fal_stats = d75_long['tauWtdMeanRmse0.5'][(d75_long['Season']== 'Fall')].describe()
Win_stats = d75_long['tauWtdMeanRmse0.5'][(d75_long['Season']== 'Winter')].describe()
Spr_stats = d75_long['tauWtdMeanRmse0.5'][(d75_long['Season']== 'Spring')].describe()
Sum_stats = d75_long['tauWtdMeanRmse0.5'][(d75_long['Season']== 'Summer')].describe()


df_plt75 = pd.DataFrame(data = np.array([[Fal_stats[1], Win_stats[1], Spr_stats[1], Sum_stats[1]],
                                         [Fal_stats[5], Win_stats[5], Spr_stats[5], Sum_stats[5]]]), 
                        index = ['Mean','Median'],
                        columns = ['Fall', 'Winter', 'Spring', 'Summer'])
df_plt75 = df_plt75.unstack()
df_plt75.index.names = ['Season','Statistic']
df_plt75=df_plt75.to_frame()
df_plt75.columns=['Value']

fig75, axes = plt.subplots(nrows= 1,ncols= 1, figsize=(7, 5))
#Plot Data
sns.scatterplot(x="Season", y="Value", style="Statistic", s=100, data=df_plt75, ax=axes)
axes.set_xticks(ticks = ['Fall', 'Winter', 'Spring', 'Summer'])
#Set outer labels and layout
axes.set_ylabel(r'Average $\tau_{mth,k}$ [hours]')
plt.tight_layout()
sns.despine(fig=fig75)
fig75.savefig(os.path.join(cwd,'Figures_TmCstData','sctrPlt_TmCstData_StatBySsn.png'), dpi=400,
#       transparent = 'true'
    )

#%% DFIG 6: BOX PLOT - Time Cst Data Set - Distribution by Season and Climate (Win Vs. Sum)
#Box 
df_plt76 = df[['Climate Zone','tauWtdMeanRmse0.5','Season']][(df['Season'] == 'Summer') | (df['Season'] == 'Winter')]
df_plt76= df_plt76[(df_plt76['Climate Zone'] != 8)]

fig76, ax76 = plt.subplots(figsize=(8,5))
sns.boxplot(x='Climate Zone', y= 'tauWtdMeanRmse0.5', hue= 'Season',    
           palette={'Winter': "skyblue",'Summer': "salmon"}, showmeans=True, meanprops={"marker":"o",
                                                       "markerfacecolor":"white", 
                                                       "markeredgecolor":"black",
                                                       "markersize":"4"},
           fliersize=1, data=df_plt76, ax=ax76)
plt.xlabel('Climate Zone')
ax76.set_xticklabels(['1', '2','3','4','5','6','7'])
plt.ylabel(r'$\tau_{mth,k}$ [hours]')
plt.tight_layout()
sns.despine(fig=fig76)
fig76.savefig(os.path.join(cwd,'Figures_TmCstData','boxPlt_TmCstData_DistByCz17ByWinSum.png'), dpi=400,
#       transparent = 'true'
    )
#%% CUSTOM FUNCTION FOR DFIG 7 and  DFIG 8:
def func(x, a, b, c):
    return a * np.exp(-1 / b * x) + c

#Define the data to be fit with some noise:
x00 = np.linspace(0, 71, 852) # 71 hours total
x01 = np.linspace(0, 160, 1920) # 71 hours total

#%%  DFIG 7: Exponential curves according for one TTC at mulptiple outdoor T_degCelcius

y01 = func(x01, 21., 38.72, 0)
y02 = func(x01, 26., 38.72, -5.)
y03 = func(x01, 36., 38.72, -15.)
y04 = func(x01, 46., 38.72, -25.)

# fig77, (ax77a, ax77b) = plt.subplots(nrows= 2,ncols= 1, figsize=(9., 8.5))
fig77, (ax77a, ax77b) = plt.subplots(nrows= 1,ncols= 2, figsize=(10, 6), gridspec_kw={'width_ratios': [3, 2]})


ax77a.plot(x01, y01, 'indigo', label= u'$T_{ext}$ = 0.0 \N{DEGREE SIGN}C')
ax77a.plot(x01, y02, 'blue', label= u'$T_{ext}$  = -5.0\N{DEGREE SIGN}C')
ax77a.plot(x01, y03, 'steelblue', label= u'$T_{ext}$  = -15.0\N{DEGREE SIGN}C')
ax77a.plot(x01, y04, 'skyblue', label= u'$T_{ext}$  = -25.0\N{DEGREE SIGN}C')
ax77a.set_xlabel('Time, t [hours]')
ax77a.set_ylabel(u'Indoor Temperature, $T_{in}$ [\N{DEGREE SIGN}C]')
ax77a.axhline(21., color='k', linestyle='dashed', linewidth=1, label = '$T_{in}$ (t=0)')
ax77a.axvline(38.72, color='r', linestyle='dashed', linewidth=1, label = r'Multiple of $\tau_{win,6}$')
ax77a.axvline(77.44, color='r', linestyle='dashed', linewidth=1)
ax77a.axvline(116.16, color='r', linestyle='dashed', linewidth=1)
ax77a.axvline(154.88, color='r', linestyle='dashed', linewidth=1)
ax77a.axhspan(20, 23, facecolor='g',
            alpha=0.2, label='Acceptable Thermal Comfort Range')
ax77a.axhspan(18, 20, facecolor='yellow',
            alpha=0.2, label='Low Thermal Comfort Range')
ax77a.set_xlim(left = 0, right = 160) # step 3: For close up of graph
ax77a.set_ylim(top = 21.5, bottom = -27.5)
ax77a.title.set_text(r'Climate Zone 6 Winter ($\tau_{win,6}$ = 38.72 hr)')
# ax77a.legend( bbox_to_anchor=(0, -0.6),loc="lower left", ncol=2)
ax77a.legend( bbox_to_anchor=(0, 1.08),loc="lower left", ncol=2)

ax77b.plot(x01, y01, 'indigo', label= u'$T_{ext}$ = 0.0 \N{DEGREE SIGN}C')
ax77b.plot(x01, y02, 'blue', label= u'$T_{ext}$  = -5.0\N{DEGREE SIGN}C')
ax77b.plot(x01, y03, 'steelblue', label= u'$T_{ext}$  = -15.0\N{DEGREE SIGN}C')
ax77b.plot(x01, y04, 'skyblue', label= u'$T_{ext}$  = -25.0\N{DEGREE SIGN}C')
# ax77b.set_xlabel('Time, t [hours]')
# ax77b.set_ylabel(u'Indoor Temperature, $T_{in}$ [\N{DEGREE SIGN}C]')
ax77b.axhline(21, color='k', linestyle='dashed', linewidth=1, label = '$T_{in}$ (t=0)')
# ax77b.axvline(38.72, color='r', linestyle='dashed', linewidth=1, label = r'Multiple of $\tau_{win,6}$')
ax77b.axhspan(20, 23, facecolor='g',
            alpha=0.2, label='Acceptable Thermal \n Comfort Range')
ax77b.axhspan(18, 20, facecolor='yellow',
            alpha=0.2, label='Low Thermal \n Comfort Range')
ax77b.set_xlim(left = 0, right = 8) # step 3: For close up of graph
ax77b.set_ylim(top = 21.5, bottom = 17.5)
ax77b.title.set_text(r'Close-up of Thermal Comfort Ranges')
# ax77b.legend(bbox_to_anchor=(.25,1.05), loc="lower left")
# ax77b.legend(bbox_to_anchor=(1.02,.01), loc="lower left")

plt.tight_layout()
# sns.despine(fig=fig77)
fig77.savefig(os.path.join(cwd, 'Figures_TmCstData', 'tempDropLL_cz6Win.png'), dpi=400, bbox_inches='tight')

#%% DFIG 8: Exponential curves according for multiple TTCs at one outdoor T_degCelcius

y11 = func(x01, 26., 18.62, -5.)
y12 = func(x01, 26., 26.84, -5.)
y13 = func(x01, 26., 38.72, -5.)
y14 = func(x01, 26., 42.30, -5.)

# fig78, (ax78a, ax78b) = plt.subplots(nrows= 2,ncols= 1, figsize=(9., 8.5))
fig78, (ax78a, ax78b) = plt.subplots(nrows= 1,ncols= 2, figsize=(10, 6), gridspec_kw={'width_ratios': [3, 2]})

ax78a.plot(x01, y11, 'tab:orange', label= 'Climate Zone 4')
ax78a.plot(x01, y12, 'tab:red', label= 'Climate Zone 5')
ax78a.plot(x01, y13, 'tab:purple', label= 'Climate Zone 6')
ax78a.plot(x01, y14, 'tab:blue', label= 'Climate Zone 7')
ax78a.set_xlabel('Time, t [hours]')
ax78a.set_ylabel(u'Indoor Temperature, $T_{in}$ [\N{DEGREE SIGN}C]')
ax78a.axhline(21., color='k', linestyle='dashed', linewidth=1, label = '$T_{in}$ (t=0)')
# ax78a.axvline(18.62, color='tab:orange', linestyle='dashed', linewidth=1, label = r'$\tau_{win,4}$')
# ax78a.axvline(26.84, color='tab:red', linestyle='dashed', linewidth=1, label = r'$\tau_{win,5}$')
# ax78a.axvline(38.72, color='tab:purple', linestyle='dashed', linewidth=1, label = r'$\tau_{win,6}$')
# ax78a.axvline(42.30, color='tab:blue', linestyle='dashed', linewidth=1, label = r'$\tau_{win,7}$')
ax78a.axhspan(20, 23, facecolor='g',
            alpha=0.2, label='Acceptable Thermal Comfort Range')
ax78a.axhspan(18, 20, facecolor='yellow',
            alpha=0.2, label='Low Thermal Comfort Range')
ax78a.set_xlim(left = 0, right = 160) # step 3: For close up of graph
ax78a.set_ylim(top = 21.5, bottom = -7.5)
ax78a.title.set_text(u'Thermal Response to $T_{ext}$= -5.0\N{DEGREE SIGN}C ')
ax78a.legend( bbox_to_anchor=(0, 1.08),loc="lower left", ncol=2)

ax78b.plot(x01, y11, 'tab:orange', label= r'$\tau_{win,4}$ =18.62 hr')
ax78b.plot(x01, y12, 'tab:red', label= r'$\tau_{win,5}$ =26.84 hr')
ax78b.plot(x01, y13, 'tab:purple', label= r'$\tau_{win,6}$ =38.72 hr')
ax78b.plot(x01, y14, 'tab:blue', label= r'$\tau_{win,7}$ =42.30 hr')
# ax78b.set_xlabel('Time, t [hours]')
# ax78b.set_ylabel(u'Indoor Temperature, $T_{in}$ [\N{DEGREE SIGN}C]')
ax78b.axhline(21, color='k', linestyle='dashed', linewidth=1, label = '$T_{in}$ (t=0)')
# ax78b.axvline(18.62, color='tab:orange', linestyle='dashed', linewidth=1, label = r'$\tau_{win,4}$')
# ax78b.axvline(26.84, color='tab:red', linestyle='dashed', linewidth=1, label = r'$\tau_{win,5}$')
# ax78b.axvline(38.72, color='tab:purple', linestyle='dashed', linewidth=1, label = r'$\tau_{win,6}$')
# ax78b.axvline(42.30, color='tab:blue', linestyle='dashed', linewidth=1, label = r'$\tau_{win,7}$')
ax78b.axhspan(20, 23, facecolor='g',
            alpha=0.2, label='Acceptable Thermal \n Comfort Range')
ax78b.axhspan(18, 20, facecolor='yellow',
            alpha=0.2, label='Low Thermal \n Comfort Range')
ax78b.set_xlim(left = 0, right = 7.) # step 3: For close up of graph
ax78b.set_ylim(top = 21.5, bottom = 17.5)
# ax78b.legend(bbox_to_anchor=(.25,1.05), loc="lower left")
# ax78b.legend(bbox_to_anchor=(1.02,0.02), loc="lower left")
ax78b.title.set_text(r'Close-up of Thermal Comfort Ranges')

plt.tight_layout()
# sns.despine(fig=fig78)
fig78.savefig(os.path.join(cwd, 'Figures_TmCstData', 'tempDropLL_cz47Win.png'), dpi=400, bbox_inches='tight')


#%% DFIG 9:BOX PLOT - Time Cst Data Set - Distribution by Season and Climate
#Box 
df_plt80 = df[['Climate Zone','tauWtdMeanRmse0.5','Season']][(df['Climate Zone']!=8)]
fig80, ax80 = plt.subplots(figsize=(6.5,4))
sns.boxplot(x='Climate Zone', y= 'tauWtdMeanRmse0.5', hue= 'Season',    
           palette={'Fall':"orange",'Winter': "skyblue",'Spring': "limegreen",'Summer': "salmon"},
           showmeans=True, meanprops={"marker":"o",
                                        "markerfacecolor":"white", 
                                        "markeredgecolor":"black",
                                        "markersize":"4"},
           fliersize=1,
           data=df_plt80, ax=ax80)
plt.xlabel('Climate Zone')
ax80.set_xticklabels(['1', '2','3','4','5','6','7'])
plt.ylabel(r'$\tau_{mth,k}$ [hours]')
#plt.title(r'Monthly TCC Average ($\tau_{mth}$) by Season and Climate Zone')
plt.tight_layout()
sns.despine(fig=fig80)
fig80.savefig(os.path.join(cwd,'Figures_TmCstData','boxPlt_TmCstData_DistByCz17BySsn.png'), dpi=400,
#       transparent = 'true'
    )

#%% DFIG 10: BAR PLOT/ HEATMAP - Time Cst Data Set  - Dwelling Percentage by all Climate by Sample name
d81_long= df_mdTmCst

cz1 = d81_long['Climate Zone'][(d81_long['Climate Zone']== 1)].value_counts()[1]
cz2 = d81_long['Climate Zone'][(d81_long['Climate Zone']== 2)].value_counts()[2]
cz3 = d81_long['Climate Zone'][(d81_long['Climate Zone']== 3)].value_counts()[3]
cz4 = d81_long['Climate Zone'][(d81_long['Climate Zone']== 4)].value_counts()[4]
cz5 = d81_long['Climate Zone'][(d81_long['Climate Zone']== 5)].value_counts()[5]
cz6 = d81_long['Climate Zone'][(d81_long['Climate Zone']== 6)].value_counts()[6]
cz7 = d81_long['Climate Zone'][(d81_long['Climate Zone']== 7)].value_counts()[7]
cz8 = d81_long['Climate Zone'][(d81_long['Climate Zone']== 8)].value_counts()[8]

cz1b = df_md['Climate Zone'][(df_md['Climate Zone']== 1)].value_counts()[1]
cz2b = df_md['Climate Zone'][(df_md['Climate Zone']== 2)].value_counts()[2]
cz3b = df_md['Climate Zone'][(df_md['Climate Zone']== 3)].value_counts()[3]
cz4b = df_md['Climate Zone'][(df_md['Climate Zone']== 4)].value_counts()[4]
cz5b = df_md['Climate Zone'][(df_md['Climate Zone']== 5)].value_counts()[5]
cz6b = df_md['Climate Zone'][(df_md['Climate Zone']== 6)].value_counts()[6]
cz7b = df_md['Climate Zone'][(df_md['Climate Zone']== 7)].value_counts()[7]
cz8b = df_md['Climate Zone'][(df_md['Climate Zone']== 8)].value_counts()[8]

df_plt81 = pd.DataFrame(data = np.array([[cz1/cz1b*100, cz2/cz2b*100, cz3/cz3b*100,
                                          cz4/cz4b*100, cz5/cz5b*100, cz6/cz6b*100, cz7/cz7b*100]]),
                        columns = ['1', '2', '3', '4', '5', '6', '7'])

df_plt81 = df_plt81.T
df_plt81.index.names = ['Climate Zone']
df_plt81.columns=['Percentage of Original Sample']
df_plt81 = df_plt81.reset_index()

pal81 = sns.color_palette("Blues_r", 1)
fig81, ax81 = plt.subplots(nrows= 1,ncols= 1, figsize=(6,3.5)) 
ax81 =  sns.barplot(data= df_plt81, y='Percentage of Original Sample', x='Climate Zone',  palette=pal81)
for bar in ax81.patches:
    ax81.annotate('{:.0f}'.format(bar.get_height()), 
                xy=(bar.get_x() + bar.get_width()/2, bar.get_height()), 
                xytext= (0,1), 
                textcoords='offset points', 
                ha='center', va='bottom')
plt.xticks(rotation= 0)
plt.xlabel('Climate Zone')
plt.ylabel('Percentage [%]')
ax81.set_ylim([0, max(df_plt81['Percentage of Original Sample'])+10])
plt.title(r'Dwellings yielding $\tau_{mth,k}$ value(s)')
plt.tight_layout()
sns.despine(fig=fig81)
fig81.savefig(os.path.join(cwd,'Figures_TmCstData','barPlt_TmCstDw_PercentageVsCz.png'), dpi=400,
#       transparent = 'true'
    )

#%% DFIG 11: BAR PLOT/ HEATMAP - Time Cst Data Set  - Dwelling Count by all Climate and Season

d82_long= df

cz1 = len(df_cz1)
cz2 = len(df_cz2)
cz3 = len(df_cz3)
cz4 = len(df_cz4)
cz5 = len(df_cz5) 
cz6 = len(df_cz6) 
cz7 = len(df_cz7)
cz8 = len(df_cz8) 
 
cz1Fal = d82_long['Climate Zone'][(d82_long['Climate Zone']== 1) & (d82_long['Season'] == 'Fall')].value_counts()[1]
cz1Win = d82_long['Climate Zone'][(d82_long['Climate Zone']== 1) & (d82_long['Season'] == 'Winter')].value_counts()[1]
cz1Spr = d82_long['Climate Zone'][(d82_long['Climate Zone']== 1) & (d82_long['Season'] == 'Spring')].value_counts()[1]
cz1Sum = d82_long['Climate Zone'][(d82_long['Climate Zone']== 1) & (d82_long['Season'] == 'Summer')].value_counts()[1]

cz2Fal = d82_long['Climate Zone'][(d82_long['Climate Zone']== 2) & (d82_long['Season'] == 'Fall')].value_counts()[2]
cz2Win = d82_long['Climate Zone'][(d82_long['Climate Zone']== 2) & (d82_long['Season'] == 'Winter')].value_counts()[2]
cz2Spr = d82_long['Climate Zone'][(d82_long['Climate Zone']== 2) & (d82_long['Season'] == 'Spring')].value_counts()[2]
cz2Sum = d82_long['Climate Zone'][(d82_long['Climate Zone']== 2) & (d82_long['Season'] == 'Summer')].value_counts()[2]

cz3Fal = d82_long['Climate Zone'][(d82_long['Climate Zone']== 3) & (d82_long['Season'] == 'Fall')].value_counts()[3]
cz3Win = d82_long['Climate Zone'][(d82_long['Climate Zone']== 3) & (d82_long['Season'] == 'Winter')].value_counts()[3]
cz3Spr = d82_long['Climate Zone'][(d82_long['Climate Zone']== 3) & (d82_long['Season'] == 'Spring')].value_counts()[3]
cz3Sum = d82_long['Climate Zone'][(d82_long['Climate Zone']== 3) & (d82_long['Season'] == 'Summer')].value_counts()[3]

cz4Fal = d82_long['Climate Zone'][(d82_long['Climate Zone']== 4) & (d82_long['Season'] == 'Fall')].value_counts()[4]
cz4Win = d82_long['Climate Zone'][(d82_long['Climate Zone']== 4) & (d82_long['Season'] == 'Winter')].value_counts()[4]
cz4Spr = d82_long['Climate Zone'][(d82_long['Climate Zone']== 4) & (d82_long['Season'] == 'Spring')].value_counts()[4]
cz4Sum = d82_long['Climate Zone'][(d82_long['Climate Zone']== 4) & (d82_long['Season'] == 'Summer')].value_counts()[4]

cz5Fal = d82_long['Climate Zone'][(d82_long['Climate Zone']== 5) & (d82_long['Season'] == 'Fall')].value_counts()[5]
cz5Win = d82_long['Climate Zone'][(d82_long['Climate Zone']== 5) & (d82_long['Season'] == 'Winter')].value_counts()[5]
cz5Spr = d82_long['Climate Zone'][(d82_long['Climate Zone']== 5) & (d82_long['Season'] == 'Spring')].value_counts()[5]
cz5Sum = d82_long['Climate Zone'][(d82_long['Climate Zone']== 5) & (d82_long['Season'] == 'Summer')].value_counts()[5]

cz6Fal = d82_long['Climate Zone'][(d82_long['Climate Zone']== 6) & (d82_long['Season'] == 'Fall')].value_counts()[6]
cz6Win = d82_long['Climate Zone'][(d82_long['Climate Zone']== 6) & (d82_long['Season'] == 'Winter')].value_counts()[6]
cz6Spr = d82_long['Climate Zone'][(d82_long['Climate Zone']== 6) & (d82_long['Season'] == 'Spring')].value_counts()[6]
cz6Sum = d82_long['Climate Zone'][(d82_long['Climate Zone']== 6) & (d82_long['Season'] == 'Summer')].value_counts()[6]

cz7Fal = d82_long['Climate Zone'][(d82_long['Climate Zone']== 7) & (d82_long['Season'] == 'Fall')].value_counts()[7]
cz7Win = d82_long['Climate Zone'][(d82_long['Climate Zone']== 7) & (d82_long['Season'] == 'Winter')].value_counts()[7]
cz7Spr = d82_long['Climate Zone'][(d82_long['Climate Zone']== 7) & (d82_long['Season'] == 'Spring')].value_counts()[7]
cz7Sum = d82_long['Climate Zone'][(d82_long['Climate Zone']== 7) & (d82_long['Season'] == 'Summer')].value_counts()[7]

cz8Fal = 0
# d82_long['Climate Zone'][(d82_long['Climate Zone']== 8) & (d82_long['Season'] == 'Fall')].value_counts()[8]
cz8Win = d82_long['Climate Zone'][(d82_long['Climate Zone']== 8) & (d82_long['Season'] == 'Winter')].value_counts()[8]
cz8Spr = 0
# d82_long['Climate Zone'][(d82_long['Climate Zone']== 8) & (d82_long['Season'] == 'Spring')].value_counts()[8]
cz8Sum = d82_long['Climate Zone'][(d82_long['Climate Zone']== 8) & (d82_long['Season'] == 'Summer')].value_counts()[8]

df_plt82 = pd.DataFrame(data = np.array([[cz1Fal/cz1*100, cz2Fal/cz2*100, cz3Fal/cz3*100, cz4Fal/cz4*100, cz5Fal/cz5*100, cz6Fal/cz6*100, cz7Fal/cz7*100], 
                                         [cz1Win/cz1*100, cz2Win/cz2*100, cz3Win/cz3*100, cz4Win/cz4*100, cz5Win/cz5*100, cz6Win/cz6*100, cz7Win/cz7*100],
                                         [cz1Spr/cz1*100, cz2Spr/cz2*100, cz3Spr/cz3*100, cz4Spr/cz4*100, cz5Spr/cz5*100, cz6Spr/cz6*100, cz7Spr/cz7*100],
                                         [cz1Sum/cz1*100, cz2Sum/cz2*100, cz3Sum/cz3*100, cz4Sum/cz4*100, cz5Sum/cz5*100, cz6Sum/cz6*100, cz7Sum/cz7*100]]), 
                        index = ['Fall','Winter', 'Spring', 'Summer'],
                        columns = ['1', '2', '3', '4', '5', '6', '7'])
df_plt82 = df_plt82.unstack()
df_plt82.index.names = ['Climate Zone','Season']
df_plt82=df_plt82.to_frame()
df_plt82.columns=['Percentage [%]']
df_plt82 = df_plt82.reset_index()

pal82 = {'Fall':"orange",'Winter': "skyblue",'Spring': "limegreen",'Summer': "salmon"}
fig82, ax82 = plt.subplots(nrows= 1,ncols= 1, figsize=(7,9))
ax82 =  sns.barplot(data= df_plt82, x='Percentage [%]', y='Climate Zone', hue ='Season', palette=pal82, orient='h')
# Annotate every single Bar with its value, based on it's width           
for p in ax82.patches:
    width = p.get_width()
    plt.text(1+p.get_width(), p.get_y()+0.55*p.get_height(),
             '{:.0f}'.format(width),
             ha='left', va='center')
ax82.set_xlim([0, max(df_plt82['Percentage [%]'])+10])
plt.xlabel(r'Percentage of [%]')
plt.title(r'Seasonal breakdown of $\tau_{mth,k}$ values per zone')
plt.setp(ax82.get_legend().get_title(), fontsize='13') # for legend title
plt.rc('font', size=14)          # controls default text sizes
plt.rc('axes', titlesize=14)     # fontsize of the axes title
plt.rc('axes', labelsize=16)    # fontsize of the x and y labels
plt.rc('xtick', labelsize=14)    # fontsize of the tick labels
plt.rc('ytick', labelsize=14)    # fontsize of the tick labels
plt.rc('legend', fontsize=13)    # legend fontsize
# plt.rc('figure', titlesize=24)  # fontsize of the figure title
plt.tight_layout()
sns.despine(fig=fig82)
fig82.savefig(os.path.join(cwd,'Figures_TmCstData','barPlt_TmCstDw_CountVsCzBySeason.png'), dpi=400,
#       transparent = 'true'
    )

#%% DFIG 12: BAR PLOT/ HEATMAP - Time Cst Data Set  - Tau Value Percentage by all Climate and Season

d83_long= df

cz1 = len(df_cz1)
cz2 = len(df_cz2)
cz3 = len(df_cz3)
cz4 = len(df_cz4)
cz5 = len(df_cz5) 
cz6 = len(df_cz6) 
cz7 = len(df_cz7)
cz8 = len(df_cz8) 
 
cz1Fal = d83_long['Climate Zone'][(d83_long['Climate Zone']== 1) & (d83_long['Season'] == 'Fall')].value_counts()[1]
cz1Win = d83_long['Climate Zone'][(d83_long['Climate Zone']== 1) & (d83_long['Season'] == 'Winter')].value_counts()[1]
cz1Spr = d83_long['Climate Zone'][(d83_long['Climate Zone']== 1) & (d83_long['Season'] == 'Spring')].value_counts()[1]
cz1Sum = d83_long['Climate Zone'][(d83_long['Climate Zone']== 1) & (d83_long['Season'] == 'Summer')].value_counts()[1]

cz2Fal = d83_long['Climate Zone'][(d83_long['Climate Zone']== 2) & (d83_long['Season'] == 'Fall')].value_counts()[2]
cz2Win = d83_long['Climate Zone'][(d83_long['Climate Zone']== 2) & (d83_long['Season'] == 'Winter')].value_counts()[2]
cz2Spr = d83_long['Climate Zone'][(d83_long['Climate Zone']== 2) & (d83_long['Season'] == 'Spring')].value_counts()[2]
cz2Sum = d83_long['Climate Zone'][(d83_long['Climate Zone']== 2) & (d83_long['Season'] == 'Summer')].value_counts()[2]

cz3Fal = d83_long['Climate Zone'][(d83_long['Climate Zone']== 3) & (d83_long['Season'] == 'Fall')].value_counts()[3]
cz3Win = d83_long['Climate Zone'][(d83_long['Climate Zone']== 3) & (d83_long['Season'] == 'Winter')].value_counts()[3]
cz3Spr = d83_long['Climate Zone'][(d83_long['Climate Zone']== 3) & (d83_long['Season'] == 'Spring')].value_counts()[3]
cz3Sum = d83_long['Climate Zone'][(d83_long['Climate Zone']== 3) & (d83_long['Season'] == 'Summer')].value_counts()[3]

cz4Fal = d83_long['Climate Zone'][(d83_long['Climate Zone']== 4) & (d83_long['Season'] == 'Fall')].value_counts()[4]
cz4Win = d83_long['Climate Zone'][(d83_long['Climate Zone']== 4) & (d83_long['Season'] == 'Winter')].value_counts()[4]
cz4Spr = d83_long['Climate Zone'][(d83_long['Climate Zone']== 4) & (d83_long['Season'] == 'Spring')].value_counts()[4]
cz4Sum = d83_long['Climate Zone'][(d83_long['Climate Zone']== 4) & (d83_long['Season'] == 'Summer')].value_counts()[4]

cz5Fal = d83_long['Climate Zone'][(d83_long['Climate Zone']== 5) & (d83_long['Season'] == 'Fall')].value_counts()[5]
cz5Win = d83_long['Climate Zone'][(d83_long['Climate Zone']== 5) & (d83_long['Season'] == 'Winter')].value_counts()[5]
cz5Spr = d83_long['Climate Zone'][(d83_long['Climate Zone']== 5) & (d83_long['Season'] == 'Spring')].value_counts()[5]
cz5Sum = d83_long['Climate Zone'][(d83_long['Climate Zone']== 5) & (d83_long['Season'] == 'Summer')].value_counts()[5]

cz6Fal = d83_long['Climate Zone'][(d83_long['Climate Zone']== 6) & (d83_long['Season'] == 'Fall')].value_counts()[6]
cz6Win = d83_long['Climate Zone'][(d83_long['Climate Zone']== 6) & (d83_long['Season'] == 'Winter')].value_counts()[6]
cz6Spr = d83_long['Climate Zone'][(d83_long['Climate Zone']== 6) & (d83_long['Season'] == 'Spring')].value_counts()[6]
cz6Sum = d83_long['Climate Zone'][(d83_long['Climate Zone']== 6) & (d83_long['Season'] == 'Summer')].value_counts()[6]

cz7Fal = d83_long['Climate Zone'][(d83_long['Climate Zone']== 7) & (d83_long['Season'] == 'Fall')].value_counts()[7]
cz7Win = d83_long['Climate Zone'][(d83_long['Climate Zone']== 7) & (d83_long['Season'] == 'Winter')].value_counts()[7]
cz7Spr = d83_long['Climate Zone'][(d83_long['Climate Zone']== 7) & (d83_long['Season'] == 'Spring')].value_counts()[7]
cz7Sum = d83_long['Climate Zone'][(d83_long['Climate Zone']== 7) & (d83_long['Season'] == 'Summer')].value_counts()[7]

cz8Fal = 0
# d83_long['Climate Zone'][(d83_long['Climate Zone']== 8) & (d83_long['Season'] == 'Fall')].value_counts()[8]
cz8Win = d83_long['Climate Zone'][(d83_long['Climate Zone']== 8) & (d83_long['Season'] == 'Winter')].value_counts()[8]
cz8Spr = 0
# d83_long['Climate Zone'][(d83_long['Climate Zone']== 8) & (d83_long['Season'] == 'Spring')].value_counts()[8]
cz8Sum = d83_long['Climate Zone'][(d83_long['Climate Zone']== 8) & (d83_long['Season'] == 'Summer')].value_counts()[8]

df_plt83 = pd.DataFrame(data = np.array([[cz1Fal/cz1*100, cz2Fal/cz2*100, cz3Fal/cz3*100, cz4Fal/cz4*100, cz5Fal/cz5*100, cz6Fal/cz6*100, cz7Fal/cz7*100], 
                                         [cz1Win/cz1*100, cz2Win/cz2*100, cz3Win/cz3*100, cz4Win/cz4*100, cz5Win/cz5*100, cz6Win/cz6*100, cz7Win/cz7*100],
                                         [cz1Spr/cz1*100, cz2Spr/cz2*100, cz3Spr/cz3*100, cz4Spr/cz4*100, cz5Spr/cz5*100, cz6Spr/cz6*100, cz7Spr/cz7*100],
                                         [cz1Sum/cz1*100, cz2Sum/cz2*100, cz3Sum/cz3*100, cz4Sum/cz4*100, cz5Sum/cz5*100, cz6Sum/cz6*100, cz7Sum/cz7*100]]), 
                        index = ['Fall','Winter', 'Spring', 'Summer'],
                        columns = ['1', '2', '3', '4', '5', '6', '7'])

df_plt83.index.names = ['Season']
df_plt83 = df_plt83.round(decimals=1)

fig83, ax83 = plt.subplots(nrows= 1,ncols= 1, figsize=(7,4.25))
sns.heatmap(df_plt83, annot=True, fmt="g", linewidths=.5, ax=ax83, cmap='YlGnBu', cbar_kws={'label': r'Percentage of $\tau_{mth,k}$ values [%]'})
ax83.set_xticklabels(['1', '2', '3', '4', '5', '6', '7'])
plt.xlabel('Climate Zone')
plt.ylabel('Season')
ax83.set_yticklabels(['Fall', 'Winter', 'Spring', 'Summer'], rotation = 360)
# plt.title(r'Seasonal breakdown of $\tau_{mth,k}$ values')
plt.tight_layout()
sns.despine(fig=fig83)
fig83.savefig(os.path.join(cwd,'Figures_TmCstData','heatMap_TmCstData_PercentageVsCzBySeason.png'), dpi=400,
#       transparent = 'true'
    )



#%% DFIG 13: SCATTER PLOT  - Time Cst Data set - Means and medians by Climate

d84_long = df

# sns.distplot(d26_long['tauWtdMeanRmse0.5'][(d26_long['Climate Zone']== 1)])
# sns.distplot(d26_long['tauWtdMeanRmse0.5'][(d26_long['Climate Zone']== 2)])
# sns.distplot(d26_long['tauWtdMeanRmse0.5'][(d26_long['Climate Zone']== 3)])
# sns.distplot(d26_long['tauWtdMeanRmse0.5'][(d26_long['Climate Zone']== 4)])
# sns.distplot(d26_long['tauWtdMeanRmse0.5'][(d26_long['Climate Zone']== 5)])
# sns.distplot(d26_long['tauWtdMeanRmse0.5'][(d26_long['Climate Zone']== 6)])
# sns.distplot(d26_long['tauWtdMeanRmse0.5'][(d26_long['Climate Zone']== 7)])
# sns.distplot(d26_long['tauWtdMeanRmse0.5'][(d26_long['Climate Zone']== 8)])

cz1Win_stats = df_cz1Win['tauWtdMeanRmse0.5'].describe()
cz2Win_stats = df_cz2Win['tauWtdMeanRmse0.5'].describe()
cz3Win_stats = df_cz3Win['tauWtdMeanRmse0.5'].describe()
cz4Win_stats = df_cz4Win['tauWtdMeanRmse0.5'].describe()
cz5Win_stats = df_cz5Win['tauWtdMeanRmse0.5'].describe()
cz6Win_stats = df_cz6Win['tauWtdMeanRmse0.5'].describe()
cz7Win_stats = df_cz7Win['tauWtdMeanRmse0.5'].describe()
cz8Win_stats = df_cz8Win['tauWtdMeanRmse0.5'].describe()

cz1Sum_stats = df_cz1Sum['tauWtdMeanRmse0.5'].describe()
cz2Sum_stats = df_cz2Sum['tauWtdMeanRmse0.5'].describe()
cz3Sum_stats = df_cz3Sum['tauWtdMeanRmse0.5'].describe()
cz4Sum_stats = df_cz4Sum['tauWtdMeanRmse0.5'].describe()
cz5Sum_stats = df_cz5Sum['tauWtdMeanRmse0.5'].describe()
cz6Sum_stats = df_cz6Sum['tauWtdMeanRmse0.5'].describe()
cz7Sum_stats = df_cz7Sum['tauWtdMeanRmse0.5'].describe()

win_plt84 = pd.DataFrame(data = np.array([[cz1Win_stats[1], cz2Win_stats[1], cz3Win_stats[1], cz4Win_stats[1], cz5Win_stats[1], cz6Win_stats[1], cz7Win_stats[1]],
                                         [cz1Win_stats[5], cz2Win_stats[5], cz3Win_stats[5], cz4Win_stats[5], cz5Win_stats[5], cz6Win_stats[5], cz7Win_stats[5]]]), 
                        index = ['Mean','Median'],
                        columns = ['1', '2', '3', '4', '5', '6', '7',])
win_plt84 = win_plt84.unstack()
win_plt84.index.names = ['Climate Zone','Statistic']
win_plt84=win_plt84.to_frame()
win_plt84.columns=['Value']
win_plt84['Season'] = 'Winter'

sum_plt84 = pd.DataFrame(data = np.array([[cz1Sum_stats[1], cz2Sum_stats[1], cz3Sum_stats[1], cz4Sum_stats[1], cz5Sum_stats[1], cz6Sum_stats[1], cz7Sum_stats[1]],
                                         [cz1Sum_stats[5], cz2Sum_stats[5], cz3Sum_stats[5], cz4Sum_stats[5], cz5Sum_stats[5], cz6Sum_stats[5], cz7Sum_stats[5]]]), 
                        index = ['Mean','Median'],
                        columns = ['1', '2', '3', '4', '5', '6', '7',])
sum_plt84 = sum_plt84.unstack()
sum_plt84.index.names = ['Climate Zone','Statistic']
sum_plt84=sum_plt84.to_frame()
sum_plt84.columns=['Value']
sum_plt84['Season'] = 'Summer'


df_plt84 = pd.concat([win_plt84, sum_plt84])
df_plt84 = df_plt84.reset_index()

fig84, ax84 = plt.subplots(nrows= 1,ncols= 1, figsize=(8, 5))
#Plot Data
sns.scatterplot(x="Climate Zone", y="Value", style="Statistic", hue='Season', s=100, palette={'Winter': "skyblue",'Summer': "salmon"}, data=df_plt84, ax=ax84)
ax84.set_xticks(ticks = [1.,2.,3.,4.,5.,6.,7.])
#Set outer labels and layout
ax84.set_ylabel(r'Average $\tau_{mth,k}$ [hours]')
plt.tight_layout()
sns.despine(fig=fig84)
fig84.savefig(os.path.join(cwd,'Figures_TmCstData','sctrPlt_TmCstData_StatByCz17ByWinSum.png'), dpi=400,
#       transparent = 'true'
    )

#%% DFIG 14: SETBACK EXAMPLE for Lit Rev

x02 = np.array([0, 6, 8, 18, 22, 24])
y85_1 = np.array([19, 20, 17, 20, 19, 19]) #heat
y85_2 = np.array([25, 23, 28, 23, 25, 25]) #cool
  
fig85, (ax85a, ax85b) = plt.subplots(nrows= 2,ncols= 1, figsize=(9., 5.), sharex = True)
ax85a.axhline(20., color='k', linestyle='dashed', linewidth=2, label= u'Normal Setpoint')
ax85a.step(x02, y85_1, color='r', linewidth=2.5, where='post')
ax85a.axvspan(0, 6, facecolor='purple',
            alpha=0.15, label='Sleep')
ax85a.axvspan(8, 18, facecolor='g',
            alpha=0.15, label='Away')
ax85a.axvspan(22, 24, facecolor='purple',
            alpha=0.15)
ax85a.set_xlim(left = 0., right = 23.99)
ax85a.set_ylim(top = 21, bottom = 16.)
ax85a.set_ylabel(u'Heating Mode \n Setpoint [\N{DEGREE SIGN}C]')
ax85a.legend(bbox_to_anchor=(0.5,1.02), loc="lower center", ncol=3)

ax85b.axhline(23., color= 'k', linestyle='dashed', linewidth=2, label= u'Normal Setpoint')
ax85b.step(x02, y85_2, color='b', linewidth=2.5, where='post')
ax85b.axvspan(0, 6, facecolor='purple',
            alpha=0.15, label='Sleep')
ax85b.axvspan(8, 18, facecolor='g',
            alpha=0.15, label='Away')
ax85b.axvspan(22, 24, facecolor='purple',
            alpha=0.15)
ax85b.set_xlim(left = 0., right = 23.99)
ax85b.set_ylim(top = 29, bottom = 22.)
ax85b.set_ylabel(u'Cooling Mode \n Setpoint  [\N{DEGREE SIGN}C]')
ax85b.set_xlabel('Hour of the day')
plt.tight_layout()
# sns.despine(fig=fig85)
fig85.savefig(os.path.join(cwd, 'Figures_TmCstData', 'SetbackExample.png'), dpi=400, bbox_inches='tight')

#%% MAIN BODY OF CODE - End
#%% NOTES - Start


#%% NOTES - End




