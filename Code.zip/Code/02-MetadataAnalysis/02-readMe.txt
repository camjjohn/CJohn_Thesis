Note001.For filtering and reformatting metadata:
- requires file metadata.csv from folder 01-Data/0000-00
- use metadataDataframe.py and 
functions_metadataDataframe.py
- files created saved to folders mdAll, mdCaUs, 
mdProj
- folder mdProj contains the files used for the 
study
- files created include mdAll.csv, mdCaUs.csv, 
detached_mdCaUs.csv, citySelection_CaUs.csv,
CommonIdsCln_201709-201808.csv, 
CommonIdsCln_201609-201808.csv,
CommonIdsCln_201509-201808.csv,
mdProj.csv, CommonIdsProj_201709-201808.csv,
CommonIdsProj_201609-201808.csv,
CommonIdsProj_201509-201808.csv

Note002.For retrieval of latitude, longitude and time zone for 
unique cities used in the study:
- requires file CommonIdsProj_201709-201808.csv 
from folder 01-Data/mdProj
- use file assignLatLongTz.py
- file created is cities_LatLongTz.csv

Note003.For manually assigning the UTC offset to 
file cities_LatLongTz.csv:
- use file pytz_mdproj_utcOffset.csv for a list of 
all time zones in the study and their corresponding 
UTC offset

Note004.For assigning a sunrise and sunset 
to each month (using the longest day of the month):
- requires file cities_LatLongTz.csv from folder 01-Data/mdProj
- use file assignSuntime.py and functions_assignSuntime.py
- files created include cities_LatLongTzSuntime.csv

