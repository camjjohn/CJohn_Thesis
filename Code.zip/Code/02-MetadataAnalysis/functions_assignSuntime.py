# -*- coding: utf-8 -*-
"""
Created on Sat May 25 01:47:52 2019

@author: Camille John
"""

#%% CUSTOM FUNCTIONS FOR SUNRISE & SUNSET BASED ON LATITUDE AND LONGITUDE
#%%DOCUMENT SETUP
# Planet and Star Position Computation library
import ephem
# Time access and conversion library
import datetime as dt
# Time Zone Identification library
from timezonefinder import TimezoneFinder
tf = TimezoneFinder(in_memory=True)

#%%CUSTOM FUNCTIONS
def sunrise(lat, long, date, utc_offset):
    #defining an observer
    obs = ephem.Observer()
    obs.lat = ephem.degrees(str(lat))    
    obs.long = ephem.degrees(str(long))
    obs.date = ephem.Date(date)
    #defining an astronomic object; Sun in this case
    sun = ephem.Sun(obs)
    #defining local time with daylight savings
    r1 = obs.next_rising(sun) #UTC time
    (y,mn,d,h,min,s) = r1.tuple()
    r1_lt = dt.datetime(y,mn,d,h,min,int(s)) + dt.timedelta(hours=utc_offset) #local time 
    return (r1, r1_lt)

def sunset(lat, long, date, utc_offset):
    #defining an observer
    obs = ephem.Observer()
    obs.lat = ephem.degrees(str(lat))    
    obs.long = ephem.degrees(str(long))
    obs.date = ephem.Date(date)
    #defining an astronomic object; Sun in this case
    sun = ephem.Sun(obs)
    #defining local time with daylight savings
    s1 = obs.next_setting(sun) #UTC time
    (y,mn,d,h,min,s) = s1.tuple()
    s1_lt = dt.datetime(y,mn,d,h,min,int(s)) + dt.timedelta(hours=utc_offset) #local time
    # sunset correction - western hemisphere only
    test = s1_lt
    if (date.day != test.day): #if day behind
        corr = test.date() + dt.timedelta(days=2)
        #defining an observer
        obs2 = ephem.Observer()
        obs2.lat = ephem.degrees(str(lat))
        obs2.long = ephem.degrees(str(long))
        obs2.date = ephem.Date(corr)
        #defining an astronomic object; Sun in this case
        sun = ephem.Sun(obs2)
        #defining local time with daylight savings
        s1 = obs2.next_setting(sun)
        (y,mn,d,h,min,s) = s1.tuple()
        s1_lt = dt.datetime(y,mn,d,h,min,int(s)) + dt.timedelta(hours=utc_offset) #local time
    return (s1, s1_lt)

