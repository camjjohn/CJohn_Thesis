# -*- coding: utf-8 -*-
"""
Created on Thu Feb 28 06:41:06 2019

@author: Camille John
"""

#%% CREATION OF METADATA DATAFRAME
#%% DOCUMENT SETUP
# Scientific libraries
import numpy as np
# Data analysis libraries
import pandas as pd
# Operating system library
import os
cwd = os.getcwd()
# Custom Functions
from functions_metadataDataframe import LoadMetaDataFile, NumMissingInput, DataframeProcessing

#%% MAIN BODY OF CODE - Start    
#%% STEP 1: INPUTS
yyyy_mm = '0000-00'
identifier = 'metadata'

#%% STEP 2: LOAD METADATA FILE
df_md = LoadMetaDataFile(yyyy_mm, identifier)
#%% STEP 3: ORIGINAL METADATA DESCRIPTION
# Check out info of dataframe
print ('\n')
print ('\n')
print ("+ ORIGINAL METADATA DATAFRAME:")
print ('\n')
df_md.info()
print ('\n')
df_md_stats = df_md.describe()
#Applying per column:
print ("No. of Missing Inputs per column:")
print (df_md.apply(NumMissingInput, axis=0)) #axis=0 defines that function is to be applied on each column
##Applying per row:
#print "\n No. of Missing Inputs per row:"
#print df_md.apply(NumMissingInput, axis=1) #axis=1 defines that function is to be applied on each row# Column  0: 'Identifier'
print ('\n')


print('Total number of registered residences in database: %d' %(len(df_md.index)))
print ('\n')
#%% STEP 4: METADATA PROCESSING 
# All Users
# Processing and save the 3 CommonIdCln (1 year, 2 years, and 3 years)
df_mdAll = DataframeProcessing(df_md)

#%% STEP 5: PROCESSED METADATA DATAFRAME
# Check out info of dataframe

#correct discrepency (entry for m2 when no entry for listed ft2)
#df_md.iloc[df_md[['Floor Area [ft2]', 'Floor Area [m2]']].loc[
#            (df_md['Floor Area [ft2]'].isnull()) & (df_md['Floor Area [m2]'].notnull())
#            ].index.values, 18] = np.nan
len(df_md[['Floor Area [ft2]', 'Floor Area [m2]']].loc[
            (df_md['Floor Area [ft2]'].isnull()) & (df_md['Floor Area [m2]'].notnull())
            ].index.values)
df_mdAll.iloc[df_mdAll[['Floor Area [ft2]', 'Floor Area [m2]']].loc[
            (df_mdAll['Floor Area [ft2]'].isnull()) & (df_mdAll['Floor Area [m2]'].notnull())
            ].index.values, 18] = np.nan

print ('\n')
print ('\n')
print ("+ PROCESSED METADATA DATAFRAME:")
print ('\n')
df_mdAll.info()
print ('\n')
df_mdAll_stats = df_mdAll.describe()
#Applying per column:
print ("No. of Missing Inputs per column:")
print (df_mdAll.apply(NumMissingInput, axis=0)) #axis=0 defines that function is to be applied on each column
##Applying per row:
#print "\n No. of Missing Inputs per row:"
#print df_mdAll.apply(NumMissingInput, axis=1) #axis=1 defines that function is to be applied on each row# Column  0: 'Identifier'
print ('\n')

# Column  3: 'Country'
countriesUnique = df_mdAll['Country'].sort_values().drop_duplicates()

# Column  4: 'ProvinceState'
provincesUnique = pd.concat([df_mdAll['Country'], df_mdAll['ProvinceState']],
                                 axis=1).sort_values(['Country','ProvinceState']
                                 ).drop_duplicates().dropna()
provincesUnique['freq'] = df_mdAll.groupby(['Country','ProvinceState']).size().values

# Column  5: 'City'
citiesUnique = pd.concat([df_mdAll['Country'], df_mdAll['ProvinceState'], 
                             df_mdAll['City']], axis=1).sort_values(['Country', 'ProvinceState','City']
                            ).drop_duplicates().dropna()
citiesUnique['freq'] = df_mdAll.groupby(['Country','ProvinceState', 'City']).size().values

# Column  7: 'Style'
stylesUnique = pd.concat([df_mdAll['Style']], axis=1).sort_values(['Style']).drop_duplicates().dropna()
stylesUnique['freq'] = df_mdAll.groupby(['Style']).size().values

#%% SAVED
df_mdAll.to_csv(os.path.join(cwd,'mdAll', 'mdAll.csv' ), index = False)

#%% STEP 6: CANADA AND US
df_mdCaUs = df_mdAll.loc[(df_mdAll['Country'] == 'CA') | (df_mdAll['Country'] == 'US')]

# Column  5: 'City'
citiesUnique_CaUs = pd.concat([df_mdCaUs['Country'], df_mdAll['ProvinceState'], 
                             df_mdAll['City']], axis=1).sort_values(['Country', 'ProvinceState','City']
                            ).drop_duplicates().dropna()
print('Total Number of Canadian and American cities: %d' %(len(citiesUnique_CaUs.index)))
print ('\n')
#%% SAVED
df_mdCaUs.to_csv(os.path.join(cwd,'mdCaUs', 'mdCaUs.csv'), index = False)

#%% STEP 7: STYLES OF RESIDENCE

#Check number of users per style (eg. Detached)
stylesByLoc = pd.concat([df_mdCaUs['Country'], df_mdCaUs['ProvinceState'], 
                             df_mdCaUs['City'], df_mdCaUs['Style']], axis=1).sort_values(['Country', 'ProvinceState','City', 'Style']
                            ).drop_duplicates().dropna()
stylesByLoc['freq'] = df_mdCaUs.groupby(['Country','ProvinceState', 'City', 'Style']).size().values
# Location selection (driven by most populated by detached houses)
detachedByLoc = stylesByLoc.loc[(stylesByLoc['Style'] == 'Detached')]
detachedCa = detachedByLoc.loc[(detachedByLoc['Country'] == 'CA') & (detachedByLoc['freq'] >= 0)].reset_index()
detachedUs = detachedByLoc.loc[(detachedByLoc['Country'] == 'US') & (detachedByLoc['freq'] >= 0)].reset_index()
detachedCa_num= detachedCa['freq'].sum()
detachedUs_num= detachedUs['freq'].sum()
detached_mdCaUs = pd.concat([detachedCa,detachedUs])
#%% SAVED
detached_mdCaUs.to_csv(os.path.join(cwd,'mdCaUs', 'detached_mdCaUs.csv'), index = False)

#%% STEP 8: LOCATION SELECTION 
#Project Cities
citySelection = pd.read_csv(os.path.join(cwd,'mdCaUs', 'citySelection_CaUs.csv'))
citySelection.drop(columns = 'Style', inplace = True)
citySelection.dropna(inplace= True)
#All Users Cananadian and US Users (project-related)
df_mdProj = pd.merge(df_mdCaUs, citySelection, on = ['Country','ProvinceState','City'])
df_mdProj.columns
columnsTitles = ['Identifier', 'Model',  'Climate Zone', 'Country', 'ProvinceState', 'City',  'Frequency [detachedByLoc]',
                 'Floor Area [ft2]', 'Floor Area [m2]', 'Style', 'Number of Floors', 'Age of Home [years]', 
                 'Number of Occupants', 'Number of Remote Sensors', 
                 'installedCoolStages', 'installedHeatStages', 
                 'allowCompWithAux', 'Has Electric', 'Has a Heat Pump', 'Auxilliary Heat Fuel Type', 
                 'filename']
df_mdProj = df_mdProj.reindex(columns=columnsTitles)
# Check out info of dataframe
print ('\n')
print ('\n')
print ("+  METADATA SELECTION:")
print ('\n')
df_mdProj.info()
print ('\n')
df_mdProj_stats = df_mdProj.describe()
#Applying per column:
print ("No. of Missing Inputs per column:")
print (df_mdProj.apply(NumMissingInput, axis=0)) #axis=0 defines that function is to be applied on each column

df_mdProj['Number of Floors'].mode()
len(df_mdProj['Number of Floors'][(df_mdProj['Number of Floors'] ==2)])

commonIds1 = pd.read_csv(os.path.join(cwd,'mdAll', 'CommonIdsCln_201709-201808.csv'))
commonIds1 = pd.merge(commonIds1, df_mdProj, on = ['filename'])
print('Number of selected residences common to every month from 2017-09 to 2018-08: %d' %(len(commonIds1.index)))
print ('\n')
commonIds2 = pd.read_csv(os.path.join(cwd,'mdAll', 'CommonIdsCln_201609-201808.csv'))
commonIds2 = pd.merge(commonIds2, df_mdProj, on = ['filename'])
print('Number of selected registered residences common to every month from 2016-09 to 2018-08: %d' %(len(commonIds2.index)))
print ('\n')
commonIds3 = pd.read_csv(os.path.join(cwd,'mdAll', 'CommonIdsCln_201509-201808.csv'))
commonIds3 = pd.merge(commonIds3, df_mdProj, on = ['filename'])
print('Number of selected registered residences common to every month from 2015-09 to 2018-08: %d' %(len(commonIds3.index)))
print ('\n')

#%% SAVED
df_mdProj.to_csv(os.path.join(cwd,'mdProj', 'mdProj.csv'), index = False)
commonIds1.to_csv(os.path.join(cwd,'mdProj', 'CommonIdsProj_201709-201808.csv'), index = False)
commonIds2.to_csv(os.path.join(cwd,'mdProj', 'CommonIdsProj_201609-201808.csv'), index = False)
commonIds3.to_csv(os.path.join(cwd,'mdProj', 'CommonIdsProj_201509-201808.csv'), index = False)
#%% MAIN BODY OF CODE - End  
#%% NOTES - Start  
#testNames = df_mdAll[['Country', 'ProvinceState', 'City']].loc[(df_mdAll['Country'] == 'CA')
#    ].sort_values(['Country','ProvinceState', 'City']).drop_duplicates() #Canada
#testNames = df_mdAll[['Country', 'ProvinceState', 'City']].loc[(df_mdAll['Country'] == 'US')
#    ].sort_values(['Country','ProvinceState', 'City']).drop_duplicates() #United States
#%% NOTES - End