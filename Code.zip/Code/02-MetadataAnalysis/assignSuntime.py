# -*- coding: utf-8 -*-
"""
Created on Thu May 23 03:59:05 2019

@author: Camille John
"""

#%%SUNRISE & SUNSET BASED ON LATITUDE AND LONGITUDE
#%%DOCUMENT SETUP
# Scientific libraries
import numpy as np
# Operating system library
import os
cwd = os.getcwd()
# Data analysis libraries
import pandas as pd
# Planet and Star Position Computation library
import ephem
# Time access and conversion library
import time as tm
import datetime as dt
# Time Zone Identification library
from timezonefinder import TimezoneFinder
tf = TimezoneFinder(in_memory=True)
# Custom Functions
from functions_assignSuntime import sunrise, sunset

#%% MAIN CODE - Start
#%% STEP 1: INPUTS
# Create dataframe of meta data referenced
metaData = 'mdProj'
fileName = 'cities_LatLongTz.csv'
dateSun = pd.DataFrame(data = {'Date':[dt.datetime(2017,9,1), dt.datetime(2017,10,1), dt.datetime(2017,11,1), 
                                        dt.datetime(2017,12,1), dt.datetime(2018,1,31), dt.datetime(2018,2,28), 
                                        dt.datetime(2018,3,31), dt.datetime(2018,4,30), dt.datetime(2018,5,31), 
                                        dt.datetime(2018,6,21), dt.datetime(2018,7,1), dt.datetime(2018,8,1)]},
                        index = ['2017-09', '2017-10', '2017-11', 
                                '2017-12', '2018-01', '2018-02', 
                                '2018-03', '2018-04', '2018-05', 
                                '2018-06', '2018-07', '2018-08'])

#%% STEP 1: LOAD LATLONGTZ FILE
cwd = os.getcwd()  # cwd: current working directory
# Creates dataframe
filePath = os.path.join(cwd, metaData, fileName)
df_md = pd.DataFrame()
df_md = pd.read_csv(filePath)

#%% STEP 2: SUNRISE AND SUNSET
#create columns
for yyyy_mm in dateSun.index:
    df_md['rise_'+ yyyy_mm] = np.nan
    df_md['set_'+ yyyy_mm] = np.nan
idx1 = 1
starting = tm.time()   
for i in df_md.index:
    print ('\n')
    print('City Iteration %d of %d started' % (idx1,len(df_md.index)))
    #defining position
    lat = df_md.loc[i,'Latitude']
    long = df_md.loc[i,'Longitude'] # western hemisphere only (eg: North America, UTC offset of -3 to -10)
    #defining local time
    utc_offset = df_md.loc[i,'utcOffset']
    
    for yyyy_mm in dateSun.index:
        #defining date
        date = dateSun.loc[yyyy_mm, 'Date']
        # sunrise
        (r1, r1_lt) = sunrise(lat, long, date, utc_offset)
        df_md.loc[i,'rise_'+ yyyy_mm] = r1_lt
#        print ("rising sun (UTC time): ", r1)
#        print ("rising sun (local time): ", r1_lt)
        
        # sunset
        (s1, s1_lt) = sunset(lat, long, date, utc_offset)
        df_md.loc[i,'set_'+ yyyy_mm] = s1_lt
#        print ("setting sun (UTC time): ", s1)
#        print ("setting sun (local time): ", s1_lt)
    idx1 += 1
    print(tm.time() - starting)
#%% STEP 3: SAVE FILE
df_md.to_csv(os.path.join(cwd, metaData,'cities_LatLongTzSuntime.csv'), index = False)

#%% MAIN BODY OF CODE - End  
#%% NOTES - Start  

#%% NOTES - End