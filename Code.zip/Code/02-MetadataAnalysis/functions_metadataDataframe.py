# -*- coding: utf-8 -*-
"""
Created on Thu Feb 28 22:36:00 2019

@author: Camille John
"""

#%% CUSTOM FUNCTIONS FOR CREATION OF METADATA DATAFRAME
#%% DOCUMENT SETUP
# Scientific libraries
import numpy as np
# Data analysis libraries
import pandas as pd
# Operating system library
import os
cwd = os.getcwd()

#%% UNZIP DATA FILES
def UnzipArchive(archive):
    import zipfile
    destination = os.path.join(cwd,archive)
    archive = os.path.join(cwd,archive+'.zip')
    # Unzip archive folder
    zf = zipfile.ZipFile(archive)
    # Return a list of archive members by name
    check = zf.namelist()
    # Extract all archive members and save to a new location
    zf.extractall(destination)
    # close archive folder
    zf.close()
    return (check)

#%% LOAD ORIGINAL METADATA FILE
def LoadMetaDataFile(yyyy_mm, identifier):
    import os
    cwd = os.getcwd()
    fileName = identifier + '.csv'
    filePath = os.path.join(cwd,'..','01-Data',yyyy_mm,fileName)
    # Creates dataframe
    df_md = pd.read_csv(filePath)
#    df_md.set_index('Unnamed: 0', inplace = True)
    return df_md

#%% SUM UP NUMBER OF MISSING INPUTS    
def NumMissingInput(x):
  return sum(x.isnull())

#%% PROCESS METADATA DATAFRAME
def DataframeProcessing(df_md):
    # Column  3: 'Country'
    #      codes based on ISO 3166-2
    df_md['Country'] = df_md['Country'].str.upper()
    df_md['Country'] = df_md['Country'].replace(['UNITED STATES', 'PR'], 'US')
    df_md['Country'] = df_md['Country'].replace(['AUSTRALIA'], 'AU')
    df_md['Country'] = df_md['Country'].replace(['PANAMA'], 'PA')
    
    # Column  4: 'ProvinceState'
    #     codes based on ISO 3166-2
    df_md['ProvinceState'] = df_md['ProvinceState'].replace(['ABU DHABI'], 'AZ')
    df_md['ProvinceState'] = df_md['ProvinceState'].replace(['BUENOS AIRES'], 'B')
    df_md['ProvinceState'] = df_md['ProvinceState'].replace(['DUBAI', 
         'OUD METHA', 'DXB'],'DU')
    df_md['ProvinceState'] = df_md['ProvinceState'].replace(['ENTRE R X9D X9D'], 
         'E')
    df_md['ProvinceState'] = df_md['ProvinceState'].replace(['LITTLE EXUMA'], 
         'EX')
    df_md['ProvinceState'] = df_md['ProvinceState'].replace(['LIAONING', 
         'LIAO NING'], 'LN')
    df_md['ProvinceState'] = df_md['ProvinceState'].replace(['NEW SOUTH WALES'], 
         'NSW')
    df_md['ProvinceState'] = df_md['ProvinceState'].replace(['HUMACAO', 
         'MAYAGUEZ'], 'PR')    
    df_md['ProvinceState'] = df_md['ProvinceState'].replace(['SANTA FE'], 'S')
    df_md['ProvinceState'] = df_md['ProvinceState'].replace(['SHARJAH', 
         'sharjahDXB'], 'SH')
    df_md['ProvinceState'] = df_md['ProvinceState'].replace(['SOUTH AUSTRALIA'], 
         'SA')
    df_md['ProvinceState'] = df_md['ProvinceState'].replace(['VICTORIA'], 'VIC')
    df_md['ProvinceState'] = df_md['ProvinceState'].replace(['GENT'], 'VOV')

    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['Country'] == 'BH') & (df_md['ProvinceState'] == 'SOUTHERN')
            ].index.values, 4] = '14'
    
# Column  5: 'City'
    df_md['City'] = df_md['City'].replace(['-'], np.nan)
    df_md['City'] = df_md['City'].str.title()
    
    df_md['City'] = df_md['City'].replace(['#Name?', '&#X9D;&#X9D;&#X9D;&#', '1184', '1730', '???', '???', '?X9Dx9Dxb0?????'], np.nan)
    df_md['City'] = df_md['City'].replace(['Aldergrovd'], 'Aldergrove')
    df_md['City'] = df_md['City'].replace(['Atlanta '], 'Atlanta')
    df_md['City'] = df_md['City'].replace(['Austin '], 'Austin')
    
    df_md['City'] = df_md['City'].replace(["Baie-D'Urf&#X9D;&#X9"], "Baie-D'Urfe")                
    df_md['City'] = df_md['City'].replace([' Ballwin'], 'Ballwin')
    df_md['City'] = df_md['City'].replace(['Barri3', 'Barre'], 'Barrie')
    df_md['City'] = df_md['City'].replace(['Beaconsfield '], 'Beaconsfield')      
    df_md['City'] = df_md['City'].replace([' Beverly'], 'Beverly')
    df_md['City'] = df_md['City'].replace(['Boca Raton '], 'Boca Raton')
    df_md['City'] = df_md['City'].replace(['Winners Cir'], 'Brampton')
    df_md['City'] = df_md['City'].replace(['Brossad'], 'Brossard')
    df_md['City'] = df_md['City'].replace(['Burlinghton'], 'Burlington')
    
    df_md['City'] = df_md['City'].replace(['Calgary '], 'Calgary')    
    df_md['City'] = df_md['City'].replace(['Cambridge Ontario', 'Cambridge '], 'Cambridge')
    df_md['City'] = df_md['City'].replace(['Cavan-Monaghan'], 'Cavan Monaghan')
    df_md['City'] = df_md['City'].replace(['Charlottwtown'], 'Charlottetown')
    df_md['City'] = df_md['City'].replace(['Chicago '], 'Chicago')    
    df_md['City'] = df_md['City'].replace(['Coburg'], 'Cobourg')
    df_md['City'] = df_md['City'].replace(['Columbus '], 'Columbus')
    df_md['City'] = df_md['City'].replace(['Cote-St-Luc', 'Cote Saint Luc'], 'Cote Saint-Luc')
    
    df_md['City'] = df_md['City'].replace(['Da Lian'], 'Dalian')
    df_md['City'] = df_md['City'].replace(['Denver ', 'Denvee'], 'Denver')
    df_md['City'] = df_md['City'].replace(['Dollard-Des Ormeaux', 'Ddo', 'Dollard Des Ormeaux'], 'Dollard-Des-Ormeaux')
    df_md['City'] = df_md['City'].replace(['Dysart And Others'], 'Dysart et al')
    
    df_md['City'] = df_md['City'].replace([' Eagle River'], 'Eagle River')
    df_md['City'] = df_md['City'].replace(['Eastyork'], 'East York')
    df_md['City'] = df_md['City'].replace(['East St. Paul'], 'East St Paul')
    df_md['City'] = df_md['City'].replace(['Edmonton '], 'Edmonton')
    df_md['City'] = df_md['City'].replace(['El Paso '], 'El Paso')
    
    df_md['City'] = df_md['City'].replace(['Rural Foothills M.D.', 'Heritage Pointe Ab'], 'Foothills No. 31')
    df_md['City'] = df_md['City'].replace(['Ft Lauderdale'], 'Fort Lauderdale')
    df_md['City'] = df_md['City'].replace(['Fort Saskathewan'], 'Fort Saskatchewan')
    df_md['City'] = df_md['City'].replace(['Fortworth'], 'Fort Worth')    
    df_md['City'] = df_md['City'].replace(['Fuquay Varina'], 'Fuquay-Varina')
    
    df_md['City'] = df_md['City'].replace(['Grand Rapids ','Grand Rapid'], 'Grand Rapids')
    df_md['City'] = df_md['City'].replace(['Guelph Eramosa',  ], 'Guelph')
    df_md['City'] = df_md['City'].replace(['Hamilton '], 'Hamilton')

    df_md['City'] = df_md['City'].replace(["L'Le-Perrot"], 'Ile Perrot')
    df_md['City'] = df_md['City'].replace(['Innisfil '], 'Innisfil')
    df_md['City'] = df_md['City'].replace(['Jonqui&#X9D;&#X9D;&#'], 'Jonquiere')
         
    df_md['City'] = df_md['City'].replace(['2910 Pheobe Trace'], 'Katy')
    df_md['City'] = df_md['City'].replace(['Kennesaw '], 'Kennesaw')
    df_md['City'] = df_md['City'].replace(['Kissmmee'], 'Kissimmee')
    df_md['City'] = df_md['City'].replace(['Kitchener '], 'Kitchener')
    
    df_md['City'] = df_md['City'].replace(['Lanark'], 'Lanark County')
    df_md['City'] = df_md['City'].replace(['Leduc '], 'Leduc')
    df_md['City'] = df_md['City'].replace(["L'Ile-Bizard"], "L'Ile-Bizard–Sainte-Genevieve")    
    df_md['City'] = df_md['City'].replace(['Little Rock ', 'Little Rock Arkansas'], 'Little Rock')
    df_md['City'] = df_md['City'].replace(['Lloydminster (Part)'], 'Lloydminster') 
    df_md['City'] = df_md['City'].replace(['Los Angeles '], 'Los Angeles')
    
    df_md['City'] = df_md['City'].replace(['Mar Del Plats'], 'Mar Del Plata')
    df_md['City'] = df_md['City'].replace(['Marieta'], 'Marietta')
    df_md['City'] = df_md['City'].replace(['L3T5H3'], 'Markham')
    df_md['City'] = df_md['City'].replace(['Mckinny'], 'McKinney')
    df_md['City'] = df_md['City'].replace(['South Miami', 'West Miami'], 'Miami')
    df_md['City'] = df_md['City'].replace(['Minneapolis '], 'Minneapolis')
    df_md['City'] = df_md['City'].replace(['Mississuaga', 'Mississauga '], 'Mississauga')
    df_md['City'] = df_md['City'].replace(['Montrxe9Al', 'Montrx9Dx9Dx9Dx9Dx9D', 'Montr&#X9D;&#X9D;Al', 'Montr&#X9D;&#X9D;&#X'], 'Montreal')
    df_md['City'] = df_md['City'].replace(['Mt Pleasant'], 'Mount Pleasant')
    df_md['City'] = df_md['City'].replace(['Mount-Royal', 'Mont-Royal', 'Mont Royal'], 'Mount Royal')
    df_md['City'] = df_md['City'].replace(['Morin Heights'], 'Morin-Heights')
    
    df_md['City'] = df_md['City'].replace(['Naper Ille', 'Napervillr'], 'Naperville')
    df_md['City'] = df_md['City'].replace(['Nashville '], 'Nashville')
    df_md['City'] = df_md['City'].replace(['Niagara Falls '], 'Niagara Falls')
    df_md['City'] = df_md['City'].replace(['Niagara On The Lake'], 'Niagara On The Lake')    
    df_md['City'] = df_md['City'].replace(['North York '], 'North York')
    
    df_md['City'] = df_md['City'].replace(['Oak Bluff Mb'], 'Oak Bluff')
    df_md['City'] = df_md['City'].replace(['Orlando '], 'Orlando')
    df_md['City'] = df_md['City'].replace(['Ottawa Orleans'], 'Ottawa')

    df_md['City'] = df_md['City'].replace(['Paris (Brant)'], 'Paris')
    df_md['City'] = df_md['City'].replace(['Petite-Riviere-St-Fr'], 'Petite-Riviere-Saint-Francois')
    df_md['City'] = df_md['City'].replace(['Philadelphia '], 'Philadelphia') 
    df_md['City'] = df_md['City'].replace(['Phoenix '], 'Phoenix')    
    df_md['City'] = df_md['City'].replace(['Piction'], 'Picton')
    df_md['City'] = df_md['City'].replace(['Pittsburgh '], 'Pittsburgh')
    df_md['City'] = df_md['City'].replace(['Pointe Claire'], 'Pointe-Claire')
    df_md['City'] = df_md['City'].replace(['Pompino Beach'], 'Pompano Beach')
    df_md['City'] = df_md['City'].replace(['Portland '], 'Portland')
    df_md['City'] = df_md['City'].replace(['Prince Edward'], 'Prince Edward County')
    df_md['City'] = df_md['City'].replace([' Princeville'], 'Princeville')
    
    df_md['City'] = df_md['City'].replace(['Ville De Quebec', 'Quebec City'], 'Quebec')
    
    df_md['City'] = df_md['City'].replace(['Richmon Hill'], 'Richmond Hill')
    df_md['City'] = df_md['City'].replace(['Riverside '], 'Riverside')
    df_md['City'] = df_md['City'].replace(['Rocky View County'], 'Rocky View No. 44')    

    df_md['City'] = df_md['City'].replace(["St. Albert"], "St Albert")
    df_md['City'] = df_md['City'].replace(['Saint-Bruno'], 'St-Bruno')
    df_md['City'] = df_md['City'].replace(['St. Catharines', 'Saint Catharines'], 'St Catharines')
    df_md['City'] = df_md['City'].replace(['St. Clair'], 'St Clair')
    df_md['City'] = df_md['City'].replace(['Saint Clements'], 'St Clements')
    df_md['City'] = df_md['City'].replace(['Saint-Denis-De-Brompton'], 'St-Denis-De-Brompton')
    df_md['City'] = df_md['City'].replace(['Saint-Donat-De-Montcalm', 'St Donat De Montcalm'], 'St-Donat-De-Montcalm')
    df_md['City'] = df_md['City'].replace(['St-Eugxe8Ne', 'Saint-Eugene'], 'St-Eugene')    
    df_md['City'] = df_md['City'].replace(['Saint-Hubert', 'Saint Hubert'], 'St-Hubert')
    df_md['City'] = df_md['City'].replace(['Saint-Jacques-Le-Mineur'], 'St-Jacques-Le-Mineur')
    df_md['City'] = df_md['City'].replace(['Saint-Jean'], 'St-Jean')
    df_md['City'] = df_md['City'].replace(['Stjean Sur Richelieu', 'Saint-Jean-Sur-Richelieu'], 'St-Jean-Sur-Richelieu')
    df_md['City'] = df_md['City'].replace(['Saint-J&#X9D;&#X9D;&', 'Saint-Jerome'], 'St-Jerome')
    df_md['City'] = df_md['City'].replace(["St. John'S"], "St John'S")
    df_md['City'] = df_md['City'].replace(['Saint-Lambert'], 'St-Lambert')
    df_md['City'] = df_md['City'].replace(['Saint-Laurent', 'Saint Laurent'], 'St-Laurent')
    df_md['City'] = df_md['City'].replace(['Saint Lazare', 'Saint-Lazare'], 'St-Lazare')
    df_md['City'] = df_md['City'].replace(['St. Louis'], 'St Louis')
    df_md['City'] = df_md['City'].replace(['Saint-Louis-De-Gonzague', 'St Louis De Gonzague'], 'St-Louis-De-Gonzague')
    df_md['City'] = df_md['City'].replace(['Saint-Luc'], 'St-Luc')
    df_md['City'] = df_md['City'].replace(['Saint Paul'], 'St Paul')
    df_md['City'] = df_md['City'].replace(['Saint-R&#X9D;&#X9D;&', 'Saint-Rx9Dx9Dx9Dx9Dx'], 'St-Remi')    
    df_md['City'] = df_md['City'].replace(['Saint Thomas'], 'St Thomas')
    df_md['City'] = df_md['City'].replace(['Ste. Rose Du Lac'], 'Ste Rose Du Lac')
    df_md['City'] = df_md['City'].replace(['Sainte-Adele', 'Sainte-Ad&#X9D;&#X9D'], 'Ste-Adele')
    df_md['City'] = df_md['City'].replace(['St-Anne-Des-Plaines', 'St Anne Des Plaines', 'Sainte-Anne-Des-Plaines'], 'Ste-Anne-Des-Plaines')
    df_md['City'] = df_md['City'].replace(['Ste-Anne Des Lacs', 'Sainte-Anne-Des-Lacs'], 'Ste-Anne-Des-Lacs')    
    df_md['City'] = df_md['City'].replace(['Sainte Catherine', 'Sainte-Catherine'], 'Ste-Catherine')
    df_md['City'] = df_md['City'].replace(['Sainte-Julie'], 'Ste-Julie')
    df_md['City'] = df_md['City'].replace(['Sainte-Therese', 'Ste-Th&#X9D;&#X9D;&#', 'Sainte Therese'], 'Ste-Therese') 
    df_md['City'] = df_md['City'].replace(['Saly Lake City'], 'Salt Lake City')
    df_md['City'] = df_md['City'].replace(['San Antonio '], 'San Antonio')
    df_md['City'] = df_md['City'].replace(['San Diego '], 'San Diego')
    df_md['City'] = df_md['City'].replace(['Sarnia No 221'], 'Sarnia No. 221')
    df_md['City'] = df_md['City'].replace(['Sault Ste. Marie'], 'Sault Ste Marie')
    df_md['City'] = df_md['City'].replace(['Scottsdalee'], 'Scottsdale')    
    df_md['City'] = df_md['City'].replace(['Sherwood  Park', 'Sherwood Park '], 'Sherwood Park')
    df_md['City'] = df_md['City'].replace(['Sincoe', 'Simcoe Ontario', '50 Colbourne St'], 'Simcoe')
    df_md['City'] = df_md['City'].replace(['Springwater Township'], 'Springwater')
    df_md['City'] = df_md['City'].replace(['Strathroy'], 'Strathroy-Caradoc')
    df_md['City'] = df_md['City'].replace(['Sudbury '], 'Sudbury')
    df_md['City'] = df_md['City'].replace(['Sunnyvale '], 'Sunnyvale')
   
    df_md['City'] = df_md['City'].replace(['Tampa '], 'Tampa')
    df_md['City'] = df_md['City'].replace(['The Springs 15'], 'The Springs')
    df_md['City'] = df_md['City'].replace(['Totonto', 'Toronto '], 'Toronto')
    df_md['City'] = df_md['City'].replace(['Trois-Rivi&#X9D;&#X9'], 'Trois-Rivieres')
         
    df_md['City'] = df_md['City'].replace(['Vaudreuil'], 'Vaudreuil-Dorion')
    
    df_md['City'] = df_md['City'].replace(['Washington ','Washington Dc'], 'Washington')
    df_md['City'] = df_md['City'].replace(['Whitby '], 'Whitby')
    df_md['City'] = df_md['City'].replace(['Windser'], 'Windsor')
    df_md['City'] = df_md['City'].replace(['Winnipeg '], 'Winnipeg')
    
    df_md['City'] = df_md['City'].replace(['Youngs Point'], "Young's Point")
      
    
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'GA') & (df_md['City'] == 'Cumming')
            ].index.values, 3] = 'US'
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'MI') & (df_md['City'] == 'Ferndale')
            ].index.values, 3] = 'US'
    
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['Country'] == 'AE') & (df_md['City'] == 'Dubai')        
            ].index.values, 4] = 'DU' 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['Country'] == 'CA') & (df_md['City'] == 'Toronto')        
            ].index.values, 4] = 'ON' 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['Country'] == 'CL') & (df_md['City'] == 'Santiago')        
            ].index.values, 4] = 'RM'
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['Country'] == 'CL') & (df_md['City'] == 'Cachagua')        
            ].index.values, 4] = 'VS' 
    
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['Country'] == 'US') & (df_md['City'] == '2200 E Cedar Pl')
            ].index.values, 5] = 'Chandler'
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'HI') & (df_md['City'] == 'Ocean Pointe')
            ].index.values, 5] = 'Honolulu'    
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Lac La Nonne')
            ].index.values, 5] = 'Barrhead No. 11'
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Lac Des Arcs')
            ].index.values, 5] = 'Bighorn No. 8'
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Goodrich')
            ].index.values, 5] = 'Goodridge'
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['Country'] == 'AR') & (df_md['City'] == 'Paran&#X9D;&#X9D;&#X')        
            ].index.values, 5] = 'Parana'
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Grand Prairie')
            ].index.values, 5] = 'Grande Prairie'
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['Country'] == 'US') & (df_md['City'] == '12833')
            ].index.values, 5] = 'Greenfield Center'        
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Ewing')
            ].index.values, 5] = 'Stettler County No. 6' 

    
# Suspicious Locations
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['Country'] == 'US') & (df_md['ProvinceState'] == 'AB')        
            ].index.values, 4] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['Country'] == 'US') & (df_md['ProvinceState'] == 'NB')        
            ].index.values, 4] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['Country'] == 'US') & (df_md['ProvinceState'] == 'QC')        
            ].index.values, 4] = np.nan
    
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Abingdon')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Albuquerque')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Allen')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Alvin')
            ].index.values, 3:6] = np.nan    
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Ankeny')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Annapolis')
            ].index.values, 3:6] = np.nan    
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Artesia')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Arundel')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Atlanta')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Aurora')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Austin')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Avon')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Avon Park')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Ayer')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Barre')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Bayard')
            ].index.values, 3:6] = np.nan    
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Bethesda')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Boardman')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Brighton')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Buckeye')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Cahokia')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Cambridge')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Canfield')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Carpentersville')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Casselberry')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Cedar Park')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Chandler')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Chattanooga')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Chester Springs')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Cobourg')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Columbia')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Columbia Station')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Converse')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Coppell')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Cumming')
            ].index.values, 3:6] = np.nan 
    
     
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Dallas')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Darien')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Deephaven')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Dekalb')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Denver')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Downers Grove')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Dundas')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'East Lansing')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'El Dorado Hills')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Ellicott City')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Erie')
            ].index.values, 3:6] = np.nan   
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Etobicoke')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Eustis')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Fairfield')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Faribault')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Ferndale')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Fleetwood')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Fort Wayne')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Fresno')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Gilbert')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Goodlettsville')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Goose Creek')
            ].index.values, 3:6] = np.nan     
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Grand Rapids')
            ].index.values, 3:6] = np.nan     
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Granite Bay')
            ].index.values, 3:6] = np.nan        
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Gravenhurst')
            ].index.values, 3:6] = np.nan        
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Greensboro')
            ].index.values, 3:6] = np.nan        
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Gresham')
            ].index.values, 3:6] = np.nan        
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Hamilton')
            ].index.values, 3:6] = np.nan    
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Hartford')
            ].index.values, 3:6] = np.nan    
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Hemet')
            ].index.values, 3:6] = np.nan    
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Herriman')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Hewlett')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Hinesburg')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Houston')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Hugo')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Indian Shores')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Indianapolis')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Invermere')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Jacksonville')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Kitchener')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'La Feria')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'La Salle')
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Lake Stevens')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Lakefield')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Lansing')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Las Cruces')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Las Vegas')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Livonia')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Logan')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Loganville')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'London')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Longboat Key')
            ].index.values, 3:6] = np.nan 
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Longwood')
            ].index.values, 3:6] = np.nan             
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Loxahatchee')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Macon')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Manchester')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Mankato')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Mansfield')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Maple Grove')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Marquette')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Mesa')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Middleton')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Middletown')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Mijdrecht')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Milford')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Minneapolis')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Mississauga')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Monroe')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Monroe Township')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Montr&#X9D;&#X9D;&#X')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Moreno Valley')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Mount Olive Township')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == "O'Fallon")        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Oak Park')        
            ].index.values, 3:6] = np.nan    
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Orange')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Orem')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Overland Park')        
            ].index.values, 3:6] = np.nan    
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Owens Cross Roads')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Pace')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Painesville')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Palm Harbor')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Parma')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Penetanguishene')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Pensacola')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Petoskey')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Phoenix')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Pickering')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Plano')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Ponoka')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Portland')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Prior Lake')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Puyallup')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Red Lodge')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Rexburg')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Rocky Mountain House')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'San Antonio')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'San Diego')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Saskatoon')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Schomberg')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Seabrook')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Seattle')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Sheffield Lake')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Shelby')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Snellville')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'South Bend')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'South Bound Brook')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['City'] == 'South Pole')        
            ].index.values, 3:6] = np.nan    
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Spokane')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Spring')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Springfield')        
            ].index.values, 3:6] = np.nan   
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Stafford')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Stone Mountain')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Streetsboro')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Strongsville')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Summerville')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Sunset Point')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Suwanee')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Taber')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Tacoma')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Tampa')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Teaneck')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'The Blue Mountains')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Tigard')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Townville')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Trussville')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Vaughan')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Vernon')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Warren')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == ' West River')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Westminster')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Whitewater')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Windsor')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Yuma')        
            ].index.values, 3:6] = np.nan
    df_md.iloc[df_md[['Country', 'ProvinceState', 'City']].loc[
            (df_md['ProvinceState'] == 'AB') & (df_md['City'] == 'Zion')        
            ].index.values, 3:6] = np.nan
    
    # Column  6: 'Floor Area [ft2]'
    df_md.iloc[df_md[['Floor Area [ft2]']].loc[
            (df_md['Floor Area [ft2]'] < 100)
            ].index.values, 6] = np.nan
    df_md['Floor Area [m2]'] = df_md['Floor Area [ft2]'] * np.square(0.3048)
    
    # Column  7: 'Style'
    df_md['Style'] = df_md['Style'].str.title()
    df_md['Style'] = df_md['Style'].replace(['0', 'Other', "I Don'T Know"], np.nan)
    df_md['Style'] = df_md['Style'].replace(['Condo'], 'Condominium')
    df_md['Style'] = df_md['Style'].replace(['Multi Plex'], 'Multiplex')
    df_md['Style'] = df_md['Style'].replace(['Row House'], 'Rowhouse')
    df_md['Style'] = df_md['Style'].replace(['Semidetached'], 'Semi-Detached')
    df_md['Style'] = df_md['Style'].replace(['Town House'], 'Townhouse')
    
    df_md.iloc[df_md[['Floor Area [ft2]','Style']].loc[
            (df_md['Style'] == 'Apartment') & (df_md['Floor Area [ft2]'] > 2000)
            ].index.values, 6] = np.nan
    df_md.iloc[df_md[['Floor Area [ft2]','Style']].loc[
            (df_md['Style'] == 'Condominium') & (df_md['Floor Area [ft2]'] > 2000)
            ].index.values, 6] = np.nan
    df_md.iloc[df_md[['Floor Area [ft2]','Style']].loc[
            (df_md['Style'] == 'Loft') & (df_md['Floor Area [ft2]'] > 2000)
            ].index.values, 6] = np.nan
    df_md.iloc[df_md[['Floor Area [ft2]','Style']].loc[
            (df_md['Style'] == 'Multiplex') & (df_md['Floor Area [ft2]'] > 2000)
            ].index.values, 6] = np.nan
    df_md.iloc[df_md[['Floor Area [ft2]','Style']].loc[
            (df_md['Style'] == 'Rowhouse') & (df_md['Floor Area [ft2]'] > 3000)
            ].index.values, 6] = np.nan
    df_md.iloc[df_md[['Floor Area [ft2]','Style']].loc[
            (df_md['Style'] == 'Semi-Detached') & (df_md['Floor Area [ft2]'] > 3000)
            ].index.values, 6] = np.nan
    df_md.iloc[df_md[['Floor Area [ft2]','Style']].loc[
            (df_md['Style'] == 'Townhouse') & (df_md['Floor Area [ft2]'] > 3000)
            ].index.values, 6] = np.nan
    
    # Column  8: 'Number of Floors'
    df_md.iloc[df_md[['Number of Floors']].loc[(df_md['Number of Floors'] < 1)
        ].index.values, 8] = np.nan
    df_md.iloc[df_md[['Number of Floors']].loc[(df_md['Number of Floors'] >= 5)
        ].index.values, 8] = np.nan
    
     
    df_md.iloc[df_md[['Number of Floors','Style']].loc[
            (df_md['Style'] == 'Apartment') & (df_md['Number of Floors'] > 2)
            ].index.values, 8] = np.nan
    df_md.iloc[df_md[['Number of Floors','Style']].loc[
            (df_md['Style'] == 'Condominium') & (df_md['Number of Floors'] > 2)
            ].index.values, 8] = np.nan
    df_md.iloc[df_md[['Number of Floors','Style']].loc[
            (df_md['Style'] == 'Loft') & (df_md['Number of Floors'] > 2)
            ].index.values, 8] = np.nan
    df_md.iloc[df_md[['Number of Floors','Style']].loc[
            (df_md['Style'] == 'Multiplex') & (df_md['Number of Floors'] > 2)
            ].index.values, 8] = np.nan

    
    # Column 10: 'Number of Occupants'
    df_md['Number of Occupants'] = df_md['Number of Occupants'].replace([0], np.nan)
    df_md.iloc[df_md[['Number of Occupants']].loc[(df_md['Number of Occupants'] >= 8)
            ].index.values, 10] = np.nan
    
    df_md.iloc[df_md[['Number of Occupants','Style']].loc[
            (df_md['Style'] == 'Apartment') & (df_md['Number of Occupants'] >= 5)
            ].index.values, 10] = np.nan
    df_md.iloc[df_md[['Number of Occupants','Style']].loc[
            (df_md['Style'] == 'Condominium') & (df_md['Number of Occupants'] >= 5)
            ].index.values, 10] = np.nan
    df_md.iloc[df_md[['Number of Occupants','Style']].loc[
            (df_md['Style'] == 'Detached') & (df_md['Number of Occupants'] >= 8)
            ].index.values, 10] = np.nan
    df_md.iloc[df_md[['Number of Occupants','Style']].loc[
            (df_md['Style'] == 'Loft') & (df_md['Number of Occupants'] >= 5)
            ].index.values, 10] = np.nan
    df_md.iloc[df_md[['Number of Occupants','Style']].loc[
            (df_md['Style'] == 'Multiplex') & (df_md['Number of Occupants'] >= 8)
            ].index.values, 10] = np.nan
    df_md.iloc[df_md[['Number of Occupants','Style']].loc[
            (df_md['Style'] == 'Rowhouse') & (df_md['Number of Occupants'] >= 8)
            ].index.values, 10] = np.nan
    df_md.iloc[df_md[['Number of Occupants','Style']].loc[
            (df_md['Style'] == 'Semi-Detached') & (df_md['Number of Occupants'] >= 8)
            ].index.values, 10] = np.nan
    df_md.iloc[df_md[['Number of Occupants','Style']].loc[
            (df_md['Style'] == 'Townhouse') & (df_md['Number of Occupants'] >= 8)
            ].index.values, 10] = np.nan
    
    #ALL COLUMNS
    # Remove duplicated entries in metadata
    df_md.drop(columns=['UserID'], inplace=True)
    df_md.drop_duplicates(inplace = True)
    print('Number of registered residences minus duplicated residences(original files kept): %d' %(len(df_md.index)))
    print ('\n')
    # ALL duplicate filenames with discrepencies in metadata (from Common ids and the rest)
    duplicates = df_md[['filename']].loc[(df_md.duplicated(['filename'], keep=False))]
    print('Number of questionable residents (i.e. sharing data files): %d' %(len(duplicates.index)))
    print ('\n')
    duplicates.drop_duplicates(inplace = True)
    # Common Identifiers(Ids) found throughout every month folder for these periods
    commonIds1 =  pd.read_csv(os.path.join(cwd,'..','01-Data','CommonIds_201709-201808.csv'))
    # Only keep Common ids with no duplicates
    commonIds1 =pd.concat([commonIds1,duplicates,duplicates], ignore_index=True).drop_duplicates(keep=False)
    commonIds1.to_csv(os.path.join(cwd,'mdAll', 'CommonIdsCln_201709-201808.csv'), index = False)
    print('Number of registered residences common to every month from 2017-09 to 2018-08: %d' %(len(commonIds1.index)))
    print ('\n')
    commonIds2 = pd.read_csv(os.path.join(cwd,'..','01-Data','CommonIds_201609-201808.csv')) 
    commonIds2 = pd.merge(commonIds2, commonIds1, on = ['filename'])
    commonIds2.to_csv(os.path.join(cwd,'mdAll', 'CommonIdsCln_201609-201808.csv'), index = False)
    print('Number of registered residences common to every month from 2016-09 to 2018-08: %d' %(len(commonIds2.index)))
    print ('\n')
    commonIds3 = pd.read_csv(os.path.join(cwd,'..','01-Data','CommonIds_201509-201808.csv'))
    commonIds3 = pd.merge(commonIds3, commonIds1, on = ['filename'])
    commonIds3.to_csv(os.path.join(cwd,'mdAll', 'CommonIdsCln_201509-201808.csv'), index = False)
    print('Number of registered residences common to every month from 2015-09 to 2018-08: %d' %(len(commonIds3.index)))
    print ('\n')
    # df_md based on common ids of 2017-2018
    df_md = pd.merge(df_md, commonIds1, on='filename')

    return df_md