Note001.For creating the monthly dataframes
with each dwelling's monthly average of their 
estimated time constant values and contextual 
information:
- requires csv files (with the individual 
analysis period estimations) saved to monthly 
folders in folder 03-TimeCstEstimationNb
(eg: timeCstProjN_yyyy-mm_a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1.csv)
- use analysisDataframeNb.py and 
functions_analysisDataframeNb.py
- csv files created are saved as:
colAnaProjN_yyyy-mm
- files created saved to folder 
05-DataAnalysisPt2/60min_2oC_Nb_Tfdiff5


