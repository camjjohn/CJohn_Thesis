# -*- coding: utf-8 -*-
"""
Created on Fri Mar  8 10:04:25 2019

@author: Camille John
"""

#%% CREATION OF ANALYSIS DATAFRAME
#%% DOCUMENT SETUP
# Scientific libraries
import numpy as np
# Data analysis libraries
import pandas as pd
#Visualization Librairies
import matplotlib.pyplot as plt
#import seaborn as sns;
#sns.set()
# Operating system library
import os
cwd = os.getcwd()  # cwd: current working directory
# Time access and conversion library
import time as tm
# Custom Functions
from functions_analysisDataframeNb import LoadCleanDataFile, CreateColSel, CreateColAna

#%% MAIN BODY OF CODE - Start
#%% STEP 1: INPUTS 

# Create dataframe of meta data referenced
metaData = 'mdProj'
filePath = os.path.join(cwd,'..','02-MetaDataAnalysis', metaData, metaData + '.csv')
df_md = pd.DataFrame()
df_md = pd.read_csv(filePath)

# Create list of identifiers to analyze
#identifier_list = df_md['Identifier'].tolist()
#identifier_list = ['8b0c8e73226d4e76a94940ea7a0d09eb64fe1997', 
#                   '21bf3d7c2495cdc2e7e1776c3c2bf6a6eb27f9d7', 
#                   '60d1b128ecdd67ab89be533d25c8e2536e41565f'] # Partial and single
#                                                               # selection initiated
identifier_list = df_md['Identifier']
commonIds = pd.read_csv(os.path.join(cwd,'..','02-MetaDataAnalysis','mdProj', 
                                     'CommonIdsProj_201709-201808.csv'))
identifier_list = pd.merge(identifier_list.to_frame(), commonIds, on = ['Identifier'])
identifier_list = identifier_list['Identifier'].tolist()


# Create list of months to analyze   
yyyy_mm_list =  ['2015-09', '2015-10', '2015-11', '2015-12', '2016-01', '2016-02', #0-5
                 '2016-03', '2016-04', '2016-05', '2016-06', '2016-07', '2016-08', #6-11
                 '2016-09', '2016-10', '2016-11', '2016-12', '2017-01', '2017-02', #12-17
                 '2017-03', '2017-04', '2017-05', '2017-06', '2017-07', '2017-08', #18-23
                 '2017-09', '2017-10', '2017-11', '2017-12', '2018-01', '2018-02', #24-29
                 '2018-03', '2018-04', '2018-05', '2018-06', '2018-07', '2018-08'] #30-35
#yyyy_mm_list = yyyy_mm_list[24:36] # Partial selection initiated (2017-09 to 2018-08)
#yyyy_mm_list = yyyy_mm_list[12:36] # Partial selection initiated (2016-09 to 2018-08)
yyyy_mm_list = [yyyy_mm_list[35]] # Single selection initiated

seasonAssign = pd.DataFrame({
            'Year_Month': ['2015-09', '2015-10', '2015-11', '2015-12', '2016-01', '2016-02', #0-5
                           '2016-03', '2016-04', '2016-05', '2016-06', '2016-07', '2016-08', #6-11
                           '2016-09', '2016-10', '2016-11', '2016-12', '2017-01', '2017-02', #12-17
                           '2017-03', '2017-04', '2017-05', '2017-06', '2017-07', '2017-08', #18-23
                           '2017-09', '2017-10', '2017-11', '2017-12', '2018-01', '2018-02', #24-29
                           '2018-03', '2018-04', '2018-05', '2018-06', '2018-07', '2018-08'], #30-35
#            'Season': ['Cooling', 'Shoulder', 'Shoulder', 'Heating', 'Heating', 'Heating', 
#                       'Heating', 'Shoulder', 'Shoulder', 'Cooling', 'Cooling', 'Cooling',
#                       'Cooling', 'Shoulder', 'Shoulder', 'Heating', 'Heating', 'Heating', 
#                       'Heating', 'Shoulder', 'Shoulder', 'Cooling', 'Cooling', 'Cooling',
#                       'Cooling', 'Shoulder', 'Shoulder', 'Heating', 'Heating', 'Heating', 
#                       'Heating', 'Shoulder', 'Shoulder', 'Cooling', 'Cooling', 'Cooling'],
            'Season': ['Fall', 'Fall', 'Fall', 'Winter', 'Winter', 'Winter', 
                       'Spring', 'Spring', 'Spring', 'Summer', 'Summer', 'Summer',
                       'Fall', 'Fall', 'Fall', 'Winter', 'Winter', 'Winter', 
                       'Spring', 'Spring', 'Spring', 'Summer', 'Summer', 'Summer',                       
                       'Fall', 'Fall', 'Fall', 'Winter', 'Winter', 'Winter', 
                       'Spring', 'Spring', 'Spring', 'Summer', 'Summer', 'Summer'],                       
                       })
# Specify criterion2: Analysis period is  >= crit2 [hour]
# Specify criterion3: Outdoor temperature remains approximately constant during
    #   analysis period (i.e. the temperature change is <= crit3)
# criterion4: Specify daytime or nighttime periods of analysis
# Specify criterion5: R-squared value for tauBldg_hr_optim is  >= crit5)
    
crit2 = 1.
crit3 = 2.
crit4 = ['D_', 'N_']
crit5 = [0.35, 0.5, 1.0] #place standard error values in descending order
crit6 = 3. # min tau 3 hours
crit7 = 240. # max tau 10 days
critSel = '60min_2oC_Nb_Tfdiff5'
#%% STEP 2:  SELECT TIME CONSTANTS USED FOR ANALYSIS
colAllAna = pd.DataFrame() 

now = tm.time()
idx1 = 1
for yyyy_mm in yyyy_mm_list:
    colAllAna = pd.DataFrame() # Only use if appending for max one month and multiple iterations 
    print ('\n')
    print('Year_Month Iteration %d of %d started' % (idx1,len(yyyy_mm_list)))
    print ('\n')
    if os.path.exists(os.path.join(cwd, '..','03-TimeCstEstimationNb', yyyy_mm)):
        idx2 = 1
        for identifier in identifier_list:
            print('Identifier Iteration %d of %d started' % (idx2,len(identifier_list)))
            if os.path.exists(os.path.join(cwd,'..','03-TimeCstEstimationNb',yyyy_mm,'timeCst'+
                                           metaData[2:]+crit4[1]+yyyy_mm+'_'+identifier+'.csv')):
                colCln = pd.DataFrame()
                colCln = LoadCleanDataFile(yyyy_mm, identifier, metaData, crit4)
                if 'tauBldg_hr_optim' in colCln.columns:
                    colAna = CreateColAna(identifier, yyyy_mm, colCln, crit2, crit3, crit5, crit6, crit7)
                    colAllAna = colAllAna.append(colAna, ignore_index=True)
                else:
                    print(str(identifier) + ': Least Squares was not performed for this identifier.')
            else:
                print (str(identifier) + ': This identifier was not found in ' + yyyy_mm + '.')
            idx2 += 1
            print(tm.time() - now)
    else:
        print (yyyy_mm + ': This month was not found in estimated data.')
        print ('\n')
    
    colAllAna['Season'] = np.nan
    colAllAna['Climate Zone'] = np.nan
    colAllAna['Style'] = np.nan
    colAllAna['Age of Home [years]'] = np.nan
    colAllAna['Floor Area [m2]'] = np.nan
    colAllAna['Number of Floors'] = np.nan
    colAllAna['Building Footprint [m2]'] = np.nan
    colAllAna['Number of Occupants'] = np.nan
    colAllAna['Number of Remote Sensors'] = np.nan
    colAllAna['Season'] = seasonAssign.loc[
            seasonAssign['Year_Month'] == yyyy_mm, 'Season'].item()
    colAllAna.set_index(['Identifier'], inplace = True)  
    for ind in colAllAna.index:
        colAllAna.loc[ind, 'Climate Zone'] = df_md.loc[df_md['Identifier'] == ind, 
                      'Climate Zone'].values
        colAllAna.loc[ind, 'Age of Home [years]'] = df_md.loc[df_md['Identifier'] == ind, 
                      'Age of Home [years]'].values
        colAllAna.loc[ind, 'Style'] = df_md.loc[df_md['Identifier'] == ind, 
                      'Style'].values
        colAllAna.loc[ind, 'Floor Area [m2]'] = df_md.loc[df_md['Identifier'] == ind, 
                      'Floor Area [m2]'].values
        colAllAna.loc[ind, 'Number of Floors'] = df_md.loc[df_md['Identifier'] == ind, 
                      'Number of Floors'].values
        colAllAna.loc[ind, 'Number of Occupants'] = df_md.loc[df_md['Identifier'] == ind, 
                      'Number of Occupants'].values
        colAllAna.loc[ind, 'Number of Remote Sensors'] = df_md.loc[df_md['Identifier'] == ind, 
                      'Number of Remote Sensors'].values

    colAllAna['Building Footprint [m2]'] = colAllAna['Floor Area [m2]'] / colAllAna[
            'Number of Floors']
    colAllAna['Dwelling Classification']= np.nan
    colAllAna.loc[(colAllAna['Style'] == 'Detached'), 'Dwelling Classification'] = 'Single-Family Residential'
    colAllAna.loc[(colAllAna['Style'] != 'Detached') & (colAllAna['Style'].notnull()), 'Dwelling Classification'] = 'Multi-Family Residential'

    colAllAna.to_csv(os.path.join(cwd,critSel,'colAna'+ metaData[2:]+crit4[1]+yyyy_mm+
                                  '.csv'), index = True)
    idx1 += 1
    print(tm.time() - now)

#%% MAIN BODY OF CODE - End
#%% NOTES - Start     
  
#%% NOTES - End