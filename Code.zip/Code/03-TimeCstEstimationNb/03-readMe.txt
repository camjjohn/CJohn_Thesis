Note001.For estimating time constants for every individual
analysis period using data files:
- requires mdProj.csv from folder 02-MetadataAnalysis/mdProj
- requires CommonIdsProj_201709-201808.csv from folder
02-MetadataAnalysis
- requires cities_LatLongTzSuntime.csv from folder 
02-MetadataAnalysis
- use timeCstEstimation.py and 
functions_timeCstEstimation.py
-requires data files in folder 01-Data
- files created saved to monthly folders
- csv files created are named as follows:
timeCstProjN_yyyy-mm_0000ExampleDataFile000000000000000000000.csv



