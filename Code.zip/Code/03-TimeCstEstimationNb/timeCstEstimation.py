# -*- coding: utf-8 -*-
"""
Created on Sat Mar  2 15:16:35 2019

@author: Camille John
"""

#%% TIME CONSTANT ESTIMATION (NIGHT)
#%% DOCUMENT SETUP
# Scientific libraries
import numpy as np
# Data analysis libraries
import pandas as pd
from scipy.optimize import least_squares
from sklearn.metrics import r2_score
# Operating system library
import os
cwd = os.getcwd()
# Time access and conversion library
import time as tm
import datetime as dt
# Custom Functions
from functions_timeCstEstimation import LoadDataFile, SunRiseSet, CreateColPrep, ExponentialDecay, AggregateFunction, CreateColCalc, CreateColCln

#%% MAIN BODY OF CODE - Start
#%% STEP 1: INPUTS 
# Create dataframe of meta data referenced
metaData = 'mdProj'
filePath = os.path.join(cwd,'..','02-MetaDataAnalysis', metaData, metaData + '.csv')
df_md = pd.DataFrame()
df_md = pd.read_csv(filePath)

# Create list of identifiers to analyze
identifier_list = df_md['Identifier']
commonIds = pd.read_csv(os.path.join(cwd,'..','02-MetaDataAnalysis','mdProj', 'CommonIdsProj_201709-201808.csv'))
identifier_list = pd.merge(identifier_list.to_frame(), commonIds, on = ['Identifier'])
identifier_list = identifier_list['Identifier'].tolist()
identifier_list = ['2b627e529f92b52c937f64782d1acf6b01bb2e07']

# Create list of months to analyze   
yyyy_mm_list =  ['2015-09', '2015-10', '2015-11', '2015-12', '2016-01', '2016-02', #0-5
                 '2016-03', '2016-04', '2016-05', '2016-06', '2016-07', '2016-08', #6-11
                 '2016-09', '2016-10', '2016-11', '2016-12', '2017-01', '2017-02', #12-17
                 '2017-03', '2017-04', '2017-05', '2017-06', '2017-07', '2017-08', #18-23
                 '2017-09', '2017-10', '2017-11', '2017-12', '2018-01', '2018-02', #24-29
                 '2018-03', '2018-04', '2018-05', '2018-06', '2018-07', '2018-08'] #30-35
yyyy_mm_list = yyyy_mm_list[24:36] # Partial selection initiated (2017-09 to 2018-08)
#yyyy_mm_list = [yyyy_mm_list[29]] # Single selection initiated

# Create dataframe of suntimes referenced
suntime = pd.DataFrame()
suntime = pd.read_csv(os.path.join(cwd,'..', '02-MetaDataAnalysis','mdProj', 
                                       'cities_LatLongTzSuntime.csv'))

#%% STEP 2:  TIME CONSTANT ESTIMATION ITERATION
idx1 = 1
for yyyy_mm in yyyy_mm_list:
    print ('\n')
    print('Year_Month Iteration %d of %d started' % (idx1,len(yyyy_mm_list)))
    starting = tm.time()
    print ('\n')
    # Does the Year_month exist?      
    if os.path.exists(os.path.join(cwd, '..', '01-Data',yyyy_mm)):
        idx2 = 1
        for identifier in identifier_list:
            print('Identifier Iteration %d of %d started' % (idx2,len(identifier_list)))
            # Does the identifier exist?
            if os.path.exists(os.path.join(cwd, '..', '01-Data',yyyy_mm,identifier+'.csv')):                 
                if not os.path.exists(os.path.join(cwd, yyyy_mm,'timeCst'+metaData[2:]+'N_'+yyyy_mm+'_'+identifier+'.csv')):
                    try:
                        # Create daylight dataframe
                        daylight = SunRiseSet(df_md, suntime, yyyy_mm, identifier)
                        # Create dataframe df and load data
                        df = pd.DataFrame()
                        df = LoadDataFile(yyyy_mm, identifier)                        
                        #Create dataframe df and save data
                        colCln = CreateColCln(df, daylight)
                        colCln.to_csv(os.path.join(cwd,yyyy_mm,'timeCst'+metaData[2:]+'N_'+yyyy_mm+'_'+identifier+'.csv'), index = True)
                    except UnboundLocalError:
                        print ("Error - Local variable not assigned for %s" %(identifier))
            else:
                print (str(identifier) + ': This identifier was not found in ' + yyyy_mm + '.')
            idx2 += 1
            print(tm.time() - starting)
    else:
        print (yyyy_mm + ': This month was not found in data set.')
        print ('\n')    
    idx1 += 1 
                   
#%% MAIN BODY OF CODE - End
#%% NOTES - Start


#%% NOTES - End